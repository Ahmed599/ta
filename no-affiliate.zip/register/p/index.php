<?php 
	if(isset($_SESSION['email'])){
		header("location: ../dashboard/");
	}
?>
<?php
$servername = "127.0.0.1:3306";
$username = "root";
$password = "wpH35AZ1Lv3@";
$dbname = "topadn6_project";

$language = $fullname = $email = $website = $country = $category = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

//require_once '../../Mail/Mail.php';

if(empty(trim($_POST["email"]))){
        $email_err = "Please enter your email.";
    }else{
        $email = trim($_POST["email"]);
        $statement = $pdo->prepare("SELECT id FROM users WHERE email = :email");
        $statement->execute(array('email' => $email));
        $id = $statement->fetchColumn();
        if($id){
            $email_err = "This email is already taken.";
        }else{
            $email = trim($_POST["email"]);
        }
} 

$pattern = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,12}$/";
if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
}if(!(preg_match($pattern, $_POST["password"])) == 1){
		$password_err = "Password must have 8-12 Uppercase, Lowercase, Symbols and Numbers";
}else{
      $password = trim($_POST["password"]);
}
    

if(empty(trim($_POST["confirm_password"]))){
    $confirm_password_err = "Please confirm password.";     
}else{
    $confirm_password = trim($_POST["confirm_password"]);
    if(empty($password_err) && ($password != $confirm_password)){
        $confirm_password_err = "Password does not match.";
    }
}

if(empty(trim($_POST["website"]))){
    $website_err = "Please enter your website url.";
}else{
    $website = trim($_POST["website"]);
    $statement = $pdo->prepare("SELECT id FROM users WHERE website = :website");
    $statement->execute(array('website' => $website));
    $id = $statement->fetchColumn();
    if($id){
          $website_err = "This website is already registerd.";
    }else{
          $website = trim($_POST["website"]);
          $website = parse_url("$website", PHP_URL_HOST);
          if (!preg_match('#^http(s)?://#', $website)) {
            $website = ('http://' . $website);
          }
          $urlParts = parse_url($website);
          $website = preg_replace('/^www\./', '', $urlParts['host']);
    }
}


  if(empty(trim($_POST["fullname"]))){
    $fullname_err = "Please write your full name.";     
}
if(preg_match('/[#$%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/', $_POST["fullname"])){
   $fullname_err = "Fullname should not contain any special characters";
  }else{
   $fullname = trim($_POST["fullname"]);
  }


$a = "paypal.me";
if(empty(trim($_POST["paypal"]))){
    $paypal_err = "Please enter your PayPal.me link.";

} elseif (strpos(strtolower($_POST["paypal"]), $a) !== false) {

    $paypal = trim($_POST["paypal"]);
    $statement = $pdo->prepare("SELECT id FROM users WHERE paypal = :paypal");
    $statement->execute(array('paypal' => $paypal));
    $id = $statement->fetchColumn();
    if($id){
        $paypal_err = "This PayPal.Me link is already registerd.";
    }else{
        $paypal = trim($_POST["paypal"]);
        }
  }else{
      $paypal_err = "Please enter a valid PayPal.Me link.";
    }
  
if(empty(trim($_POST["category"]))){
    $category_err = "Please choose your website category.";     
}else{
    $category = trim($_POST["category"]);
    }
        
if(empty(trim($_POST["country"]))){
    $country_err = "Please choose your country.";     
}else{
    $country = trim($_POST["country"]);
    }

if(empty(trim($_POST["language"]))){
    $language_err = "Please choose your language.";     
}else{
    $language = trim($_POST["language"]);
    }
		
if(isset($_POST['reference']) and preg_match("/^-?[1-9][0-9]*$/D", $_POST['reference']) == true){
  $reference = trim($_POST['reference']);
}else{
  $reference = '0';   
      }
		
if(isset($language_err) or isset($country_err) or isset($fullname_err) or isset($category_err)){
  $potential_error = "<span class=\"help-block\" style=\"color: #b4b4b4; background: #ff00000d;\">Please check your inputs.</span>";
}if(isset($website_err)){
  $potential_error = "<span class=\"help-block\" style=\"color: #b4b4b4; background: #ff00000d;\">$website_err</span>";
}if(isset($paypal_err)){
  $potential_error = "<span class=\"help-block\" style=\"color: #b4b4b4; background: #ff00000d;\">$paypal_err</span>";
}if(isset($password_err)){
  $potential_error = "<span class=\"help-block\" style=\"color: #b4b4b4; background: #ff00000d;\">$password_err</span>";
}if(isset($confirm_password_err)){
  $potential_error = "<span class=\"help-block\" style=\"color: #b4b4b4; background: #ff00000d;\">$confirm_password_err</span>";
}if(isset($email_err)){
  $potential_error = "<span class=\"help-block\" style=\"color: #b4b4b4; background: #ff00000d;\">$email_err</span>";
    }

require '../add.php';
$redirect = md5(time() . rand(10,100));
$arrow = $total_payment = $coming_payment = $coming_clicks = $coming_imps = $coming_views = $blocked = $active = $emailcode = $affiliate = $step = $dir = $js_file_name1 = $js_file_name2 = $js_file_name3 = $js_file_name4 = $js_file_name5 = "0";
$date = date("Y-m-d");
$prep = md5($_POST["email"]);
$code = md5($prep);
$password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash


if(empty($potential_error)){
try {

$stmt = $pdo->prepare("INSERT INTO users (website, fullname, category, email, paypal, password, country, language, type, blocked, views_map, impressions_map, clicks_map, payment_map, coming_views, coming_imps, coming_clicks, coming_payment, total_payment, arrow, date, code, redirect, emailcode, active, step, dir, js160x600, js300x600, js300x250, js970x250, js728x90, reference, affiliate)
  VALUES (:website, :fullname, :category, :email, :paypal, :password, :country, :language, :type, :blocked, :views_map, :impressions_map, :clicks_map, :payment_map, :coming_views, :coming_imps, :coming_clicks, :coming_payment, :total_payment, :arrow, :date, :code, :redirect, :emailcode, :active, :step, :dir, :js_file_name5, :js_file_name4, :js_file_name3, :js_file_name2, :js_file_name1, :reference, :affiliate)");
$stmt->bindParam(':website', $website);
$stmt->bindParam(':fullname', $fullname);
$stmt->bindParam(':category', $category);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':paypal', $paypal);
$stmt->bindParam(':password', $password);
$stmt->bindParam(':country', $country);
$stmt->bindParam(':language', $language);
$stmt->bindParam(':type', $type);
$stmt->bindParam(':blocked', $blocked);
$stmt->bindParam(':views_map', $views_map);
$stmt->bindParam(':impressions_map', $impressions_map);
$stmt->bindParam(':clicks_map', $clicks_map);
$stmt->bindParam(':payment_map', $payment_map);
$stmt->bindParam(':coming_views', $coming_views);
$stmt->bindParam(':coming_imps', $coming_imps);
$stmt->bindParam(':coming_clicks', $coming_clicks);
$stmt->bindParam(':coming_payment', $coming_payment);
$stmt->bindParam(':total_payment', $total_payment);
$stmt->bindParam(':arrow', $arrow);
$stmt->bindParam(':date', $date);
$stmt->bindParam(':code', $code);
$stmt->bindParam(':redirect', $redirect);
$stmt->bindParam(':emailcode', $emailcode);
$stmt->bindParam(':active', $active);
$stmt->bindParam(':step', $step);
$stmt->bindParam(':dir', $dir);
$stmt->bindParam(":js_file_name1", $js_file_name1, PDO::PARAM_STR);
$stmt->bindParam(":js_file_name2", $js_file_name2, PDO::PARAM_STR);
$stmt->bindParam(":js_file_name3", $js_file_name3, PDO::PARAM_STR);
$stmt->bindParam(":js_file_name4", $js_file_name4, PDO::PARAM_STR);
$stmt->bindParam(":js_file_name5", $js_file_name5, PDO::PARAM_STR);
$stmt->bindParam(':reference', $reference);
$stmt->bindParam(':affiliate', $affiliate);
$type = '1';

require '../add.php';
								 
$redirect = md5(time() . rand(10,100));
$arrow = $total_payment = $coming_payment = $coming_clicks = $coming_imps = $coming_views = $blocked = $active = $emailcode = $affiliate = $step = "0";
$date = date("Y-m-d");
$prep = md5($_POST["email"]);
$code = md5($prep);
$password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash

 if($stmt->execute()){
    
    include_once '../sendverif.php';
    header("location: ../../check-your-email/");
  
	}

} catch(PDOException $e) {
  echo "Error: " . $e->getMessage();
    }

  }
}
?>
                    
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Publisher Registration - Topad.net</title>
<meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style class="INLINE_PEN_STYLESHEET_ID"> body {
}
p {
    margin-top: 0rem;
    margin-bottom: 0rem;
}
a { color: #000;
text-decoration: auto;
}
a:hover, a:active, a:focus { color:#000;
}
@-webkit-keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
@keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
h1 { font-size: 3em; font-weight: bold;
}
h3 { display: block; font-size: 1.5em; margin-left: 0; margin-right: 0; font-weight: bold;
}
.h-100 { margin: 0;
	/*height: 100%!important;*/
}
.text-white {
    color: #6a6e72!important;
}
.cent {
    margin-top: 2rem!important;
    margin-bottom: 2rem!important;
}
.bottom {
font-size: 0.8rem;
color: #6a6e72;
text-decoration: auto;
}
footer {
  text-align: center;
  padding: 3px;
  color: white;
}
  </style>

</head>
<body>
<div class="header">
<a href="../" style="float: left;"><h2 class="fw-light m-3" style="color: #559ade; font-size: 2rem;">TopAd</h2></a>
</div>
<div class="d-flex flex-column justify-content-center w-100">
<div class="d-flex flex-column justify-content-center align-items-center">
<h2 class="fw-light text-white m-3" style="text-align: -webkit-center;font-weight: 400!important;">Sign up now :)</h2>


<h3 style="padding-right: 10%;padding-left: 10%;text-align: center;font-size: 1.3rem;max-width: 1360px;padding-bottom: 1rem;" class="fw-light text-white m-2">
Wish you a good experience.</h3>
<?php 
	if(!empty($potential_error)){echo $potential_error;}
?>
<br>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="text-align: -webkit-center;">
<div style="max-width: 400px; padding-left: 10px; padding-right: 10px;" class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default">Website</span>
  </div>
  <input type="website" name="website" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
</div>
<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">
    <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default">Language</span>
  </div>
    <select class="form-select" name="language" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <option value="" <?php if($language== "") echo "selected"; ?>>Select your website language</option>
                                <option value="English" <?php if($language== "English") echo "selected"; ?>>English</option>
                                <option value="Chinese" <?php if($language== "Chinese") echo "selected"; ?>>Chinese</option>
                                <option value="Hindi" <?php if($language== "Hindi") echo "selected"; ?>>Hindi</option>
                                <option value="Spanish" <?php if($language== "Spanish") echo "selected"; ?>>Spanish</option>
                                <option value="French" <?php if($language== "French") echo "selected"; ?>>French</option>
                                <option value="Arabic" <?php if($language== "Arabic") echo "selected"; ?>>Arabic</option>
                                <option value="Bengali" <?php if($language== "Bengali") echo "selected"; ?>>Bengali</option>
                                <option value="Russian" <?php if($language== "Russian") echo "selected"; ?>>Russian</option>
                                <option value="Portuguese" <?php if($language== "Portuguese") echo "selected"; ?>>Portuguese</option>
                                <option value="Indonesian" <?php if($language== "Indonesian") echo "selected"; ?>>Indonesian</option>
                                <option value="Urdu" <?php if($language== "Urdu") echo "selected"; ?>>Urdu</option>
                                <option value="German" <?php if($language== "German") echo "selected"; ?>>German</option>
                                <option value="Japanese" <?php if($language== "Japanese") echo "selected"; ?>>Japanese</option>
                                <option value="Swahili" <?php if($language== "Swahili") echo "selected"; ?>>Swahili</option>
                                <option value="Marathi" <?php if($language== "Marathi") echo "selected"; ?>>Marathi</option>
                                <option value="Telugu" <?php if($language== "Telugu") echo "selected"; ?>>Telugu</option>
                                <option value="Punjabi" <?php if($language== "Punjabi") echo "selected"; ?>>Punjabi</option>
                                <option value="Tamil" <?php if($language== "Tamil") echo "selected"; ?>>Tamil</option>
                                <option value="Turkish" <?php if($language== "Turkish") echo "selected"; ?>>Turkish</option></select>
</div>

<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">
    <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default">Country</span>
  </div>
    <select class=" form-select"  name="country" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <option value="" <?php if($country== "") echo "selected"; ?>>Select your country</option>
                                <option value="Afghanistan" <?php if($country== "Afghanistan") echo "selected"; ?>>Afghanistan</option>
                            <option value="Albania" <?php if($country== "Albania") echo "selected"; ?>>Albania</option>
                            <option value="Algeria" <?php if($country== "Algeria") echo "selected"; ?>>Algeria</option>
                            <option value="American Samoa" <?php if($country== "American Samoa") echo "selected"; ?>>American Samoa</option>
                            <option value="Andorra" <?php if($country== "Andorra") echo "selected"; ?>>Andorra</option>
                            <option value="Angola" <?php if($country== "Angola") echo "selected"; ?>>Angola</option>
                            <option value="Anguilla" <?php if($country== "Anguilla") echo "selected"; ?>>Anguilla</option>
                            <option value="Antartica" <?php if($country== "Antartica") echo "selected"; ?>>Antarctica</option>
                            <option value="Antigua and Barbuda" <?php if($country== "Antigua and Barbuda") echo "selected"; ?>>Antigua and Barbuda</option>
                            <option value="Argentina" <?php if($country== "Argentina") echo "selected"; ?>>Argentina</option>
                            <option value="Armenia" <?php if($country== "Armenia") echo "selected"; ?>>Armenia</option>
                            <option value="Aruba" <?php if($country== "Aruba") echo "selected"; ?>>Aruba</option>
                            <option value="Australia" <?php if($country== "Australia") echo "selected"; ?>>Australia</option>
                            <option value="Austria" <?php if($country== "Austria") echo "selected"; ?>>Austria</option>
                            <option value="Azerbaijan" <?php if($country== "Azerbaijan") echo "selected"; ?>>Azerbaijan</option>
                            <option value="Bahamas"<?php if($country== "Bahamas") echo "selected"; ?>>Bahamas</option>
                            <option value="Bahrain" <?php if($country== "Bahrain") echo "selected"; ?>>Bahrain</option>
                            <option value="Bangladesh" <?php if($country== "Bangladesh") echo "selected"; ?>>Bangladesh</option>
                            <option value="Barbados" <?php if($country== "Barbados") echo "selected"; ?>>Barbados</option>
                            <option value="Belarus" <?php if($country== "Belarus") echo "selected"; ?>>Belarus</option>
                            <option value="Belgium" <?php if($country== "Belgium") echo "selected"; ?>>Belgium</option>
                            <option value="Belize" <?php if($country== "Belize") echo "selected"; ?>>Belize</option>
                            <option value="Benin" <?php if($country== "Benin") echo "selected"; ?>>Benin</option>
                            <option value="Bermuda" <?php if($country== "Bermuda") echo "selected"; ?>>Bermuda</option>
                            <option value="Bhutan" <?php if($country== "Bhutan") echo "selected"; ?>>Bhutan</option>
                            <option value="Bolivia" <?php if($country== "Bolivia") echo "selected"; ?>>Bolivia</option>
                            <option value="Bosnia and Herzegowina" <?php if($country== "Bosnia and Herzegowina") echo "selected"; ?>>Bosnia and Herzegowina</option>
                            <option value="Botswana" <?php if($country== "Botswana") echo "selected"; ?>>Botswana</option>
                            <option value="Bouvet Island" <?php if($country== "Bouvet Island") echo "selected"; ?>>Bouvet Island</option>
                            <option value="Brazil" <?php if($country== "Brazil") echo "selected"; ?>>Brazil</option>
                            <option value="Brunei Darussalam" <?php if($country== "Brunei Darussalam") echo "selected"; ?>>Brunei Darussalam</option>
                            <option value="Bulgaria" <?php if($country== "Bulgaria") echo "selected"; ?>>Bulgaria</option>
                            <option value="Burkina Faso" <?php if($country== "Burkina Faso") echo "selected"; ?>>Burkina Faso</option>
                            <option value="Burundi" <?php if($country== "Burundi") echo "selected"; ?>>Burundi</option>
                            <option value="Cambodia" <?php if($country== "Cambodia") echo "selected"; ?>>Cambodia</option>
                            <option value="Cameroon" <?php if($country== "Cameroon") echo "selected"; ?>>Cameroon</option>
                            <option value="Canada" <?php if($country== "Canada") echo "selected"; ?>>Canada</option>
                            <option value="Cape Verde" <?php if($country== "Cape Verde") echo "selected"; ?>>Cape Verde</option>
                            <option value="Cayman Islands" <?php if($country== "Cayman Islands") echo "selected"; ?>>Cayman Islands</option>
                            <option value="Central African Republic" <?php if($country== "Central African Republic") echo "selected"; ?>>Central African Republic</option>
                            <option value="Chad" <?php if($country== "Chad") echo "selected"; ?>>Chad</option>
                            <option value="Chile" <?php if($country== "Chile") echo "selected"; ?>>Chile</option>
                            <option value="China" <?php if($country== "China") echo "selected"; ?>>China</option>
                            <option value="Christmas Island" <?php if($country== "Christmas Island") echo "selected"; ?>>Christmas Island</option>
                            <option value="Cocos Islands" <?php if($country== "Cocos Islands") echo "selected"; ?>>Cocos (Keeling) Islands</option>
                            <option value="Colombia" <?php if($country== "Colombia") echo "selected"; ?>>Colombia</option>
                            <option value="Comoros" <?php if($country== "Comoros") echo "selected"; ?>>Comoros</option>
                            <option value="Congo" <?php if($country== "Congo") echo "selected"; ?>>Congo</option>
                            <option value="Congo" <?php if($country== "Congo") echo "selected"; ?>>Congo</option>
                            <option value="Cook Islands" <?php if($country== "Cook Islands") echo "selected"; ?>>Cook Islands</option>
                            <option value="Costa Rica" <?php if($country== "Costa Rica") echo "selected"; ?>>Costa Rica</option>
                            <option value="Cota D'Ivoire" <?php if($country== "Cota D'Ivoire") echo "selected"; ?>>Cote d'Ivoire</option>
                            <option value="Croatia" <?php if($country== "Croatia") echo "selected"; ?>>Croatia (Hrvatska)</option>
                            <option value="Cuba" <?php if($country== "Cuba") echo "selected"; ?>>Cuba</option>
                            <option value="Cyprus" <?php if($country== "Cyprus") echo "selected"; ?>>Cyprus</option>
                            <option value="Czech Republic" <?php if($country== "Czech Republic") echo "selected"; ?>>Czech Republic</option>
                            <option value="Denmark" <?php if($country== "Denmark") echo "selected"; ?>>Denmark</option>
                            <option value="Djibouti" <?php if($country== "Djibouti") echo "selected"; ?>>Djibouti</option>
                            <option value="Dominica" <?php if($country== "Dominica") echo "selected"; ?>>Dominica</option>
                            <option value="Dominican Republic" <?php if($country== "Dominican Republic") echo "selected"; ?>>Dominican Republic</option>
                            <option value="East Timor" <?php if($country== "East Timor") echo "selected"; ?>>East Timor</option>
                            <option value="Ecuador" <?php if($country== "Ecuador") echo "selected"; ?>>Ecuador</option>
                            <option value="Egypt" <?php if($country== "Egypt") echo "selected"; ?>>Egypt</option>
                            <option value="El Salvador" <?php if($country== "El Salvador") echo "selected"; ?>>El Salvador</option>
                            <option value="Equatorial Guinea" <?php if($country== "Equatorial Guinea") echo "selected"; ?>>Equatorial Guinea</option>
                            <option value="Eritrea" <?php if($country== "Eritrea") echo "selected"; ?>>Eritrea</option>
                            <option value="Estonia" <?php if($country== "Estonia") echo "selected"; ?>>Estonia</option>
                            <option value="Ethiopia" <?php if($country== "Ethiopia") echo "selected"; ?>>Ethiopia</option>
                            <option value="Fiji" <?php if($country== "Fiji") echo "selected"; ?>>Fiji</option>
                            <option value="Finland" <?php if($country== "Finland") echo "selected"; ?>>Finland</option>
                            <option value="France" <?php if($country== "France") echo "selected"; ?>>France</option>
                            <option value="French Polynesia" <?php if($country== "French Polynesia") echo "selected"; ?>>French Polynesia</option>
                            <option value="Gabon" <?php if($country== "Gabon") echo "selected"; ?>>Gabon</option>
                            <option value="Gambia" <?php if($country== "Gambia") echo "selected"; ?>>Gambia</option>
                            <option value="Georgia" <?php if($country== "Georgia") echo "selected"; ?>>Georgia</option>
                            <option value="Germany" <?php if($country== "Germany") echo "selected"; ?>>Germany</option>
                            <option value="Ghana" <?php if($country== "Ghana") echo "selected"; ?>>Ghana</option>
                            <option value="Gibraltar" <?php if($country== "Gibraltar") echo "selected"; ?>>Gibraltar</option>
                            <option value="Greece" <?php if($country== "Greece") echo "selected"; ?>>Greece</option>
                            <option value="Greenland" <?php if($country== "Greenland") echo "selected"; ?>>Greenland</option>
                            <option value="Grenada" <?php if($country== "Grenada") echo "selected"; ?>>Grenada</option>
                            <option value="Guadeloupe" <?php if($country== "Guadeloupe") echo "selected"; ?>>Guadeloupe</option>
                            <option value="Guam" <?php if($country== "Guam") echo "selected"; ?>>Guam</option>
                            <option value="Guatemala" <?php if($country== "Guatemala") echo "selected"; ?>>Guatemala</option>
                            <option value="Guinea" <?php if($country== "Guinea") echo "selected"; ?>>Guinea</option>
                            <option value="Guinea-Bissau" <?php if($country== "Guinea-Bissau") echo "selected"; ?>>Guinea-Bissau</option>
                            <option value="Guyana" <?php if($country== "Guyana") echo "selected"; ?>>Guyana</option>
                            <option value="Haiti" <?php if($country== "Haiti") echo "selected"; ?>>Haiti</option>
                            <option value="Honduras" <?php if($country== "Honduras") echo "selected"; ?>>Honduras</option>
                            <option value="Hong Kong" <?php if($country== "Hong Kong") echo "selected"; ?>>Hong Kong</option>
                            <option value="Hungary" <?php if($country== "Hungary") echo "selected"; ?>>Hungary</option>
                            <option value="Iceland" <?php if($country== "Iceland") echo "selected"; ?>>Iceland</option>
                            <option value="India" <?php if($country== "India") echo "selected"; ?>>India</option>
                            <option value="Indonesia" <?php if($country== "Indonesia") echo "selected"; ?>>Indonesia</option>
                            <option value="Iran" <?php if($country== "Iran") echo "selected"; ?>>Iran (Islamic Republic of)</option>
                            <option value="Iraq" <?php if($country== "Iraq") echo "selected"; ?>>Iraq</option>
                            <option value="Ireland" <?php if($country== "Ireland") echo "selected"; ?>>Ireland</option>
                            <option value="Israel" <?php if($country== "Israel") echo "selected"; ?>>Israel</option>
                            <option value="Italy" <?php if($country== "Italy") echo "selected"; ?>>Italy</option>
                            <option value="Jamaica" <?php if($country== "Jamaica") echo "selected"; ?>>Jamaica</option>
                            <option value="Japan" <?php if($country== "Japan") echo "selected"; ?>>Japan</option>
                            <option value="Jordan" <?php if($country== "Jordan") echo "selected"; ?>>Jordan</option>
                            <option value="Kazakhstan" <?php if($country== "Kazakhstan") echo "selected"; ?>>Kazakhstan</option>
                            <option value="Kenya" <?php if($country== "Kenya") echo "selected"; ?>>Kenya</option>
                            <option value="Kiribati" <?php if($country== "Kiribati") echo "selected"; ?>>Kiribati</option></option>
                            <option value="North Korea" <?php if($country== "North Korea") echo "selected"; ?>>North Korea</option>
                            <option value="South Korea" <?php if($country== "South Korea") echo "selected"; ?>>South Korea</option>
                            <option value="Kuwait" <?php if($country== "Kuwait") echo "selected"; ?>>Kuwait</option>
                            <option value="Kyrgyzstan" <?php if($country== "Kyrgyzstan") echo "selected"; ?>>Kyrgyzstan</option>
                            <option value="Lao" <?php if($country== "Lao") echo "selected"; ?>>Lao</option>
                            <option value="Latvia" <?php if($country== "Latvia") echo "selected"; ?>>Latvia</option>
                            <option value="Lebanon" <?php if($country== "Lebanon") echo "selected"; ?>>Lebanon</option>
                            <option value="Lesotho" <?php if($country== "Lesotho") echo "selected"; ?>>Lesotho</option>
                            <option value="Liberia" <?php if($country== "Liberia") echo "selected"; ?>>Liberia</option>
                            <option value="Libya" <?php if($country== "Libya") echo "selected"; ?>>Libya</option>
                            <option value="Liechtenstein" <?php if($country== "Liechtenstein") echo "selected"; ?>>Liechtenstein</option>
                            <option value="Lithuania" <?php if($country== "Lithuania") echo "selected"; ?>>Lithuania</option>
                            <option value="Luxembourg" <?php if($country== "Luxembourg") echo "selected"; ?>>Luxembourg</option>
                            <option value="Macau" <?php if($country== "Macau") echo "selected"; ?>>Macau</option>
                            <option value="Macedonia" <?php if($country== "Macedonia") echo "selected"; ?>>Macedonia</option>
                            <option value="Madagascar" <?php if($country== "Madagascar") echo "selected"; ?>>Madagascar</option>
                            <option value="Malawi" <?php if($country== "Malawi") echo "selected"; ?>>Malawi</option>
                            <option value="Malaysia" <?php if($country== "Malaysia") echo "selected"; ?>>Malaysia</option>
                            <option value="Maldives" <?php if($country== "Maldives") echo "selected"; ?>>Maldives</option>
                            <option value="Mali" <?php if($country== "Mali") echo "selected"; ?>>Mali</option>
                            <option value="Malta" <?php if($country== "Malta") echo "selected"; ?>>Malta</option>
                            <option value="Martinique" <?php if($country== "Martinique") echo "selected"; ?>>Martinique</option>
                            <option value="Mauritania" <?php if($country== "Mauritania") echo "selected"; ?>>Mauritania</option>
                            <option value="Mauritius" <?php if($country== "Mauritius") echo "selected"; ?>>Mauritius</option>
                            <option value="Mayotte" <?php if($country== "Mayotte") echo "selected"; ?>>Mayotte</option>
                            <option value="Mexico" <?php if($country== "Mexico") echo "selected"; ?>>Mexico</option>
                            <option value="Moldova" <?php if($country== "Moldova") echo "selected"; ?>>Moldova, Republic of</option>
                            <option value="Monaco" <?php if($country== "Monaco") echo "selected"; ?>>Monaco</option>
                            <option value="Mongolia" <?php if($country== "Mongolia") echo "selected"; ?>>Mongolia</option>
                            <option value="Montserrat" <?php if($country== "Montserrat") echo "selected"; ?>>Montserrat</option>
                            <option value="Morocco" <?php if($country== "Morocco") echo "selected"; ?>>Morocco</option>
                            <option value="Mozambique" <?php if($country== "Mozambique") echo "selected"; ?>>Mozambique</option>
                            <option value="Myanmar" <?php if($country== "Myanmar") echo "selected"; ?>>Myanmar</option>
                            <option value="Namibia" <?php if($country== "Namibia") echo "selected"; ?>>Namibia</option>
                            <option value="Nauru" <?php if($country== "Nauru") echo "selected"; ?>>Nauru</option>
                            <option value="Nepal" <?php if($country== "Nepal") echo "selected"; ?>>Nepal</option>
                            <option value="Netherlands" <?php if($country== "Netherlands") echo "selected"; ?>>Netherlands</option>
                            <option value="New Caledonia" <?php if($country== "New Caledonia") echo "selected"; ?>>New Caledonia</option>
                            <option value="New Zealand" <?php if($country== "New Zealand") echo "selected"; ?>>New Zealand</option>
                            <option value="Nicaragua" <?php if($country== "Nicaragua") echo "selected"; ?>>Nicaragua</option>
                            <option value="Niger" <?php if($country== "Niger") echo "selected"; ?>>Niger</option>
                            <option value="Nigeria" <?php if($country== "Nigeria") echo "selected"; ?>>Nigeria</option>
                            <option value="Niue" <?php if($country== "Niue") echo "selected"; ?>>Niue</option>
                            <option value="Norway" <?php if($country== "Norway") echo "selected"; ?>>Norway</option>
                            <option value="Oman" <?php if($country== "Oman") echo "selected"; ?>>Oman</option>
                            <option value="Pakistan" <?php if($country== "Pakistan") echo "selected"; ?>>Pakistan</option>
                            <option value="Palau" <?php if($country== "Palau") echo "selected"; ?>>Palau</option>
                            <option value="Panama" <?php if($country== "Panama") echo "selected"; ?>>Panama</option>
                            <option value="Paraguay" <?php if($country== "Paraguay") echo "selected"; ?>>Paraguay</option>
                            <option value="Peru" <?php if($country== "Peru") echo "selected"; ?>>Peru</option>
                            <option value="Philippines" <?php if($country== "Philippines") echo "selected"; ?>>Philippines</option>
                            <option value="Pitcairn" <?php if($country== "Pitcairn") echo "selected"; ?>>Pitcairn</option>
                            <option value="Poland" <?php if($country== "Poland") echo "selected"; ?>>Poland</option>
                            <option value="Portugal" <?php if($country== "Portugal") echo "selected"; ?>>Portugal</option>
                            <option value="Puerto Rico" <?php if($country== "Puerto Rico") echo "selected"; ?>>Puerto Rico</option>
                            <option value="Qatar" <?php if($country== "Qatar") echo "selected"; ?>>Qatar</option>
                            <option value="Reunion" <?php if($country== "Reunion") echo "selected"; ?>>Reunion</option>
                            <option value="Romania" <?php if($country== "Romania") echo "selected"; ?>>Romania</option>
                            <option value="Russia" <?php if($country== "Russia") echo "selected"; ?>>Russian Federation</option>
                            <option value="Rwanda" <?php if($country== "Rwanda") echo "selected"; ?>>Rwanda</option>
                            <option value="Samoa" <?php if($country== "Samoa") echo "selected"; ?>>Samoa</option>
                            <option value="San Marino" <?php if($country== "San Marino") echo "selected"; ?>>San Marino</option>
                            <option value="Saudi Arabia" <?php if($country== "Saudi Arabia") echo "selected"; ?>>Saudi Arabia</option>
                            <option value="Senegal" <?php if($country== "Senegal") echo "selected"; ?>>Senegal</option>
                            <option value="Seychelles" <?php if($country== "Seychelles") echo "selected"; ?>>Seychelles</option>
                            <option value="Sierra" <?php if($country== "Sierra") echo "selected"; ?>>Sierra Leone</option>
                            <option value="Singapore" <?php if($country== "Singapore") echo "selected"; ?>>Singapore</option>
                            <option value="Slovakia" <?php if($country== "Slovakia") echo "selected"; ?>>Slovakia</option>
                            <option value="Slovenia" <?php if($country== "Slovenia") echo "selected"; ?>>Slovenia</option>
                            <option value="Somalia" <?php if($country== "Somalia") echo "selected"; ?>>Somalia</option>
                            <option value="South Africa" <?php if($country== "South Africa") echo "selected"; ?>>South Africa</option>
                            <option value="Span" <?php if($country== "Span") echo "selected"; ?>>Spain</option>
                            <option value="SriLanka" <?php if($country== "SriLanka") echo "selected"; ?>>Sri Lanka</option>
                            <option value="St. Helena" <?php if($country== "St. Helena") echo "selected"; ?>>St. Helena</option>
                            <option value="Sudan" <?php if($country== "Sudan") echo "selected"; ?>>Sudan</option>
                            <option value="Suriname" <?php if($country== "Suriname") echo "selected"; ?>>Suriname</option>
                            <option value="Swaziland" <?php if($country== "Swaziland") echo "selected"; ?>>Swaziland</option>
                            <option value="Sweden" <?php if($country== "Sweden") echo "selected"; ?>>Sweden</option>
                            <option value="Switzerland" <?php if($country== "Switzerland") echo "selected"; ?>>Switzerland</option>
                            <option value="Syria" <?php if($country== "Syria") echo "selected"; ?>>Syrian Arab Republic</option>
                            <option value="Taiwan" <?php if($country== "Taiwan") echo "selected"; ?>>Taiwan</option>
                            <option value="Tajikistan" <?php if($country== "Tajikistan") echo "selected"; ?>>Tajikistan</option>
                            <option value="Tanzania" <?php if($country== "Tanzania") echo "selected"; ?>>Tanzania</option>
                            <option value="Thailand" <?php if($country== "Thailand") echo "selected"; ?>>Thailand</option>
                            <option value="Togo" <?php if($country== "Togo") echo "selected"; ?>>Togo</option>
                            <option value="Tokelau" <?php if($country== "Tokelau") echo "selected"; ?>>Tokelau</option>
                            <option value="Tonga" <?php if($country== "Tonga") echo "selected"; ?>>Tonga</option>
                            <option value="Tunisia" <?php if($country== "Tunisia") echo "selected"; ?>>Tunisia</option>
                            <option value="Turkey" <?php if($country== "Turkey") echo "selected"; ?>>Turkey</option>
                            <option value="Turkmenistan" <?php if($country== "Turkmenistan") echo "selected"; ?>>Turkmenistan</option>
                            <option value="Tuvalu" <?php if($country== "Tuvalu") echo "selected"; ?>>Tuvalu</option>
                            <option value="Uganda" <?php if($country== "Uganda") echo "selected"; ?>>Uganda</option>
                            <option value="Ukraine" <?php if($country== "Ukraine") echo "selected"; ?>>Ukraine</option>
                            <option value="United Arab Emirates" <?php if($country== "United Arab Emirates") echo "selected"; ?>>United Arab Emirates</option>
                            <option value="United Kingdom" <?php if($country== "United Kingdom") echo "selected"; ?>>United Kingdom</option>
                            <option value="United States" <?php if($country== "United States") echo "selected"; ?>>United States</option>
                            <option value="Uruguay" <?php if($country== "Uruguay") echo "selected"; ?>>Uruguay</option>
                            <option value="Uzbekistan" <?php if($country== "Uzbekistan") echo "selected"; ?>>Uzbekistan</option>
                            <option value="Vanuatu" <?php if($country== "Vanuatu") echo "selected"; ?>>Vanuatu</option>
                            <option value="Venezuela" <?php if($country== "Venezuela") echo "selected"; ?>>Venezuela</option>
                            <option value="Vietnam" <?php if($country== "Vietnam") echo "selected"; ?>>Viet Nam</option>
                            <option value="Yemen" <?php if($country== "Yemen") echo "selected"; ?>>Yemen</option>
                            <option value="Serbia" <?php if($country== "Serbia") echo "selected"; ?>>Serbia</option>
                            <option value="Zambia" <?php if($country== "Zambia") echo "selected"; ?>>Zambia</option>
                            <option value="Zimbabwe" <?php if($country== "Zimbabwe") echo "selected"; ?>>Zimbabwe</option></select>
							</div>

<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default">Full Name</span>
  </div>
  <input type="text" name="fullname" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
  </div>


<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default">Email</span>
  </div>
  <input type="email" name="email" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
</div>


<div class="input-group mb-3" style="padding-left: 10px; padding-right: 10px; max-width: 400px;">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default">Password</span>
  </div>
  <input type="password" name="password" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
</div>

<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default">Re-Password</span>
  </div>
  <input type="password" name="confirm_password" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
</div>

<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">
    <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default">Category</span>
  </div>
    <select name="category" id="category" class="form-control input-sm">
             <option value="" <?php if($category== "") echo "selected"; ?>>Select your website category</option>
                        <option value="Film & Animation" <?php if($category== "Film & Animation") echo "selected"; ?>>Film & Animation</option>
                        <option value="Autos & Vehicles" <?php if($category== "Autos & Vehicles") echo "selected"; ?>>Autos & Vehicles</option>
                        <option value="Pets & Animals" <?php if($category== "Pets & Animals") echo "selected"; ?>>Pets & Animals</option>
                        <option value="Sports" <?php if($category== "Sports") echo "selected"; ?>>Sports</option>
                        <option value="Travel & Events" <?php if($category== "Travel & Events") echo "selected"; ?>>Travel & Events</option>
                        <option value="Gaming" <?php if($category== "Gaming") echo "selected"; ?>>Gaming</option>
                        <option value="People & Blogs" <?php if($category== "People & Blogs") echo "selected"; ?>>People & Blogs</option>
                        <option value="Comedy" <?php if($category== "Comedy") echo "selected"; ?>>Comedy</option>
                        <option value="Entertainment" <?php if($category== "Entertainment") echo "selected"; ?>>Entertainment</option>
                        <option value="News & Politics" <?php if($category== "News & Politics") echo "selected"; ?>>News & Politics</option>
                        <option value="Howto & Style" <?php if($category== "Howto & Style") echo "selected"; ?>>Howto & Style</option>
                        <option value="Education" <?php if($category== "Education") echo "selected"; ?>>Education</option>
                        <option value="Science & Technology" <?php if($category== "Science & Technology") echo "selected"; ?>>Science & Technology</option>
                        <option value="Nonprofits & Activism" <?php if($category== "Nonprofits & Activism") echo "selected"; ?>>Nonprofits & Activism</option></select>
</div>

<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">
  <div class="input-group-prepend" style="display: inline-flex;">
    <span class="input-group-text" id="inputGroup-sizing-default">Your PayPal.me Link</span>
  <input type="text" name="paypal" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
  </div>
</div>

<div class="btn-group cent" style="margin-top: 1rem!important; margin-bottom: 1rem!important;">

<span style="width: 1rem;"></span>
<input class="btn btn-outline-dark" style="border-top-left-radius: 4px;border-bottom-left-radius: 4px;padding: 0.6rem;" value="REGISTER NOW" type="submit">
</div>
</form>
<h6 class="fw-light text-white m-0 text-decoration-none">Or login <a href="../login/">here</a> if you already have an account.</h6> 
</div>
</div>
<div style="text-align: -webkit-center;"><hr style="width:35%;"></div>
<footer>
<div style="text-align: center; margin-bottom: 1rem;"><a href="../../how-it-works/" class="bottom">How it works</a>&emsp;<a href="../../pricing/" class="bottom">Pricing</a>&emsp;<a href="../../contact-us/" class="bottom">Contact us</a>
&emsp;<a href="../../about/" class="bottom">About</a></div>
<p class="fw-light text-white bottom" style="text-align: -webkit-center;">Topad.net © <?php echo date("Y"); ?></p>
</footer>
</body>
</html>
