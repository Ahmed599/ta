<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '..\phpmailer\src\Exception.php';
require_once '..\phpmailer\src\PHPMailer.php';
require_once '..\phpmailer\src\SMTP.php';
$mail = new PHPMailer(true);

$a = rand(1000000,10000000);
$b = md5($a);
$c = base64_encode(md5(rand(1,1000)));
$url = "https://www.topad.net/v/?se=$a&tn=$b&r=$code&c=$c";

try {
    // Server settings
    $mail->SMTPDebug = 0; // for detailed debug output
    $mail->isSMTP();
    $mail->Host = 'smtp-relay.brevo.com';
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->Username = 'topad.net@gmail.com'; // YOUR gmail email
    $mail->Password = 'xsmtpsib-84867de6121d39f505ffc7b9073db195299dcfbacf5c77e44c651930b178e3b5-G40IHK58xXZO96pj'; // YOUR gmail password

    // Sender and recipient settings
    $mail->setFrom('no-reply@topad.net', 'TopAd ');
    $mail->addAddress("$email", '');

    // Setting the email content
    $mail->IsHTML(true);
    $mail->Subject = "Signup | Verification";
    $mail->Body = 'Thanks for signing up!
    Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below. 
    Please click this link to activate your account:
    <a href="' . $url . '">Click Here</a>';

    $mail->send();
    header("location: https://www.topad.net/check-your-email");
} catch (Exception $e) {
    header("location: https://www.topad.net/error");
}

?>
