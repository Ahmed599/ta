<?php
require_once "../connect/connect1.php";


$keywords  = array("SELECT", "UPDATE", "DELETE", "ORDER BY", "INSERT", "LIMIT", "UNION", "CASE", "GROUP BY", "WHERE", "select", "update", "delete", "order by", "insert", "limit", "union", "case", "group by", "where", "=", "*", ",");
$replace = array("SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "", "", "");

$Ad_redirect = $_GET['a'];
$Adv_redirect = $_GET['r'];

$Ad_redirect = str_replace($keywords, $replace, $Ad_redirect);
$Adv_redirect = str_replace($keywords, $replace, $Adv_redirect);	

$stmt = $pdo->prepare('SELECT * FROM users WHERE redirect = ?');
$stmt->execute([$Adv_redirect]);
$data = $stmt->fetchAll();
if ($data){
		$status = 4;
		$stmt = $pdo->prepare('UPDATE ads_normal SET status = ? WHERE redirect = ?');
		$stmt->execute([$status, $Ad_redirect]);
		$stmt->fetchAll();
		header("Location: ads.php");
		}

?>
