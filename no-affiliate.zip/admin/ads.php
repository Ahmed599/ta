<?php include 'das-php.php';?>
<html lang="en"><head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../../assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="../../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="../../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../../assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../../assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.2.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
<style id="apexcharts-css">.apexcharts-canvas {
  position: relative;
  user-select: none;
  /* cannot give overflow: hidden as it will crop tooltips which overflow outside chart area */
}


/* scrollbar is not visible by default for legend, hence forcing the visibility */
.apexcharts-canvas ::-webkit-scrollbar {
  -webkit-appearance: none;
  width: 6px;
}

.apexcharts-canvas ::-webkit-scrollbar-thumb {
  border-radius: 4px;
  background-color: rgba(0, 0, 0, .5);
  box-shadow: 0 0 1px rgba(255, 255, 255, .5);
  -webkit-box-shadow: 0 0 1px rgba(255, 255, 255, .5);
}


.apexcharts-inner {
  position: relative;
}

.apexcharts-text tspan {
  font-family: inherit;
}

.legend-mouseover-inactive {
  transition: 0.15s ease all;
  opacity: 0.20;
}

.apexcharts-series-collapsed {
  opacity: 0;
}

.apexcharts-tooltip {
  border-radius: 5px;
  box-shadow: 2px 2px 6px -4px #999;
  cursor: default;
  font-size: 14px;
  left: 62px;
  opacity: 0;
  pointer-events: none;
  position: absolute;
  top: 20px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  white-space: nowrap;
  z-index: 12;
  transition: 0.15s ease all;
}

.apexcharts-tooltip.apexcharts-active {
  opacity: 1;
  transition: 0.15s ease all;
}

.apexcharts-tooltip.apexcharts-theme-light {
  border: 1px solid #e3e3e3;
  background: rgba(255, 255, 255, 0.96);
}

.apexcharts-tooltip.apexcharts-theme-dark {
  color: #fff;
  background: rgba(30, 30, 30, 0.8);
}

.apexcharts-tooltip * {
  font-family: inherit;
}


.apexcharts-tooltip-title {
  padding: 6px;
  font-size: 15px;
  margin-bottom: 4px;
}

.apexcharts-tooltip.apexcharts-theme-light .apexcharts-tooltip-title {
  background: #ECEFF1;
  border-bottom: 1px solid #ddd;
}

.apexcharts-tooltip.apexcharts-theme-dark .apexcharts-tooltip-title {
  background: rgba(0, 0, 0, 0.7);
  border-bottom: 1px solid #333;
}

.apexcharts-tooltip-text-y-value,
.apexcharts-tooltip-text-goals-value,
.apexcharts-tooltip-text-z-value {
  display: inline-block;
  font-weight: 600;
  margin-left: 5px;
}

.apexcharts-tooltip-text-y-label:empty,
.apexcharts-tooltip-text-y-value:empty,
.apexcharts-tooltip-text-goals-label:empty,
.apexcharts-tooltip-text-goals-value:empty,
.apexcharts-tooltip-text-z-value:empty {
  display: none;
}

.apexcharts-tooltip-text-y-value,
.apexcharts-tooltip-text-goals-value,
.apexcharts-tooltip-text-z-value {
  font-weight: 600;
}

.apexcharts-tooltip-text-goals-label, 
.apexcharts-tooltip-text-goals-value {
  padding: 6px 0 5px;
}

.apexcharts-tooltip-goals-group, 
.apexcharts-tooltip-text-goals-label, 
.apexcharts-tooltip-text-goals-value {
  display: flex;
}
.apexcharts-tooltip-text-goals-label:not(:empty),
.apexcharts-tooltip-text-goals-value:not(:empty) {
  margin-top: -6px;
}

.apexcharts-tooltip-marker {
  width: 12px;
  height: 12px;
  position: relative;
  top: 0px;
  margin-right: 10px;
  border-radius: 50%;
}

.apexcharts-tooltip-series-group {
  padding: 0 10px;
  display: none;
  text-align: left;
  justify-content: left;
  align-items: center;
}

.apexcharts-tooltip-series-group.apexcharts-active .apexcharts-tooltip-marker {
  opacity: 1;
}

.apexcharts-tooltip-series-group.apexcharts-active,
.apexcharts-tooltip-series-group:last-child {
  padding-bottom: 4px;
}

.apexcharts-tooltip-series-group-hidden {
  opacity: 0;
  height: 0;
  line-height: 0;
  padding: 0 !important;
}

.apexcharts-tooltip-y-group {
  padding: 6px 0 5px;
}

.apexcharts-tooltip-box, .apexcharts-custom-tooltip {
  padding: 4px 8px;
}

.apexcharts-tooltip-boxPlot {
  display: flex;
  flex-direction: column-reverse;
}

.apexcharts-tooltip-box>div {
  margin: 4px 0;
}

.apexcharts-tooltip-box span.value {
  font-weight: bold;
}

.apexcharts-tooltip-rangebar {
  padding: 5px 8px;
}

.apexcharts-tooltip-rangebar .category {
  font-weight: 600;
  color: #777;
}

.apexcharts-tooltip-rangebar .series-name {
  font-weight: bold;
  display: block;
  margin-bottom: 5px;
}

.apexcharts-xaxistooltip {
  opacity: 0;
  padding: 9px 10px;
  pointer-events: none;
  color: #373d3f;
  font-size: 13px;
  text-align: center;
  border-radius: 2px;
  position: absolute;
  z-index: 10;
  background: #ECEFF1;
  border: 1px solid #90A4AE;
  transition: 0.15s ease all;
}

.apexcharts-xaxistooltip.apexcharts-theme-dark {
  background: rgba(0, 0, 0, 0.7);
  border: 1px solid rgba(0, 0, 0, 0.5);
  color: #fff;
}

.apexcharts-xaxistooltip:after,
.apexcharts-xaxistooltip:before {
  left: 50%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}

.apexcharts-xaxistooltip:after {
  border-color: rgba(236, 239, 241, 0);
  border-width: 6px;
  margin-left: -6px;
}

.apexcharts-xaxistooltip:before {
  border-color: rgba(144, 164, 174, 0);
  border-width: 7px;
  margin-left: -7px;
}

.apexcharts-xaxistooltip-bottom:after,
.apexcharts-xaxistooltip-bottom:before {
  bottom: 100%;
}

.apexcharts-xaxistooltip-top:after,
.apexcharts-xaxistooltip-top:before {
  top: 100%;
}

.apexcharts-xaxistooltip-bottom:after {
  border-bottom-color: #ECEFF1;
}

.apexcharts-xaxistooltip-bottom:before {
  border-bottom-color: #90A4AE;
}

.apexcharts-xaxistooltip-bottom.apexcharts-theme-dark:after {
  border-bottom-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-xaxistooltip-bottom.apexcharts-theme-dark:before {
  border-bottom-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-xaxistooltip-top:after {
  border-top-color: #ECEFF1
}

.apexcharts-xaxistooltip-top:before {
  border-top-color: #90A4AE;
}

.apexcharts-xaxistooltip-top.apexcharts-theme-dark:after {
  border-top-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-xaxistooltip-top.apexcharts-theme-dark:before {
  border-top-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-xaxistooltip.apexcharts-active {
  opacity: 1;
  transition: 0.15s ease all;
}

.apexcharts-yaxistooltip {
  opacity: 0;
  padding: 4px 10px;
  pointer-events: none;
  color: #373d3f;
  font-size: 13px;
  text-align: center;
  border-radius: 2px;
  position: absolute;
  z-index: 10;
  background: #ECEFF1;
  border: 1px solid #90A4AE;
}

.apexcharts-yaxistooltip.apexcharts-theme-dark {
  background: rgba(0, 0, 0, 0.7);
  border: 1px solid rgba(0, 0, 0, 0.5);
  color: #fff;
}

.apexcharts-yaxistooltip:after,
.apexcharts-yaxistooltip:before {
  top: 50%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}

.apexcharts-yaxistooltip:after {
  border-color: rgba(236, 239, 241, 0);
  border-width: 6px;
  margin-top: -6px;
}

.apexcharts-yaxistooltip:before {
  border-color: rgba(144, 164, 174, 0);
  border-width: 7px;
  margin-top: -7px;
}

.apexcharts-yaxistooltip-left:after,
.apexcharts-yaxistooltip-left:before {
  left: 100%;
}

.apexcharts-yaxistooltip-right:after,
.apexcharts-yaxistooltip-right:before {
  right: 100%;
}

.apexcharts-yaxistooltip-left:after {
  border-left-color: #ECEFF1;
}

.apexcharts-yaxistooltip-left:before {
  border-left-color: #90A4AE;
}

.apexcharts-yaxistooltip-left.apexcharts-theme-dark:after {
  border-left-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-yaxistooltip-left.apexcharts-theme-dark:before {
  border-left-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-yaxistooltip-right:after {
  border-right-color: #ECEFF1;
}

.apexcharts-yaxistooltip-right:before {
  border-right-color: #90A4AE;
}

.apexcharts-yaxistooltip-right.apexcharts-theme-dark:after {
  border-right-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-yaxistooltip-right.apexcharts-theme-dark:before {
  border-right-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-yaxistooltip.apexcharts-active {
  opacity: 1;
}

.apexcharts-yaxistooltip-hidden {
  display: none;
}

.apexcharts-xcrosshairs,
.apexcharts-ycrosshairs {
  pointer-events: none;
  opacity: 0;
  transition: 0.15s ease all;
}

.apexcharts-xcrosshairs.apexcharts-active,
.apexcharts-ycrosshairs.apexcharts-active {
  opacity: 1;
  transition: 0.15s ease all;
}

.apexcharts-ycrosshairs-hidden {
  opacity: 0;
}

.apexcharts-selection-rect {
  cursor: move;
}

.svg_select_boundingRect, .svg_select_points_rot {
  pointer-events: none;
  opacity: 0;
  visibility: hidden;
}
.apexcharts-selection-rect + g .svg_select_boundingRect,
.apexcharts-selection-rect + g .svg_select_points_rot {
  opacity: 0;
  visibility: hidden;
}

.apexcharts-selection-rect + g .svg_select_points_l,
.apexcharts-selection-rect + g .svg_select_points_r {
  cursor: ew-resize;
  opacity: 1;
  visibility: visible;
}

.svg_select_points {
  fill: #efefef;
  stroke: #333;
  rx: 2;
}

.apexcharts-svg.apexcharts-zoomable.hovering-zoom {
  cursor: crosshair
}

.apexcharts-svg.apexcharts-zoomable.hovering-pan {
  cursor: move
}

.apexcharts-zoom-icon,
.apexcharts-zoomin-icon,
.apexcharts-zoomout-icon,
.apexcharts-reset-icon,
.apexcharts-pan-icon,
.apexcharts-selection-icon,
.apexcharts-menu-icon,
.apexcharts-toolbar-custom-icon {
  cursor: pointer;
  width: 20px;
  height: 20px;
  line-height: 24px;
  color: #6E8192;
  text-align: center;
}

.apexcharts-zoom-icon svg,
.apexcharts-zoomin-icon svg,
.apexcharts-zoomout-icon svg,
.apexcharts-reset-icon svg,
.apexcharts-menu-icon svg {
  fill: #6E8192;
}

.apexcharts-selection-icon svg {
  fill: #444;
  transform: scale(0.76)
}

.apexcharts-theme-dark .apexcharts-zoom-icon svg,
.apexcharts-theme-dark .apexcharts-zoomin-icon svg,
.apexcharts-theme-dark .apexcharts-zoomout-icon svg,
.apexcharts-theme-dark .apexcharts-reset-icon svg,
.apexcharts-theme-dark .apexcharts-pan-icon svg,
.apexcharts-theme-dark .apexcharts-selection-icon svg,
.apexcharts-theme-dark .apexcharts-menu-icon svg,
.apexcharts-theme-dark .apexcharts-toolbar-custom-icon svg {
  fill: #f3f4f5;
}

.apexcharts-canvas .apexcharts-zoom-icon.apexcharts-selected svg,
.apexcharts-canvas .apexcharts-selection-icon.apexcharts-selected svg,
.apexcharts-canvas .apexcharts-reset-zoom-icon.apexcharts-selected svg {
  fill: #008FFB;
}

.apexcharts-theme-light .apexcharts-selection-icon:not(.apexcharts-selected):hover svg,
.apexcharts-theme-light .apexcharts-zoom-icon:not(.apexcharts-selected):hover svg,
.apexcharts-theme-light .apexcharts-zoomin-icon:hover svg,
.apexcharts-theme-light .apexcharts-zoomout-icon:hover svg,
.apexcharts-theme-light .apexcharts-reset-icon:hover svg,
.apexcharts-theme-light .apexcharts-menu-icon:hover svg {
  fill: #333;
}

.apexcharts-selection-icon,
.apexcharts-menu-icon {
  position: relative;
}

.apexcharts-reset-icon {
  margin-left: 5px;
}

.apexcharts-zoom-icon,
.apexcharts-reset-icon,
.apexcharts-menu-icon {
  transform: scale(0.85);
}

.apexcharts-zoomin-icon,
.apexcharts-zoomout-icon {
  transform: scale(0.7)
}

.apexcharts-zoomout-icon {
  margin-right: 3px;
}

.apexcharts-pan-icon {
  transform: scale(0.62);
  position: relative;
  left: 1px;
  top: 0px;
}

.apexcharts-pan-icon svg {
  fill: #fff;
  stroke: #6E8192;
  stroke-width: 2;
}

.apexcharts-pan-icon.apexcharts-selected svg {
  stroke: #008FFB;
}

.apexcharts-pan-icon:not(.apexcharts-selected):hover svg {
  stroke: #333;
}

.apexcharts-toolbar {
  position: absolute;
  z-index: 11;
  max-width: 176px;
  text-align: right;
  border-radius: 3px;
  padding: 0px 6px 2px 6px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.apexcharts-menu {
  background: #fff;
  position: absolute;
  top: 100%;
  border: 1px solid #ddd;
  border-radius: 3px;
  padding: 3px;
  right: 10px;
  opacity: 0;
  min-width: 110px;
  transition: 0.15s ease all;
  pointer-events: none;
}

.apexcharts-menu.apexcharts-menu-open {
  opacity: 1;
  pointer-events: all;
  transition: 0.15s ease all;
}

.apexcharts-menu-item {
  padding: 6px 7px;
  font-size: 12px;
  cursor: pointer;
}

.apexcharts-theme-light .apexcharts-menu-item:hover {
  background: #eee;
}

.apexcharts-theme-dark .apexcharts-menu {
  background: rgba(0, 0, 0, 0.7);
  color: #fff;
}

@media screen and (min-width: 768px) {
  .apexcharts-canvas:hover .apexcharts-toolbar {
    opacity: 1;
  }
}

.apexcharts-datalabel.apexcharts-element-hidden {
  opacity: 0;
}

.apexcharts-pie-label,
.apexcharts-datalabels,
.apexcharts-datalabel,
.apexcharts-datalabel-label,
.apexcharts-datalabel-value {
  cursor: default;
  pointer-events: none;
}

.apexcharts-pie-label-delay {
  opacity: 0;
  animation-name: opaque;
  animation-duration: 0.3s;
  animation-fill-mode: forwards;
  animation-timing-function: ease;
}

.apexcharts-canvas .apexcharts-element-hidden {
  opacity: 0;
}

.apexcharts-hide .apexcharts-series-points {
  opacity: 0;
}

.apexcharts-gridline,
.apexcharts-annotation-rect,
.apexcharts-tooltip .apexcharts-marker,
.apexcharts-area-series .apexcharts-area,
.apexcharts-line,
.apexcharts-zoom-rect,
.apexcharts-toolbar svg,
.apexcharts-area-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,
.apexcharts-line-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,
.apexcharts-radar-series path,
.apexcharts-radar-series polygon {
  pointer-events: none;
}


/* markers */

.apexcharts-marker {
  transition: 0.15s ease all;
}

@keyframes opaque {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}


/* Resize generated styles */

@keyframes resizeanim {
  from {
    opacity: 0;
  }
  to {
    opacity: 0;
  }
}

.resize-triggers {
  animation: 1ms resizeanim;
  visibility: hidden;
  opacity: 0;
}

.resize-triggers,
.resize-triggers>div,
.contract-trigger:before {
  content: " ";
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  overflow: hidden;
}

.resize-triggers>div {
  background: #eee;
  overflow: auto;
}

.contract-trigger:before {
  width: 200%;
  height: 200%;
}
.tab {
  overflow: hidden;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  border: none;
  outline: none;
  cursor: pointer;
  color: #899bbd;
}

/* Style the tab content */
.tabcontent {
  display: none;
  border-top: none;
}
.tabcontent1 {
  display: none;
  border-top: none;
}
.tabcontent2 {
  display: none;
  border-top: none;
}
.tabcontent3 {
  display: none;
  border-top: none;
}
.tabcontent4 {
  display: none;
  border-top: none;
}
.tabcontent5 {
  display: none;
  border-top: none;
}
</style></head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center header-scrolled">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">NiceAdmin</span>
      </a>
      
    </div><!-- End Logo -->

    <!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <!-- End Search Icon-->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">4</span>
          </a><!-- End Notification Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications" style="">
            <li class="dropdown-header">
              You have 4 new notifications
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-exclamation-circle text-warning"></i>
              <div>
                <h4>Lorem Ipsum</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>30 min. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-x-circle text-danger"></i>
              <div>
                <h4>Atque rerum nesciunt</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>1 hr. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-check-circle text-success"></i>
              <div>
                <h4>Sit rerum fuga</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>2 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-info-circle text-primary"></i>
              <div>
                <h4>Dicta reprehenderit</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>4 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>
            <li class="dropdown-footer">
              <a href="#">Show all notifications</a>
            </li>

          </ul><!-- End Notification Dropdown Items -->

        </li><!-- End Notification Nav -->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success badge-number">3</span>
          </a><!-- End Messages Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages" style="">
            <li class="dropdown-header">
              You have 3 new messages
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-1.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Maria Hudson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>4 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-2.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Anna Nelson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>6 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-3.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>David Muldon</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>8 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="dropdown-footer">
              <a href="#">Show all messages</a>
            </li>

          </ul><!-- End Messages Dropdown Items -->

        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="assets/img/profile-img.png" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $name; ?></span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile" style="">
            <li class="dropdown-header">
              <h6><?php echo $name; ?></h6>
              <span>Publisher</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-gear"></i>
                <span>Account Settings</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->


  <main id="main" class="main" style="
    margin-left: 0px;
">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row" style="justify-content: center;">

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">

            

            <!-- Recent Sales -->
            	  <div class="card-body">
              <!-- Bordered Tabs -->
			  <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Results</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
				$host = 'localhost';
				$db   = 'topadn6_project';
				$user = 'root';
				$pass = '';
				$charset = 'utf8mb4';

				$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
				$options = [
					PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
					PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
					PDO::ATTR_EMULATE_PREPARES   => false,
				];
				try {
					 $pdo = new PDO($dsn, $user, $pass, $options);
				} catch (\PDOException $e) {
					 throw new \PDOException($e->getMessage(), (int)$e->getCode());
				}
				
				$id = 353;
				$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
				$stmt->execute([$id]);
				$data = $stmt->fetchAll();
				if ($data){
					foreach ($data as $da){
						$name = $da["fullname"];
						$active = $da["active"];
						$advred = $da["redirect"];
					}
				}
				
				$payment = 1;
				$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE payment = ?');
				$stmt->execute([$payment]);
				$data = $stmt->fetchAll();
				if (($data)==0){
					echo "No results yet.";
				}else{
					echo"<thead>
					<tr>
					<th scope=\"col\" style=\"width: 12.5%;\">id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">adv id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Campaign title</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Views</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Clicks</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Budget</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Spent</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Remains</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Status</th>
					</tr>
                    </thead>
                    <tbody>";
					foreach ($data as $ad){
						$day = date("j");
						$mon = date("F");
						$year = date("Y");
						$adid = $ad["id"];
						$budget = $ad["budget"];
						$spent = $ad['spent'];
						$remains = $ad["remains"];
						$adred = $ad["redirect"];
						$views = $ad["views"];
						$clicks = $ad["clicks"];
						?>
					<tr>
						<td><?= htmlspecialchars($ad['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['adv_id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['campaign_name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						$views_result = 0;
						$json0 = json_encode($views);
						$json = json_decode($views);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$views_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($views_result), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?php
						$clicks_result = 0;
						$json0 = json_encode($clicks);
						$json = json_decode($clicks);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$clicks_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($clicks_result), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?= htmlspecialchars(number_format($ad['budget']), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						$spent_result = 0;
						$json0 = json_encode($spent);
						$json = json_decode($spent);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$spent_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($spent_result, 2), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?php echo htmlspecialchars(number_format($remains, 2), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						 	if ($ad['status']=='0'){
							echo '<span class="badge bg-warning">Pending</span>';}
							if ($ad['status']=='1'){
							echo '<span class="badge bg-success">Running</span>';}
							if ($ad['status']=='2'){
							echo '<span class="badge bg-primary">Finished</span>';}
							if ($ad['status']=='3'){
							echo '<span class="badge bg-info">Paused</span>';}
							if ($ad['status']=='4'){
							echo '<span class="badge bg-secondary">Stopped</span>';}
							if ($ad['status']=='5'){
							echo '<span class="badge bg-danger">Rejected</span>';}
						 ?>
						 
						 </td>
						 </tr>
						 <?php           
							}
						}
				?>
						 </tbody>
                  </table>
				  </div>
				  </div>
                </div>
            </div>
              <!-- Bordered Tabs -->
			  <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Stopped</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
				
				$status = 4;				
				$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE payment = ? AND status = ?');
				$stmt->execute([$payment, $status]);
				$data = $stmt->fetchAll();
				
				if (($data)==0){
					echo "No results yet.";
				}else{
					echo"<thead>
					<tr><th scope=\"col\" style=\"width: 12.5%;\">id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">adv id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Campaign title</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Views</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Clicks</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Budget</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Spent</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Remains</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Status</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Paid</th>
					</tr>
                    </thead>
                    <tbody>";
					foreach ($data as $ad){
						$day = date("j");
						$mon = date("F");
						$year = date("Y");
						$adid = $ad["id"];
						$budget = $ad["budget"];
						$spent = $ad['spent'];
						$remains = $ad["remains"];
						$adred = $ad["redirect"];
						$views = $ad["views"];
						$clicks = $ad["clicks"];
						?>
						<tr>
						<td><?= htmlspecialchars($ad['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['adv_id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['campaign_name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						$views_result = 0;
						$json0 = json_encode($views);
						$json = json_decode($views);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$views_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($views_result), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?php
						$clicks_result = 0;
						$json0 = json_encode($clicks);
						$json = json_decode($clicks);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$clicks_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($clicks_result), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?= htmlspecialchars(number_format($ad['budget']), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						$spent_result = 0;
						$json0 = json_encode($spent);
						$json = json_decode($spent);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$spent_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($spent_result, 2), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?php echo htmlspecialchars(number_format($remains, 2), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						 	if ($ad['status']=='4'){
							echo '<span class="badge bg-secondary">Stopped</span>';}
						 ?>
						 
						 </td>
						 <td><?php
						 	if ($ad['paid']=='0'){
							echo "<a href=\"paid.php?a=$adred&r=$advred\"><span class=\"badge bg-warning\">Not yet.</span></a>";}
							if ($ad['paid']=='1'){
							echo '<span class="badge bg-success">Done</span>';}
						 ?>
						 
						 </td>
						 </tr>
						 <?php           
								}
							}				
						?>
						 </tbody>
                  </table>
				  </div>
				  </div>
                </div>
            </div>
			</div>
			<!-- End Recent Sales -->
              <!-- Bordered Tabs -->
			  <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Pending</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
				
				
				$status = 0;				
				$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE payment = ? AND status = ?');
				$stmt->execute([$payment, $status]);
				$data = $stmt->fetchAll();
				
				if (($data) < 1){
					echo "No results yet.";
				}else{
					echo"<thead>
					<tr><th scope=\"col\" style=\"width: 12.5%;\">id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">adv id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Campaign title</th>
					<th scope=\"col\" style=\"width: 12.5%;\">description</th>
					<th scope=\"col\" style=\"width: 12.5%;\">category</th>
					<th scope=\"col\" style=\"width: 12.5%;\">country</th>
					<th scope=\"col\" style=\"width: 12.5%;\">language</th>
					<th scope=\"col\" style=\"width: 12.5%;\">keywords</th>
					<th scope=\"col\" style=\"width: 12.5%;\">budget</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Images</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Status</th>
					</tr>
                    </thead>
                    <tbody>";
					foreach ($data as $ad){
						$day = date("j");
						$mon = date("F");
						$year = date("Y");
						$adid = $ad["id"];
						$image1 = $ad["image1"];
						$image2 = $ad["image2"];
						$image3 = $ad["image3"];
						$image4 = $ad["image4"];					
						$adred = $ad["redirect"];
						$size1 = $ad["size1"];
						$size2 = $ad["size2"];
						$size3 = $ad["size3"];
						$size4 = $ad["size4"];	
						?>
						<tr>
						<td><?= htmlspecialchars($ad['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['adv_id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['campaign_name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['description'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['category'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['country'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['language'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['keywords'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars(number_format($ad['budget']), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php if(!($size1) == 0){echo "<a href=\"../images/$image1\"><img style=\"width: 60%;\" src=\"../images/$image1\"\"></a><br><a href=\"delete.php?im=$image1&r=$adred\"><span class=\"badge bg-success\">Delete</span></a>";}
										if(!($size2) == 0){echo "<a href=\"../images/$image2\"><img style=\"width: 60%;\" src=\"../images/$image2\" class=\"img-thumbnail\" \"></a><br><a href=\"delete.php?im=$image2&r=$adred\"><span class=\"badge bg-success\">Delete</span></a>";}
										if(!($size3) == 0){echo "<a href=\"../images/$image3\"><img style=\"width: 60%;\" src=\"../images/$image3\" class=\"img-thumbnail\" \"></a><br><a href=\"delete.php?im=$image3&r=$adred\"><span class=\"badge bg-success\">Delete</span></a>";}
										if(!($size4) == 0){echo "<a href=\"../images/$image4\"><img style=\"width: 60%;\" src=\"../images/$image4\" class=\"img-thumbnail\" \"></a><br><a href=\"delete.php?im=$image4&r=$adred\"><span class=\"badge bg-success\">Delete</span></a>";}
															
									?></td>
						 <td><?php
							echo "<a href=\"accept.php?a=$adred&r=$advred\"><span class=\"badge bg-warning\">Accept</span></a><br>
							<a href=\"reject.php?a=$adred&r=$advred\"><span class=\"badge bg-warning\">Reject</span></a>";
						 ?></td>
						 </tr>
						 <?php           
				//}else{
				//	echo "Nothing posted yet";
			}
		}
				//}
				
				?>
						 </tbody>
                  </table></div></div>
                </div>
            </div>
			</div>

          </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
        <!-- End Right side columns -->

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer" style="">
    <div class="copyright">
      © Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center active"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/chart.js/chart.min.js"></script>
  <script src="../assets/vendor/echarts/echarts.min.js"></script>
  <script src="../assets/vendor/quill/quill.min.js"></script>
  <script src="../assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="../assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <script src="../assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script>
	function res(evt, item) {
	  var i, tabcontent, tablinks;
	  tabcontent = document.getElementsByClassName("tabcontent");
	  for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	  }
	  tablinks = document.getElementsByClassName("tablinks");
	  for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	  }
	  document.getElementById(item).style.display = "block";
	  evt.currentTarget.className += " active";
	}
	document.getElementById("today-main").click();
</script>
  <script>
	function res1(evt1, item1) {
	  var i, tabcontent1, tablinks1;
	  tabcontent1 = document.getElementsByClassName("tabcontent1");
	  for (i = 0; i < tabcontent1.length; i++) {
		tabcontent1[i].style.display = "none";
	  }
	  tablinks1 = document.getElementsByClassName("tablinks1");
	  for (i = 0; i < tablinks1.length; i++) {
		tablinks1[i].className = tablinks1[i].className.replace(" active", "");
	  }
	  document.getElementById(item1).style.display = "block";
	  evt1.currentTarget.className += " active";
	}
		document.getElementById("yesterday-main").click();
</script>
  <script>
	function res2(evt2, item2) {
	  var i, tabcontent2, tablinks2;
	  tabcontent2 = document.getElementsByClassName("tabcontent2");
	  for (i = 0; i < tabcontent2.length; i++) {
		tabcontent2[i].style.display = "none";
	  }
	  tablinks2 = document.getElementsByClassName("tablinks2");
	  for (i = 0; i < tablinks2.length; i++) {
		tablinks2[i].className = tablinks2[i].className.replace(" active", "");
	  }
	  document.getElementById(item2).style.display = "block";
	  evt2.currentTarget.className += " active";
	}
		document.getElementById("last-yesterday-main").click();
</script>
<script>
	function res3(evt3, item3) {
	  var i, tabcontent3, tablinks3;
	  tabcontent3 = document.getElementsByClassName("tabcontent3");
	  for (i = 0; i < tabcontent3.length; i++) {
		tabcontent3[i].style.display = "none";
	  }
	  tablinks3 = document.getElementsByClassName("tablinks3");
	  for (i = 0; i < tablinks3.length; i++) {
		tablinks3[i].className = tablinks3[i].className.replace(" active", "");
	  }
	  document.getElementById(item3).style.display = "block";
	  evt3.currentTarget.className += " active";
	}
		document.getElementById("this-week-main").click();
</script>
<script>
	function res4(evt4, item4) {
	  var i, tabcontent4, tablinks4;
	  tabcontent4 = document.getElementsByClassName("tabcontent4");
	  for (i = 0; i < tabcontent4.length; i++) {
		tabcontent4[i].style.display = "none";
	  }
	  tablinks4 = document.getElementsByClassName("tablinks4");
	  for (i = 0; i < tablinks4.length; i++) {
		tablinks4[i].className = tablinks4[i].className.replace(" active", "");
	  }
	  document.getElementById(item4).style.display = "block";
	  evt4.currentTarget.className += " active";
	}
		document.getElementById("this-month-main").click();
</script>
<script>
	function res5(evt5, item5) {
	  var i, tabcontent5, tablinks5;
	  tabcontent5 = document.getElementsByClassName("tabcontent5");
	  for (i = 0; i < tabcontent5.length; i++) {
		tabcontent5[i].style.display = "none";
	  }
	  tablinks5 = document.getElementsByClassName("tablinks5");
	  for (i = 0; i < tablinks5.length; i++) {
		tablinks5[i].className = tablinks5[i].className.replace(" active", "");
	  }
	  document.getElementById(item5).style.display = "block";
	  evt5.currentTarget.className += " active";
	}
		document.getElementById("total-main").click();
</script>
<script>
var options = {
          series: [
          {
            name: "Impressions",
            <?php echo "data: ". $impressions_array . "\n"; ?>
          },
          {
            name: "Clicks",
            <?php echo "data: ". $clicks_array . "\n"; ?>
          }
        ],
          chart: {
          height: 350,
          type: 'line',
          dropShadow: {
            enabled: true,
            color: '#000',
            top: 18,
            left: 7,
            blur: 10,
            opacity: 0.2
          },
          toolbar: {
            show: false
          }
        },
        colors: ['#77B6EA', '#198754'],
        dataLabels: {
          enabled: true,
        },
        stroke: {
          curve: 'smooth'
        },
        title: {
          text: '',
          align: 'left'
        },
        grid: {
          borderColor: '#e7e7e7',
          row: {
            colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
            opacity: 0.5
          },
        },
        markers: {
          size: 1
        },
        xaxis: {
          <?php echo "categories: ". $days_array . "\n"; ?>,
          title: {
            text: 'Day'
          }
        },
        
        legend: {
          position: 'top',
          horizontalAlign: 'right',
          floating: true,
          offsetY: -25,
          offsetX: -5
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();
</script>

<svg id="SvgjsSvg1145" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;"><defs id="SvgjsDefs1146"></defs><polyline id="SvgjsPolyline1147" points="0,0"></polyline><path id="SvgjsPath1148" d="M-1 270.7625L-1 270.7625C-1 270.7625 128.9170673076923 270.7625 128.9170673076923 270.7625C128.9170673076923 270.7625 214.86177884615384 270.7625 214.86177884615384 270.7625C214.86177884615384 270.7625 300.80649038461536 270.7625 300.80649038461536 270.7625C300.80649038461536 270.7625 386.7512019230769 270.7625 386.7512019230769 270.7625C386.7512019230769 270.7625 472.69591346153845 270.7625 472.69591346153845 270.7625C472.69591346153845 270.7625 558.640625 270.7625 558.640625 270.7625C558.640625 270.7625 558.640625 270.7625 558.640625 270.7625 "></path></svg><svg id="SvgjsSvg1145" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;"><defs id="SvgjsDefs1146"></defs><polyline id="SvgjsPolyline1147" points="0,0"></polyline><path id="SvgjsPath1148" d="M-1 270.7625L-1 270.7625C-1 270.7625 175.07091346153845 270.7625 175.07091346153845 270.7625C175.07091346153845 270.7625 291.7848557692308 270.7625 291.7848557692308 270.7625C291.7848557692308 270.7625 408.4987980769231 270.7625 408.4987980769231 270.7625C408.4987980769231 270.7625 525.2127403846154 270.7625 525.2127403846154 270.7625C525.2127403846154 270.7625 641.9266826923077 270.7625 641.9266826923077 270.7625C641.9266826923077 270.7625 758.640625 270.7625 758.640625 270.7625C758.640625 270.7625 758.640625 270.7625 758.640625 270.7625 "></path></svg></body></html>