<?php
require_once "../connect/connect.php";
/* if(isset($_SESSION['email'])){
		$email      =$_SESSION['email']; */
				
                $keywords  = array("SELECT", "UPDATE", "DELETE", "ORDER BY", "INSERT", "LIMIT", "UNION", "CASE", "GROUP BY", "WHERE", "select", "update", "delete", "order by", "insert", "limit", "union", "case", "group by", "where", "=", "*", ",");
				$replace = array("SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "", "", "");

				/*$id = $_GET['id'];*/
				/* pause.php?a=s8d7abd0n24sa4k&r=no9d7f8bd87a6 */
				$Ad_redirect = $_GET['a'];
				$Adv_redirect = $_GET['r'];
				/*$id = str_replace($keywords, $replace, $id);*/
				$Ad_redirect = str_replace($keywords, $replace, $Ad_redirect);
				$Adv_redirect = str_replace($keywords, $replace, $Adv_redirect);
				$stmt = $pdo->prepare('SELECT * FROM users WHERE redirect = ?');
				$stmt->execute([$Adv_redirect]);
				$data = $stmt->fetchAll();
				if ($data){
					foreach ($data as $row){
						$adv_id = $row["id"];
					}
					$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE redirect = ? AND adv_id= ?');
					$stmt->execute([$Ad_redirect, $adv_id]);
					$data = $stmt->fetchAll();
					if ($data){
						$paid = 1;
						$stmt = $pdo->prepare('UPDATE ads_normal SET paid = ? WHERE redirect = ?');
						$stmt->execute([$paid, $Ad_redirect]);
						$stmt->fetchAll();
						header("Location: ads.php");
						}
				}
				/*
				$sql2 = "SELECT * FROM users WHERE redirect='$Adv_redirect'";
				$result = $conn->query($sql2);

				if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
						$advertiserid = $row["id"];
					}
						//$sql = "SELECT * FROM ads_normal WHERE redirect='".$Ad_redirect."'";
						$sql = "SELECT * FROM ads_normal WHERE redirect='".$Ad_redirect."' AND adv_id='".$advertiserid."'";
						$result = $conn->query($sql);
						if ($result->num_rows > 0) {
								  while($row = $result->fetch_assoc()) {
							$sql0 = "UPDATE ads_normal SET paid = 1 WHERE redirect = '".$Ad_redirect."'";
							$conn->query($sql0);			
							header("Location: ads.php");
							//exit;
							$conn->close();



					}
				}
				
				
				}*/

?>