<?php
require_once "../connect/connect1.php";


$keywords  = array("SELECT", "UPDATE", "DELETE", "ORDER BY", "INSERT", "LIMIT", "UNION", "CASE", "GROUP BY", "WHERE", "select", "update", "delete", "order by", "insert", "limit", "union", "case", "group by", "where", "=", "*", ",");
$replace = array("SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "", "", "");

$Ad_im = $_GET['im'];
$Adv_redirect = $_GET['r'];

$Ad_im = str_replace($keywords, $replace, $Ad_im);
$Adv_redirect = str_replace($keywords, $replace, $Adv_redirect);	

$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE redirect = ?');
$stmt->execute([$Adv_redirect]);
$data = $stmt->fetchAll();
if ($data){
	for ($x = 1; $x <= 4; $x++) {
		$image = "image$x";
		$size = "size$x";
		$status = 4;
		$zero = 0;
		$empty = '';
		$stmt = $pdo->prepare("SELECT * FROM ads_normal WHERE redirect = ? and $image = ?");
		$stmt->execute([$Adv_redirect, $Ad_im]);
		$data = $stmt->fetchAll();
		if ($data){
			$stmt = $pdo->prepare("UPDATE ads_normal SET $size = ? and $image = ? WHERE redirect = ?");
			$stmt->execute([$zero, $empty, $Adv_redirect]);
			$stmt->fetchAll();
		}
	}
	header("Location: ads.php");
}
?>
