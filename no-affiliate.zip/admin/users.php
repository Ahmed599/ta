<?php include 'das-php.php';?>
<html lang="en"><head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.2.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
<style>
/* markers */

.apexcharts-marker {
  transition: 0.15s ease all;
}

@keyframes opaque {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}


/* Resize generated styles */

@keyframes resizeanim {
  from {
    opacity: 0;
  }
  to {
    opacity: 0;
  }
}

.resize-triggers {
  animation: 1ms resizeanim;
  visibility: hidden;
  opacity: 0;
}

.resize-triggers,
.resize-triggers>div,
.contract-trigger:before {
  content: " ";
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  overflow: hidden;
}

.resize-triggers>div {
  background: #eee;
  overflow: auto;
}

.contract-trigger:before {
  width: 200%;
  height: 200%;
}
.tab {
  overflow: hidden;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  border: none;
  outline: none;
  cursor: pointer;
  color: #899bbd;
}

/* Style the tab content */
.tabcontent {
  display: none;
  border-top: none;
}
.tabcontent1 {
  display: none;
  border-top: none;
}
.tabcontent2 {
  display: none;
  border-top: none;
}
.tabcontent3 {
  display: none;
  border-top: none;
}
.tabcontent4 {
  display: none;
  border-top: none;
}
.tabcontent5 {
  display: none;
  border-top: none;
}
</style></head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center header-scrolled">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">NiceAdmin</span>
      </a>
      
    </div><!-- End Logo -->

    <!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <!-- End Search Icon-->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">4</span>
          </a><!-- End Notification Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications" style="">
            <li class="dropdown-header">
              You have 4 new notifications
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-exclamation-circle text-warning"></i>
              <div>
                <h4>Lorem Ipsum</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>30 min. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-x-circle text-danger"></i>
              <div>
                <h4>Atque rerum nesciunt</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>1 hr. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-check-circle text-success"></i>
              <div>
                <h4>Sit rerum fuga</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>2 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-info-circle text-primary"></i>
              <div>
                <h4>Dicta reprehenderit</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>4 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>
            <li class="dropdown-footer">
              <a href="#">Show all notifications</a>
            </li>

          </ul><!-- End Notification Dropdown Items -->

        </li><!-- End Notification Nav -->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success badge-number">3</span>
          </a><!-- End Messages Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages" style="">
            <li class="dropdown-header">
              You have 3 new messages
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-1.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Maria Hudson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>4 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-2.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Anna Nelson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>6 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-3.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>David Muldon</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>8 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="dropdown-footer">
              <a href="#">Show all messages</a>
            </li>

          </ul><!-- End Messages Dropdown Items -->

        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="assets/img/profile-img.png" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $name; ?></span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile" style="">
            <li class="dropdown-header">
              <h6><?php echo $name; ?></h6>
              <span>Publisher</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-gear"></i>
                <span>Account Settings</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->


  <main id="main" class="main" style="
    margin-left: 0px;
">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row" style="justify-content: center;">

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">

            

            <!-- Recent Sales -->
            	  <div class="card-body">
              <!-- Bordered Tabs -->
			  			  <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Stopped</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
<?php
$host = 'localhost';
$db   = 'topadn6_project';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

$id = 353;
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$id]);
$data = $stmt->fetchAll();
if ($data){
	foreach ($data as $da){
		$name = $da["fullname"];
		$adid = $da["id"];
		$advred = $da["redirect"];
	}
}
						
$payment = 1;
$status = 4;
$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE payment = ? AND status = ?');
$stmt->execute([$payment, $status]);
$data = $stmt->fetchAll();
echo"<thead>
<tr>
<th scope=\"col\" style=\"width: 12.5%;\">id</th>
<th scope=\"col\" style=\"width: 12.5%;\">adv id</th>
<th scope=\"col\" style=\"width: 12.5%;\">Campaign title</th>
<th scope=\"col\" style=\"width: 12.5%;\">Views</th>
<th scope=\"col\" style=\"width: 12.5%;\">Clicks</th>
<th scope=\"col\" style=\"width: 12.5%;\">Budget</th>
<th scope=\"col\" style=\"width: 12.5%;\">Spent</th>
<th scope=\"col\" style=\"width: 12.5%;\">Remains</th>
<th scope=\"col\" style=\"width: 12.5%;\">Status</th>
<th scope=\"col\" style=\"width: 12.5%;\">Paid</th>
</tr>
</thead>
<tbody>";
if ($data){
	foreach ($data as $ad) {
		$day = date("j");
		$mon = date("F");
		$year = date("Y");
		$adid = $ad["id"];
		$budget = $ad["budget"];
		$spent = $ad['spent'];
		$remains = $ad["remains"];
		$adred = $ad["redirect"];
		$views = $ad["views"];
		$clicks = $ad["clicks"];
		?>
		<tr>
		<td><?= htmlspecialchars($ad['id'], ENT_QUOTES, 'UTF-8'); ?></td>
		<td><?= htmlspecialchars($ad['adv_id'], ENT_QUOTES, 'UTF-8'); ?></td>
		<td><?= htmlspecialchars($ad['campaign_name'], ENT_QUOTES, 'UTF-8'); ?></td>
		<td><?php
		$views_result = 0;
		$json0 = json_encode($views);
		$json = json_decode($views);
		for ($x = 0; $x <= 60; $x++) {
			$key = date('j',strtotime("-$x days"));
			$key2 = date('F',strtotime("-$x days"));
			$key3 = date('Y',strtotime("-$x days"));
			//$days_chart[] = $key;
			$views_result += $json->$key3->$key2->$key;
		}
		echo htmlspecialchars(number_format($views_result), ENT_QUOTES, 'UTF-8');
		?>
		</td>
		<td><?php
		$clicks_result = 0;
		$json0 = json_encode($clicks);
		$json = json_decode($clicks);
		for ($x = 0; $x <= 60; $x++) {
			$key = date('j',strtotime("-$x days"));
			$key2 = date('F',strtotime("-$x days"));
			$key3 = date('Y',strtotime("-$x days"));
			//$days_chart[] = $key;
			$clicks_result += $json->$key3->$key2->$key;
		}
		echo htmlspecialchars(number_format($clicks_result), ENT_QUOTES, 'UTF-8');
		?>
		</td>
		<td><?= htmlspecialchars(number_format($ad['budget']), ENT_QUOTES, 'UTF-8'); ?></td>
		<td><?php
		$spent_result = 0;
		$json0 = json_encode($spent);
		$json = json_decode($spent);
		for ($x = 0; $x <= 60; $x++) {
			$key = date('j',strtotime("-$x days"));
			$key2 = date('F',strtotime("-$x days"));
			$key3 = date('Y',strtotime("-$x days"));
			//$days_chart[] = $key;
			$spent_result += $json->$key3->$key2->$key;
		}
		echo htmlspecialchars(number_format($spent_result, 2), ENT_QUOTES, 'UTF-8');
		?>
		</td>
		<td><?php echo htmlspecialchars(number_format($remains, 2), ENT_QUOTES, 'UTF-8'); ?></td>
		<td><?php
			if ($ad['status']=='4'){
			echo '<span class="badge bg-secondary">Stopped</span>';}
		 ?>
		 
		 </td>
		 <td><?php
			if ($ad['paid']=='0'){
			echo "<a href=\"paid.php?a=$adred&r=$advred\"><span class=\"badge bg-warning\">Not yet.</span></a>";}
			if ($ad['paid']=='1'){
			echo '<span class="badge bg-success">Done</span>';}
		 ?>
		 
		 </td>
		 </tr>
		 <?php           
				//}else{
				//	echo "Nothing posted yet";
			}
		}
				//}
				
				?>
						 </tbody>
                  </table>
				  </div>
				  </div>
                </div>
            </div>
			
			  <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Blocked</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
			
				$active = 1;
				$blocked = 1;
				$stmt = $pdo->prepare('SELECT * FROM users WHERE active = ? AND blocked = ?');
				$stmt->execute([$active, $blocked]);
				$data = $stmt->fetchAll();
					echo"<thead>
					<tr>
					<th scope=\"col\" style=\"width: 12.5%;\">id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">fullname</th>
					<th scope=\"col\" style=\"width: 12.5%;\">email</th>
					<th scope=\"col\" style=\"width: 12.5%;\">country</th>
					<th scope=\"col\" style=\"width: 12.5%;\">type</th>
					<th scope=\"col\" style=\"width: 12.5%;\">more</th>
					</tr>
                    </thead>
                    <tbody>";
				if ($data){
					foreach ($data as $user){
						$day = date("j");
						$mon = date("F");
						$year = date("Y");
						$userid = $user["id"];
						$usered = $user["redirect"];
						?>
						<tr>
						<td><?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['fullname'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['country'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php if ($user['type']=='1'){ echo "<span style=\"color: #0000ff8c;font-weight: bold;\">Publisher</span>";
						}if ($user['type']=='2'){ echo "<span style=\"color: #ff000094;font-weight: bold;\">Advertiser</span>"; } ?>
						</td>
						 <td><?php if ($user['blocked']=='1'){
							 echo "<a href=\"unblock.php?r=$usered\"><span class=\"badge bg-success\">unblock</span></a><br>";
							 } ?>
						</td>
						 </tr>
						 <?php           
				//}else{
				//	echo "Nothing posted yet";
			}
		}
				//}
				
				?>
						 </tbody>
                  </table>
				  </div>
				  </div>
                </div>
            </div>
			
			  <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Advertisers</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
			   
				$active = 1;
				$type = 2;
				$blocked = 0;
				$stmt = $pdo->prepare('SELECT * FROM users WHERE active = ? AND type = ? AND blocked = ?');
				$stmt->execute([$active, $type, $blocked]);
				$data = $stmt->fetchAll();
				
					echo"<thead>
					<tr>
					<th scope=\"col\" style=\"width: 12.5%;\">id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">fullname</th>
					<th scope=\"col\" style=\"width: 12.5%;\">email</th>
					<th scope=\"col\" style=\"width: 12.5%;\">country</th>
					<th scope=\"col\" style=\"width: 12.5%;\">impressions</th>
					<th scope=\"col\" style=\"width: 12.5%;\">ads</th>
					<th scope=\"col\" style=\"width: 12.5%;\">more</th>
					</tr>
                    </thead>
                    <tbody>";
				if ($data){
					foreach ($data as $user){
						$day = date("j");
						$mon = date("F");
						$year = date("Y");
						$userid = $user["id"];
						$usered = $user["redirect"];
						//$json0 = json_encode($impressions);
						//$json = json_decode($impressions);
					?>
						<tr>
						<td><?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['fullname'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['country'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php 
						
							$total_impressions = 0;
							$now = time(); // or your date as well
							$your_date = strtotime("2022-01-01");
							$datediff = $now - $your_date;
							$final = round($datediff / (60 * 60 * 24));
							
							$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
							$stmt->execute([$userid]);
							$data = $stmt->fetchAll();
							if ($data){
								foreach ($data as $da){
										$impressions = $da['impressions_map'];
										$redirect = $da['redirect'];
										$redirect = htmlspecialchars($redirect, ENT_QUOTES, 'UTF-8');
									}
									$json0 = json_encode($impressions);
									$json = json_decode($impressions);		
									
									/* $x sould be difference between today and 01/01/2022 */
									
									//echo $final;
									
									for ($x = 0; $x <= $final; $x++) {
										
										$daytot = date('j',strtotime("-$x days"));
										$montot = date('F',strtotime("-$x days"));
										$yeartot = date('Y',strtotime("-$x days"));
										$total_impressions += $json->$yeartot->$montot->$daytot;
										}
									
							if ($total_impressions > 0){
									echo htmlspecialchars($total_impressions, ENT_QUOTES, 'UTF-8');
							}else{
								echo "";
							}
							?></td>
						<?php
							$ids = array();
							$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE adv_id = ?');
							$stmt->execute([$userid]);
							$data = $stmt->fetchAll();
							if ($data > 0){
								foreach ($data as $da){
										//$ids[] = $da['id'];
										//$comma = ',';
										$ids[] += $da['id'];
										//$ids += $ids . ',';
										//$ids += ',' . '$ids';
										//$ids += implode(",", $da['id']);
										
									}
									//$ids = var_dump(implode(",", $ids));
									$ids = htmlspecialchars(implode(",", $ids), ENT_QUOTES, 'UTF-8');
									?>
							<td><span><?= $ids;
							
							//print_r (explode(",", $ids));
								//htmlspecialchars($redirect, ENT_QUOTES, 'UTF-8');							
							?></span></td>
							<?php		
								}else{echo ""; }
								?>
							<td><?php echo "<a href=\"block.php?r=$redirect\"><span class=\"badge bg-danger\">block</span></a><br>"; ?></td>
						 </tr>
						 <?php           
				//}else{
				//	echo "Nothing posted yet";
			}
		}
		
				}
				
				?>
						 </tbody>
                  </table>
				  </div>
				  </div>
                </div>
            </div>
			
			 <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Publishers</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
			   
				$active = 1;
				$type = 1;
				$blocked = 0;
				$stmt = $pdo->prepare('SELECT * FROM users WHERE active = ? AND type = ? AND blocked = ?');
				$stmt->execute([$active, $type, $blocked]);
				$data = $stmt->fetchAll();
				
					echo"<thead>
					<tr>
					<th scope=\"col\" style=\"width: 12.5%;\">id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">fullname</th>
					<th scope=\"col\" style=\"width: 12.5%;\">email</th>
					<th scope=\"col\" style=\"width: 12.5%;\">country</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Views</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Impressions</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Clicks</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Views/Impressions</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Clicks/Impressions</th>
					<th scope=\"col\" style=\"width: 12.5%;\">more</th>
					</tr>
                    </thead>
                    <tbody>";
					if ($data){
					foreach ($data as $user){
						$day = date("j");
						$mon = date("F");
						$year = date("Y");
						$adid = $user["id"];
						$adred = $user["redirect"];
						$views = $user["coming_views"];
						$impressions = $user["coming_imps"];
						$clicks = $user["coming_clicks"];
						if ($clicks > 0){
							$viewpressions = ($views / $impressions * 100);
							$clickpressions = ($clicks / $impressions * 100);
							//<?php echo ('%' . number_format($clickpressions, 2));
						?>
						<tr>
						<td><?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['fullname'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['country'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['coming_views'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['coming_imps'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['coming_clicks'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars(('% ' . number_format($viewpressions, 1)), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars(('% ' . number_format($clickpressions, 1)), ENT_QUOTES, 'UTF-8'); ?></td>
						 <td><?php echo "<a href=\"block.php?r=$adred\"><span class=\"badge bg-danger\">block</span></a><br>"; ?></td>
						 </tr>
						 <?php           
				//}else{
				//	echo "Nothing posted yet";
			}
		}
				}
				
				?>
						 </tbody>
                  </table>
				  </div>
				  </div>
                </div>
            </div>
              <!-- Bordered Tabs -->
			</div>
			<!-- End Recent Sales -->
              <!-- Bordered Tabs -->
			  <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Pending</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
				$payment = 1;
				$status = 0;
				$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE payment = ? AND status = ?');
				$stmt->execute([$payment, $status]);
				$data = $stmt->fetchAll();
			
					echo"<thead><tr><th scope=\"col\" style=\"width: 12.5%;\">id</th><th scope=\"col\" style=\"width: 12.5%;\">adv id</th><th scope=\"col\" style=\"width: 12.5%;\">Campaign title</th><th scope=\"col\" style=\"width: 12.5%;\">description</th><th scope=\"col\" style=\"width: 12.5%;\">category</th><th scope=\"col\" style=\"width: 12.5%;\">country</th><th scope=\"col\" style=\"width: 12.5%;\">language</th><th scope=\"col\" style=\"width: 12.5%;\">keywords</th><th scope=\"col\" style=\"width: 12.5%;\">budget</th><th scope=\"col\" style=\"width: 12.5%;\">Images</th><th scope=\"col\" style=\"width: 12.5%;\">Status</th></tr>
                    </thead>
                    <tbody>";
				if ($data){
					foreach ($data as $ad){
						$day = date("j");
						$mon = date("F");
						$year = date("Y");
						$adid = $ad["id"];
						$image1 = $ad["image1"];
						$image2 = $ad["image2"];
						$image3 = $ad["image3"];
						$image4 = $ad["image4"];
						$size1 = $ad["size1"];
						$size2 = $ad["size2"];
						$size3 = $ad["size3"];
						$size4 = $ad["size4"];
						$adred = $ad["redirect"];
						?>
						<tr>
						<td><?= htmlspecialchars($ad['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['adv_id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['campaign_name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['description'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['category'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['country'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['language'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['keywords'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars(number_format($ad['budget']), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php if(!($size1) == 0){echo "<img style=\"width: 60%;\" src=\"../images/$image1\"];\"><br>";}
										if(!($size2) == 0){echo "<img style=\"width: 60%;\" src=\"../images/$image2\" class=\"img-thumbnail\" \"><br>";}
										if(!($size3) == 0){echo "<img style=\"width: 60%;\" src=\"../images/$image3\" class=\"img-thumbnail\" \"><br>";}
										if(!($size4) == 0){echo "<img style=\"width: 60%;\" src=\"../images/$image4\" class=\"img-thumbnail\" \">";}
									?></td>
									
									
									
									
										
										
										
						 <td><?php
							echo "<a href=\"accept.php?a=$adred&r=$advred\"><span class=\"badge bg-warning\">Accept</span></a><br>
							<a href=\"reject.php?a=$adred&r=$advred\"><span class=\"badge bg-warning\">Reject</span></a>";
						 ?></td>
						 </tr>
						 <?php           
				//}else{
				//	echo "Nothing posted yet";
			}
		}
				//}
				
				?>
						 </tbody>
                  </table></div></div>
                </div>
            </div>
			</div>

          </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
        <!-- End Right side columns -->

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer" style="">
    <div class="copyright">
      © Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center active"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/chart.js/chart.min.js"></script>
  <script src="../assets/vendor/echarts/echarts.min.js"></script>
  <script src="../assets/vendor/quill/quill.min.js"></script>
  <script src="../assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="../assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <script src="../assets/vendor/apexcharts/apexcharts.min.js"></script>

<svg id="SvgjsSvg1145" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;"><defs id="SvgjsDefs1146"></defs><polyline id="SvgjsPolyline1147" points="0,0"></polyline><path id="SvgjsPath1148" d="M-1 270.7625L-1 270.7625C-1 270.7625 128.9170673076923 270.7625 128.9170673076923 270.7625C128.9170673076923 270.7625 214.86177884615384 270.7625 214.86177884615384 270.7625C214.86177884615384 270.7625 300.80649038461536 270.7625 300.80649038461536 270.7625C300.80649038461536 270.7625 386.7512019230769 270.7625 386.7512019230769 270.7625C386.7512019230769 270.7625 472.69591346153845 270.7625 472.69591346153845 270.7625C472.69591346153845 270.7625 558.640625 270.7625 558.640625 270.7625C558.640625 270.7625 558.640625 270.7625 558.640625 270.7625 "></path></svg><svg id="SvgjsSvg1145" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;"><defs id="SvgjsDefs1146"></defs><polyline id="SvgjsPolyline1147" points="0,0"></polyline><path id="SvgjsPath1148" d="M-1 270.7625L-1 270.7625C-1 270.7625 175.07091346153845 270.7625 175.07091346153845 270.7625C175.07091346153845 270.7625 291.7848557692308 270.7625 291.7848557692308 270.7625C291.7848557692308 270.7625 408.4987980769231 270.7625 408.4987980769231 270.7625C408.4987980769231 270.7625 525.2127403846154 270.7625 525.2127403846154 270.7625C525.2127403846154 270.7625 641.9266826923077 270.7625 641.9266826923077 270.7625C641.9266826923077 270.7625 758.640625 270.7625 758.640625 270.7625C758.640625 270.7625 758.640625 270.7625 758.640625 270.7625 "></path></svg></body></html>