<?php

include '../connect/connect.php';

//$keywords  = array("SELECT", "UPDATE", "DELETE", "ORDER BY", "INSERT", "LIMIT", "UNION", "CASE", "GROUP BY", "WHERE", "select", "update", "delete", "order by", "insert", "limit", "union", "case", "group by", "where", "=", "*", ",");
//$replace = array("SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "", "", "");

//$Ad_redirect = $_GET['a'];
$redirect = $_GET['r'];
$code = $_GET['c'];

//$Ad_redirect = str_replace($keywords, $replace, $Ad_redirect);
//$redirect = str_replace($keywords, $replace, $redirect);		

$stmt = $pdo->prepare('SELECT * FROM users WHERE redirect = ? AND code = ?');
$stmt->execute([$redirect, $code]);
$data = $stmt->fetchAll();
if ($data){
						$coming_payment = 0;
						$stmt = $pdo->prepare('UPDATE users SET coming_payment = ? WHERE redirect = ? AND code = ?');
						$stmt->execute([$coming_payment, $redirect, $code]);
						//$stmt->fetchAll();
						$coming_payment = 0;
						$stmt = $pdo->prepare('UPDATE users SET coming_imps = ? WHERE redirect = ? AND code = ?');
						$stmt->execute([$coming_payment, $redirect, $code]);
						//$stmt->fetchAll();
						$coming_payment = 0;
						$stmt = $pdo->prepare('UPDATE users SET coming_views = ? WHERE redirect = ? AND code = ?');
						$stmt->execute([$coming_payment, $redirect, $code]);
						//$stmt->fetchAll();
						$coming_payment = 0;
						$stmt = $pdo->prepare('UPDATE users SET coming_clicks = ? WHERE redirect = ? AND code = ?');
						$stmt->execute([$coming_payment, $redirect, $code]);
						//$stmt->fetchAll();
						header("Location: payments.php");
				}

?>
