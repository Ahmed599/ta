<html lang="en">
<head>
<meta charset="UTF-8">
<title>Contact Us - Topad.net</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style class="INLINE_PEN_STYLESHEET_ID"> body {
}
.footer {
  background-color: #ffffff;
}

.footer .social {
  text-align: center;
  padding-bottom: 25px;
  color: #4b4c4d;
}

.footer .social a {
  font-size: 24px;
  color: inherit;
  border: 1px solid #ccc;
  width: 40px;
  height: 40px;
  line-height: 38px;
  display: inline-block;
  text-align: center;
  border-radius: 50%;
  margin: 0 8px;
  opacity: 0.75;
}

.footer .social a:hover {
  opacity: 0.9;
}

.footer ul {
  margin-top: 0;
  padding: 0;
  list-style: none;
  text-align: center;
  font-size: 15px;
  line-height: 1.6;
  margin-bottom: 0;
}

.footer ul a {
  color: inherit;
  text-decoration: none;
  opacity: 0.8;
}

.footer ul li {
  display: inline-block;
  padding: 0 15px;
}

.footer ul a:hover {
  opacity: 1;
}

.footer .copyright {
  margin-top: 15px;
  text-align: center;
  font-size: 13px;
  color: #aaa;
}
p {
    margin-top: 0rem;
    margin-bottom: 0rem;
}
a { color: #000;
text-decoration: auto;
}
a:hover, a:active, a:focus { color:#000;
}
@-webkit-keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
@keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
h1 { font-size: 3em; font-weight: bold;
}
h3 { display: block; font-size: 1.5em; margin-left: 0; margin-right: 0; font-weight: bold;
}
.h-100 { height: 83%!important;
}
.text-white {
    color: #6a6e72!important;
}
.cent {
    margin-top: 2rem!important;
    margin-bottom: 2rem!important;
}
.bottom {
font-size: 0.8rem;
color: #6a6e72;
text-decoration: auto;
}
  </style>
<div class="header">
<a href="../" style="float: left;"><h2 class="fw-light m-3" style="color: #559ade; font-size: 2rem;">TopAd</h2></a>
</div>
</div> 
<div class="d-flex flex-column justify-content-center w-100 h-100" 
style="align-items: center;"> <div class="d-flex flex-column justify-content-center 
align-items-center" style="text-align: center; max-width: 850px;">
<h1 class="fw-light text-white m-3" style="text-align: -webkit-center;">Contact Us</h1>
<br>
<h5 class="text-white m-2" style="font-weight: 400;">Your satisfaction is our mission. </h5>
<h5 class="fw-light text-white m-2">Reach us on <b>contact-us@topad.net</b>.</h5></div>
</div>
<section class="footer">
      <ul class="list">
        <li>
          <a href="../how-it-works/">How it works</a>
        </li>
        <li>
          <a href="../pricing/">Pricing</a>
        </li>
        <li>
          <a href="../contact-us/">Contact us</a>
        </li>
        <li>
          <a href="../about/">About</a>
        </li>
      </ul>
<p class="copyright">Topad.net © <?php echo date("Y"); ?></p>
    </section>
</body></html>