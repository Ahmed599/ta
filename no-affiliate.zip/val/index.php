<?php
                $servername = "127.0.0.1:3306";
                $username = "root";
                $password = "wpH35AZ1Lv3@";
                $dbname = "topadn6_project";
				
                $keywords  = array("SELECT", "UPDATE", "DELETE", "ORDER BY", "INSERT", "LIMIT", "UNION", "CASE", "GROUP BY", "WHERE", "select", "update", "delete", "order by", "insert", "limit", "union", "case", "group by", "where", "=", "*", ",");
				$replace = array("SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "", "", "");

				/*$id = $_GET['id'];*/
				/* pause.php?a=s8d7abd0n24sa4k&r=no9d7f8bd87a6 */
				$Ad_redirect = $_GET['a'];
				$adv_id = $_GET['r'];
				/*$id = str_replace($keywords, $replace, $id);*/
				function test_input($data) {
				  $data = trim($data);
				  $data = stripslashes($data);
				  $data = htmlspecialchars($data);
				  return $data;
				}
				$Ad_redirect = test_input($_GET['a']);
				$adv_id = test_input($_GET['r']);
				$Ad_redirect = str_replace($keywords, $replace, $Ad_redirect);
				$adv_id = str_replace($keywords, $replace, $adv_id);		
                
				$conn = new PDO('mysql:host=127.0.0.1:3306;dbname=topadn6_project', 'root', 'wpH35AZ1Lv3@');

				$sql = 'UPDATE ads_normal SET payment = 1 WHERE redirect = :redirect AND adv_id = :adv_id';
				$stmt = $conn->prepare($sql);

				// Bind the parameters
				$stmt->bindParam(':redirect', $Ad_redirect);
				$stmt->bindParam(':adv_id', $adv_id);

				// Execute the statement
				$stmt->execute();

				// Close the statement
				$stmt->close();

				// Close the database connection
				$conn = null;

				// Redirect to the success page
				header('Location: ../');
					

?>
