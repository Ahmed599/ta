<html lang="en"><head>
<meta charset="UTF-8">
<title>How It Works - Topad.net</title>
<meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style class="INLINE_PEN_STYLESHEET_ID"> body {
}
p {
    margin-top: 0rem;
    margin-bottom: 0rem;
}
a { color: #000;
text-decoration: auto;
}
a:hover, a:active, a:focus { color:#000;
}
@-webkit-keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
@keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
h1 { font-size: 3em; font-weight: bold;
}
h3 { display: block; font-size: 1.5em; margin-left: 0; margin-right: 0; font-weight: bold;
}
.h-100 { height: 83%!important;
}
.text-white {
    color: #6a6e72!important;
}
.cent {
    margin-top: 2rem!important;
    margin-bottom: 2rem!important;
}
.bottom {
font-size: 0.8rem;
color: #6a6e72;
text-decoration: auto;
}
</style>
</head>
<body>
<div class="header">
<a href="../" style="float: left;"><h2 class="fw-light m-3" style="color: #559ade; font-size: 2rem;">TopAd</h2></a>
</div>
<div class="d-flex flex-column justify-content-center w-100" style="align-items: center;">
<div class="d-flex flex-column justify-content-center align-items-center" style="max-width: 850px;">
<h2 class="fw-light text-white m-3" style="text-align: -webkit-center;font-size: 2.2rem;">How It Works</h2>
<br>
<h5 class="text-white m-2" style="font-weight: 300;text-align: center;background-color: aliceblue;">
A business owner (Advertiser) wants to advertise his products, so he creates an account on TopAd and posts his ads to show for millions of targeted potential customers.</h5>

<h5 class="text-white m-2" style="font-weight: 300;text-align: center;background-color: whitesmoke;">
On the other side, A website owner (Publisher) who wants to make more profit from his website puts a custom script (that shows ads to his visitors in a banner size he selects) given by TopAd in his website source code
so he can get paid when ads are shown to his website visitors or when get clicked.
</h5>
<br>
<div style="display: inline;max-width: 1000px;">
<div class="grid-margin stretch-card" style="padding: 10px;">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title" style="background-color: aliceblue; max-width: 167px;">For advertisers:</h4>
                  <ul>
                    <li>The Advertiser pays when posting his ad using PayPal.</li>
                    <li>He can set parameters like locations, categories and keywords to help targeting the right publishers and customers.</li>
                    <li>He can pause or stop his ad campaign in any time.</li>
                    <li>Once his ad campaign is stopped he gets the rest of his money back within 48 working hours.</li>
                    <li>All statistics and tools needed to follow up the advertising process are included.</li>
                    <li>Ads that include adult, political or religious content get rejected and the fees get refunded back to the advertiser within 48 working hours.</li>
                  </ul>
                </div>
              </div>
            </div>

<div class="grid-margin stretch-card" style="padding: 10px;">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title" style="background-color: whitesmoke; max-width: 162px;">For publishers:</h4>
                  <ul>
                    <li>Once the publisher creates his account he gets custom scripts connected to his account to put on his website wherever he wants.</li>
                    <li>We now have 5 ad sizes so it can fit a wide range of websites.</li>
                    <li>All statistics and tools needed to follow up the advertising process are included.</li>
                    <li>If publisher tries to "fake click" his website he will sadly get blocked.</li>
                    <li>Publishers get paid monthly.</li>
                    <li>Payment occurs when publisher's balance is $10 or more. if it is less, he gets his balance added to the next month until the minimum value is reached.</li>
                  </ul>
                </div>
              </div>
            </div>
</div>

  </div> </div>
<div style="text-align: center; margin-bottom: 1rem;"><a href="../how-it-works/" class="bottom">How it works</a>&emsp;<a href="../pricing/" class="bottom">Pricing</a>&emsp;<a href="../contact-us/" class="bottom">Contact us</a>
&emsp;<a href="../about/" class="bottom">About</a></div>   
<p class="fw-light text-white bottom" style="text-align: -webkit-center;">Topad.net <?php echo date("Y"); ?></p>
</body></html>