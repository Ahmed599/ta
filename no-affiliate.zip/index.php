<?php
session_start();
 
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: dashboard/");
    exit;
}
?>
<html lang="en" class="">
<head>
<meta charset="UTF-8">
<title>Welcome To Topad.net</title>
<meta name="robots" content="noindex">  <meta name="viewport" content="width=device-width, initial-scale=1">
 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style class="INLINE_PEN_STYLESHEET_ID"> body {
}
p {
    margin-top: 0rem;
    margin-bottom: 0rem;
}
a { color: #000;
text-decoration: auto;
}
a:hover, a:active, a:focus { color:#000;
}
@-webkit-keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
@keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
h1 { font-size: 3em; font-weight: bold;
}
h3 { display: block; font-size: 1.5em; margin-left: 0; margin-right: 0; font-weight: bold;
}
.h-100 { height: 82%!important;
}
.text-white {
    color: #6a6e72!important;
}
.cent {
    margin-top: 2rem!important;
    margin-bottom: 2rem!important;
}
.bottom {
font-size: 0.8rem;
color: #6a6e72;
text-decoration: auto;
}
  </style>
</head>
<body>
<div class="header">
<h2 class="fw-light m-3" style="color: #559ade; font-size: 3rem;">TopAd</h2>
</div>
<div style="justify-content: center!important; flex-direction: column!important; height: 700px!important; display: flex!important;">
<div style="align-items: center!important; align-items: center!important; display: flex!important; flex-direction: column!important;">
<h1 class="fw-light text-white m-3" style="text-align: -webkit-center;">Welcome to the Ad Market :)</h1>
<br>
<h3 class="fw-light text-white m-2">Select account type</h3>
<div class="btn-group cent">
<a href="publisher/" class="btn btn-outline-dark" style="border-top-right-radius: 4px; border-bottom-right-radius: 4px;">
<i class="fas fas fa-desktop me-2"></i>PUBLISHER</a>
<span style="width: 1rem;"></span>
<a href="advertiser/" class="btn btn-outline-dark" style="border-top-left-radius: 4px; border-bottom-left-radius: 4px;">ADVERTISER<i class="fas fa-chart-line ms-2"></i>
</a>
</div> <h5 class="fw-light text-white m-0 text-decoration-none">Or login <a href="login/">here</a></h5>
</div> </div>
<div style="text-align: center; margin-bottom: 30px;"><a href="how-it-works/" class="bottom">How it works</a>&emsp;<a href="pricing/" class="bottom">Pricing</a>&emsp;<a href="contact-us/" class="bottom">Contact us</a>
&emsp;<a href="about/" class="bottom">About</a></div>
<p class="fw-light text-white bottom" style="text-align: -webkit-center;">Topad.net © <?php echo date("Y"); ?></p>
</body>
</html>