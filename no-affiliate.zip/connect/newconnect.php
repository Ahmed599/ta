<?php
$conn = new mysqli("127.0.0.1:3306","root","wpH35AZ1Lv3@","topadn6_project");

// Check connection
if ($conn -> connect_errno) {
  echo "Failed to connect to MySQL: " . $conn -> connect_error;
  exit();
}
?>