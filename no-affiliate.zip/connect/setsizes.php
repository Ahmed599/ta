<?php
require_once "connect.php";

			$id = 1;
			$zero = 0;
			
			$stmt = $pdo->prepare('INSERT INTO sizes (id, 728x90, 970x250, 300x250, 300x600, 160x600) VALUES (:id, :zero, :zero, :zero, :zero, :zero)');
			$stmt->bindParam(":id", $param_id, PDO::PARAM_STR);
			$stmt->bindParam(":zero", $param_zero, PDO::PARAM_STR);
			$param_id = $id;
			$param_zero = $zero;
			$stmt->execute();
			//$stmt->fetch();
			/*$stmt = $pdo->prepare('SELECT * FROM sizes WHERE id = ?');
				$stmt->execute([$id]);
				$data = $stmt->fetchAll();
				if ($data){
						$status = 1;
						$stmt = $pdo->prepare('UPDATE messages_in SET status = ? WHERE redirect = ?');
						$stmt->execute([$status, $redirect]);
						$stmt->fetchAll();
						header("Location: viewmess.php");
				}*/

?>
