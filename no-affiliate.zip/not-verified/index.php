<?php
include 'not-verified-file.php';

include '../connect/connect1.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '..\phpmailer\src\Exception.php';
require_once '..\phpmailer\src\PHPMailer.php';
require_once '..\phpmailer\src\SMTP.php';
$mail = new PHPMailer(true);

//session_start();	
					
					
if ($_SERVER["REQUEST_METHOD"] == "POST") {

	$a = rand(1000000,10000000);
	$b = md5($a);
	$c = base64_encode(md5(rand(1,1000)));

	if(isset($_SESSION['email'])){
		$email =$_SESSION['email'];
		$active= 0;
		$stmt = $pdo->prepare("SELECT * FROM users WHERE email= ? and active= ?");
		$stmt->execute([$email, $active]);
		$data = $stmt->fetchAll();	
		
		foreach ($data as $res){
			$dir = $res["dir"];	
			$active = $res["active"];
			$code = $res["code"];
		}
		try {
			$url = "https://www.topad.net/v/?se=$a&tn=$b&r=$code&c=$c";
		// Server settings
			$mail->SMTPDebug = 0; //SMTP::DEBUG_SERVER; for detailed debug output
			$mail->isSMTP();
			$mail->Host = 'smtp-relay.brevo.com';
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
			$mail->Port = 587;

			$mail->Username = 'topad.net@gmail.com'; // YOUR gmail email
			$mail->Password = 'xsmtpsib-84867de6121d39f505ffc7b9073db195299dcfbacf5c77e44c651930b178e3b5-G40IHK58xXZO96pj'; // YOUR gmail password

			// Sender and recipient settings
			$mail->setFrom('no-reply@topad.net', 'TopAd');
			$mail->addAddress($email, '');
			$mail->IsHTML(true);
			$mail->Subject = "Welcome to Topad.net";
			$mail->Body = 'Thanks for signing up!
				Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.
				Please click this link to activate your account:
				<a href="' . $url . '">Click Here</a>';

			$mail->send();
			//header("location: check-your-email.php");
			header("location: ../logout/");
		} catch (Exception $e) {
			header("location: ../error");
			}
		}
}
					
?>
<html lang="en"><head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Not Verified - Topad.net</title>
  <link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
  <link rel="stylesheet" href="../assets/materialdesignicons.min.css">
  <link rel="stylesheet" href="../assets/style.css">
</head>

<body style="background-color: #f1f6f8;">
<div class="header">
  <h2 class="fw-light m-3" style="color: #559ade;">TopAd</h2>
</div>

    <div class="content-wrapper" data-select2-id="10" style="margin-top: 120px;">
          <div class="row" style="place-content: center;">
            <div class="col-md-6 grid-margin stretch-card" style="display: contents;">
              <div class="card" style="min-width: auto; width: auto;">
                <div class="card-body" style="padding-bottom: 0;">
                  <p class="card-title" style="text-align: -webkit-center; margin-bottom: 0;color: #212529a8;">Not verified</p>
                  <!--<p class="card-description" style="text-align: -webkit-center;">-->
                  <p></p>
		<hr style="margin-bottom: 1.2em;width: 80%;">
                  <div class="forms-sample"style="text-align: center;">     
                    <div class="form-group">
                    <p>Please check your inbox for the verification message. If you can not find it you can press the button below to resend it.</p>
                  </div>
                    
                    
                    <div class="form-group" style="text-align: center;margin-top: 2rem;margin-bottom: 0;">
				
					<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
					  <input type="submit" class="btn btn-lg" style="background-color: #559ade;color: white;">
					</form>

			
		</div>
         </div>
                </div>
              </div>
            </div>
            </div>
        </div>
<p style="margin-top: 36px; font-size: 0.8em; text-align: center;">Topad.net © <?php echo date("Y"); ?></p>

</body></html>