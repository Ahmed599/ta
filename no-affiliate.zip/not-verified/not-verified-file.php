<?php
include '../connect/connect1.php';

session_start();	
if(isset($_SESSION['email'])){
	$email =$_SESSION['email'];
	$stmt = $pdo->prepare("SELECT * FROM users WHERE email= ?");
	$stmt->execute([$email]);
	$data = $stmt->fetchAll();	
	if ($data){
			foreach ($data as $res){
				$active = $res["active"];
					
	}if($active  == 1){
		header ("Location: ../dashboard/");
			}
		
	}
}
	
if(!(isset($_SESSION['email']))){
	header ("Location: ../");
	}
?>