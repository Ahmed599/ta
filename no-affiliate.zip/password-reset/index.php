<?php
session_start();

if(isset($_SESSION["email"]) && $_SESSION["email"] === true){
    header("location: https://www.topad.net/dashboard/");
    exit;
}
 
require_once "../connect/connect.php";
 
$email = $code = $password = $re_password = $re_password_err = "";
$email_err = $code_err = $password_err = "";
 
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter email.";
    } else{
        $email = trim($_POST["email"]);
    }
	
	if(empty(trim($_POST["code"]))){
        $code_err = "Please enter your code.";
    } else{
        $code = trim($_POST["code"]);
    }
	
	
	$pattern = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,12}$/";
	
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
	}if(!(preg_match($pattern, $_POST["password"])) == 1){
		$password_err = "Password must have 8-12 Uppercase, Lowercase, Symbols and Numbers";
    } else{
        $password = trim($_POST["password"]);
    }
	
	
	if(empty(trim($_POST["re_password"]))){
        $re_password_err = "Please re-enter your password.";
    } else{
        $re_password = trim($_POST["re_password"]);
    }
    
    if(empty($email_err) && empty($code_err) && empty($password_err) && empty($re_password_err)){
		$stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
		$stmt->execute([$email]);
		$data = $stmt->fetchAll();
		if ($data){
			foreach ($data as $row){
				$ori_code = $row["emailcode"];
				}
				$hash = password_hash($password, PASSWORD_DEFAULT);
				if($ori_code == "$code" && "$password" == "$re_password"){
					$stmt = $pdo->prepare('UPDATE users SET password = ? WHERE email = ?');
					$stmt->execute([$hash, $email]);
					unset($_SESSION["email"]);
					header("Location: https://www.topad.net/login/");
				}else{
					$code_err = "check your inputs and try again.";
				}
						
			}
		}
        
    }
?>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Reset Password - Topad.net</title>
<meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style class="INLINE_PEN_STYLESHEET_ID"> body {
}
p {
    margin-top: 0rem;
    margin-bottom: 0rem;
}
a { color: #000;
text-decoration: auto;
}
a:hover, a:active, a:focus { color:#000;
}
@-webkit-keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
@keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
h1 { font-size: 3em; font-weight: bold;
}
h3 { display: block; font-size: 1.5em; margin-left: 0; margin-right: 0; font-weight: bold;
}
.h-100 { height: 83%!important;
}
.text-white {
    color: #6a6e72!important;
}
.cent {
    margin-top: 1rem!important;
    margin-bottom: 2rem!important;
}
.bottom {
font-size: 0.8rem;
color: #6a6e72;
text-decoration: auto;
}
  </style>
</head>
<body>
<div class="header">
<a href="../" style="float: left;"><h2 class="fw-light m-3" style="color: #559ade; font-size: 2rem;">TopAd</h2></a>
</div>
<div class="d-flex flex-column justify-content-center w-100 h-100">
<div class="d-flex flex-column justify-content-center align-items-center">
<h2 class="fw-light text-white m-3" style="text-align: -webkit-center;font-weight: 400!important;">It's Ok :)</h2>

<h3 style="padding-right: 10%;padding-left: 10%;text-align: center;font-size: 1.3rem;max-width: 1360px;padding-bottom: 2rem;" class="fw-light text-white m-2">You're few steps away from resetting your password.</h3>

<form class="forms-sample" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="text-align: -webkit-center;">
<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">

  <input type="text" name="email" class="form-control" placeholder="email" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="">
</div>

<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">

  <input type="text" name="code" class="form-control" placeholder="code" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="">
</div>

<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">

  <input type="password" name="password" class="form-control" placeholder="password" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="">
</div>

<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">

  <input type="password" name="re_password" class="form-control" placeholder="re-password" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="">
</div>

<span class="help-block"><?php if (!empty($email_err)){echo  $email_err . "<br>";} elseif (!empty($code_err)){echo  $code_err . "<br>";} elseif (!empty($password_err)){echo  $password_err . "<br>";} elseif (!empty($re_password_err)){echo  $re_password_err . "<br>";}  ?></span>
<div class="btn-group cent">

<button type="submit" class="btn btn-outline-dark" style="border-top-left-radius: 4px;border-bottom-left-radius: 4px;padding-right: 1rem;padding-left: 1rem;">Next</button>

</div></form>
</div>
</div>
<div style="text-align: center; margin-bottom: 1.6rem;"><a href="how-it-works/" class="bottom">How it works</a>&emsp;<a href="pricing/"" class="bottom">Pricing</a>&emsp;<a href="contact-us/"" class="bottom">Contact us</a>
&emsp;<a href="about/" class="bottom">About</a></div>
<p class="fw-light text-white bottom" style="text-align: -webkit-center;">Topad.net © <?php echo date("Y"); ?></p>
</body></html>