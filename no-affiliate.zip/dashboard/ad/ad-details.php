<?php 
include 'das-php-ad.php';
?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Ad Details - Topad.net</title>
  
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.0/css/boxicons.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.snow.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.bubble.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/remixicon@2.2.0/fonts/remixicon.css" rel="stylesheet">
  <link href="https://unpkg.com/simple-datatables@2.1.13/dist/style.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.36.3/apexcharts.min.css" rel="stylesheet">
  <link href="https://bootstrapmade.com/demo/templates/NiceAdmin/assets/css/style.css" rel="stylesheet">

<style>
.tab {
  overflow: hidden;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  border: none;
  outline: none;
  cursor: pointer;
  color: #899bbd;
}

/* Style the tab content */
.tabcontent {
  display: none;
  border-top: none;
}
.tabcontent1 {
  display: none;
  border-top: none;
}
.tabcontent2 {
  display: none;
  border-top: none;
}
.tabcontent3 {
  display: none;
  border-top: none;
}
.tabcontent4 {
  display: none;
  border-top: none;
}
.tabcontent5 {
  display: none;
  border-top: none;
}
</style></head>

<body>

  <header id="header" class="header fixed-top d-flex align-items-center header-scrolled">

    <div class="d-flex align-items-center justify-content-between">
      <a href="../" class="logo d-flex align-items-center">
        <span class="d-none d-lg-block" style="font-weight: 300;">TopAd</span>
      </a>
      
    </div>

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        </li>

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown" aria-expanded="false">
            <span class="d-md-block dropdown-toggle ps-2"><i class="bi bi-list toggle-sidebar-btn"></i></span>
          </a>

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile" style="">
            <li class="dropdown-header">
              <h6><?php echo $name; ?></h6>
              <span>Advertiser</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="../../forgot-password/">
                <i class="bi bi-gear"></i>
                <span>Forgot/Reset Password</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="../../contact-us/">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="../../logout/">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul>
        </li>
      </ul>
    </nav>
  </header>

  <main id="main" class="main" style="margin-left: 0px;">

    <div class="pagetitle">
	  <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item">Details of campaign </li>
          <li class="breadcrumb-item active"><?php echo $campaign_name; ?></li>
        </ol>
      </nav>
    </div>

    <section class="section dashboard">
      <div class="row" style="justify-content: center;">

        <div class="col-lg-8">
          <div class="row" style="justify-content: center;">

            <div class="col-xxl-6 col-md-6">
              <div class="card info-card sales-card">

                <div class="card-body">
                  <h5 class="card-title">Today |<div class="tab" style="display: inline;">
  <button class="tablinks" onclick="res(event, 'TodayViews')"><span style="text-decoration: underline;" id="today-main">Impressions</span></button></span><div class="tab" style="display: inline;">
  <button class="tablinks" onclick="res(event, 'TodayClicks')"><span style="text-decoration: underline;">Clicks</span></button></h5>

                  <div class="d-flex align-items-center" style="justify-content: center;">

                    <div class="ps-3">
					<div id="TodayViews" class="tabcontent">
					  <h6><?php echo number_format($views_today); ?></h6>
					</div>
					<div id="TodayClicks" class="tabcontent">
					  <h6><?php echo number_format($clicks_today); ?></h6>
					</div>
                      <span class="text-success small pt-1 fw-bold"><?php echo ('$' . number_format($spent_today, 2)); ?></span> <span class="text-muted small pt-2 ps-1">spent</span>

                    </div>
                  </div>
                </div>

              </div>
            </div>
			
            <div class="col-xxl-6 col-md-6">
              <div class="card info-card sales-card">

                <div class="card-body">
                  <h5 class="card-title">Yesterday |<div class="tab" style="display: inline;">
				  <button class="tablinks1" onclick="res1(event, 'YesterdayViews')"><span style="text-decoration: underline;" id="yesterday-main">Impressions</span></button></span><div class="tab" style="display: inline;">
				  <button class="tablinks1" onclick="res1(event, 'YesterdayClicks')"><span style="text-decoration: underline;">Clicks</span></button></h5>

                  <div class="d-flex align-items-center" style="justify-content: center;">

                    <div class="ps-3">
					<div id="YesterdayViews" class="tabcontent1" style="display: none;">
					  <h6><?php echo number_format($views_yesterday); ?></h6>
					</div>
					<div id="YesterdayClicks" class="tabcontent1" style="display: none;">
					  <h6><?php echo number_format($clicks_yesterday); ?></h6>
					</div>
                      <span class="text-success small pt-1 fw-bold"><?php echo ('$' . number_format($spent_yesterday, 2)); ?></span> <span class="text-muted small pt-2 ps-1">spent</span>

                    </div>
                  </div>
                </div>

              </div>
            </div>
			</div>
			          
			<div class="row" style="justify-content: center;">
			<div class="col-xxl-6 col-md-6">
              <div class="card info-card sales-card">

                <div class="card-body">
				  <h5 class="card-title">Last Yesterday |<div class="tab" style="display: inline;">
  <button class="tablinks4" onclick="res4(event, 'ThismonthViews')"><span style="text-decoration: underline;" id="last-yesterday-main">Impressions</span></button></span><div class="tab" style="display: inline;">
  <button class="tablinks4" onclick="res4(event, 'ThismonthClicks')"><span style="text-decoration: underline;">Clicks</span></button></h5>

                  <div class="d-flex align-items-center" style="justify-content: center;">

                    <div class="ps-3">
					<div id="ThismonthViews" class="tabcontent4" style="display: none;">
					  <h6><?php echo number_format($views_yesterday1); ?></h6>
					</div>
					<div id="ThismonthClicks" class="tabcontent4" style="display: none;">
					  <h6><?php echo number_format($clicks_yesterday1); ?></h6>
					</div>
                      <span class="text-success small pt-1 fw-bold"><?php echo ('$' . number_format($spent_yesterday1, 2)); ?></span> <span class="text-muted small pt-2 ps-1">spent</span>

                    </div>
                  </div>
                </div>

              </div>
            </div>
			<div class="col-xxl-6 col-md-6">
              <div class="card info-card sales-card">

                <div class="card-body">
                  <h5 class="card-title">Total |<div class="tab" style="display: inline;">
				  <button class="tablinks5" onclick="res5(event, 'TotalViews')" id="total-main"><span style="text-decoration: underline;">Impressions</span></button></span><div class="tab" style="display: inline;">
				  <button class="tablinks5" onclick="res5(event, 'TotalClicks')"><span style="text-decoration: underline;">Clicks</span></button></h5>

                  <div class="d-flex align-items-center" style="justify-content: center;">

                    <div class="ps-3">
					<div id="TotalViews" class="tabcontent5" style="display: none;">
					  <h6><?php echo number_format($totalviews); ?></h6>
					</div>
					<div id="TotalClicks" class="tabcontent5" style="display: none;">
					  <h6><?php echo number_format($totalclicks); ?></h6>
					</div>
                      <span class="text-success small pt-1 fw-bold"><?php echo ('$' . number_format($totalspent, 2)); ?></span> <span class="text-muted small pt-2 ps-1">spent</span>

                    </div>
                  </div>
                </div>

              </div>
            </div>
			</div>
			</div>
			
			
            <div class="col-12">
              <div class="card">

                

                <div class="card-body">

            <div id="chart"></div>

                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

  </main>
  
  <footer id="footer" class="footer" style="margin: 0;">
    <div class="copyright">
     Topad.net © <?php echo date("Y"); ?>
    </div>
  </footer>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.36.3/apexcharts.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.3/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/echarts/5.4.1/echarts.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.min.js"></script>
  <script src="https://bootstrapmade.com/demo/templates/NiceAdmin/assets/vendor/simple-datatables/simple-datatables.js"></script>
  <!--<script src="../assets/vendor/simple-datatables/simple-datatables.js"></script>-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/6.3.1/tinymce.min.js"></script>
  <script>
	function res(evt, item) {
	  var i, tabcontent, tablinks;
	  tabcontent = document.getElementsByClassName("tabcontent");
	  for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	  }
	  tablinks = document.getElementsByClassName("tablinks");
	  for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	  }
	  document.getElementById(item).style.display = "block";
	  evt.currentTarget.className += " active";
	}
	document.getElementById("today-main").click();
</script>
  <script>
	function res1(evt1, item1) {
	  var i, tabcontent1, tablinks1;
	  tabcontent1 = document.getElementsByClassName("tabcontent1");
	  for (i = 0; i < tabcontent1.length; i++) {
		tabcontent1[i].style.display = "none";
	  }
	  tablinks1 = document.getElementsByClassName("tablinks1");
	  for (i = 0; i < tablinks1.length; i++) {
		tablinks1[i].className = tablinks1[i].className.replace(" active", "");
	  }
	  document.getElementById(item1).style.display = "block";
	  evt1.currentTarget.className += " active";
	}
		document.getElementById("yesterday-main").click();
</script>
<script>
	function res3(evt3, item3) {
	  var i, tabcontent3, tablinks3;
	  tabcontent3 = document.getElementsByClassName("tabcontent3");
	  for (i = 0; i < tabcontent3.length; i++) {
		tabcontent3[i].style.display = "none";
	  }
	  tablinks3 = document.getElementsByClassName("tablinks3");
	  for (i = 0; i < tablinks3.length; i++) {
		tablinks3[i].className = tablinks3[i].className.replace(" active", "");
	  }
	  document.getElementById(item3).style.display = "block";
	  evt3.currentTarget.className += " active";
	}
		document.getElementById("this-week-main").click();
</script>
<script>
	function res4(evt4, item4) {
	  var i, tabcontent4, tablinks4;
	  tabcontent4 = document.getElementsByClassName("tabcontent4");
	  for (i = 0; i < tabcontent4.length; i++) {
		tabcontent4[i].style.display = "none";
	  }
	  tablinks4 = document.getElementsByClassName("tablinks4");
	  for (i = 0; i < tablinks4.length; i++) {
		tablinks4[i].className = tablinks4[i].className.replace(" active", "");
	  }
	  document.getElementById(item4).style.display = "block";
	  evt4.currentTarget.className += " active";
	}
		document.getElementById("last-yesterday-main").click();
</script>
<script>
	function res5(evt5, item5) {
	  var i, tabcontent5, tablinks5;
	  tabcontent5 = document.getElementsByClassName("tabcontent5");
	  for (i = 0; i < tabcontent5.length; i++) {
		tabcontent5[i].style.display = "none";
	  }
	  tablinks5 = document.getElementsByClassName("tablinks5");
	  for (i = 0; i < tablinks5.length; i++) {
		tablinks5[i].className = tablinks5[i].className.replace(" active", "");
	  }
	  document.getElementById(item5).style.display = "block";
	  evt5.currentTarget.className += " active";
	}
		document.getElementById("total-main").click();
</script>
<script>
var options = {
          series: [
          {
            name: "Impressions",
            <?php echo "data: ". $views_array . "\n"; ?>
          },
          {
            name: "Clicks",
            <?php echo "data: ". $clicks_array . "\n"; ?>
          }
        ],
          chart: {
          height: 350,
          type: 'line',
          dropShadow: {
            enabled: true,
            color: '#000',
            top: 18,
            left: 7,
            blur: 10,
            opacity: 0.2
          },
          toolbar: {
            show: false
          }
        },
        colors: ['#77B6EA', '#198754'],
        dataLabels: {
          enabled: true,
        },
        stroke: {
          curve: 'smooth'
        },
        title: {
          text: '',
          align: 'left'
        },
        grid: {
          borderColor: '#e7e7e7',
          row: {
            colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
            opacity: 0.5
          },
        },
        markers: {
          size: 1
        },
        xaxis: {
          <?php echo "categories: ". $days_array . "\n"; ?>,
          title: {
            text: 'Day'
          }
        },
        
        legend: {
          position: 'top',
          horizontalAlign: 'right',
          floating: true,
          offsetY: -25,
          offsetX: -5
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();
</script>
<script>
function adcp1() {

  var copyText = document.getElementById("600x160");
  copyText.select();
  copyText.setSelectionRange(0, 99999); 
  navigator.clipboard.writeText(copyText.value);
}
function adcp2() {

  var copyText = document.getElementById("600x300");
  copyText.select();
  copyText.setSelectionRange(0, 99999); 
  navigator.clipboard.writeText(copyText.value);
}
function adcp3() {

  var copyText = document.getElementById("250x300");
  copyText.select();
  copyText.setSelectionRange(0, 99999); 
  navigator.clipboard.writeText(copyText.value);
}
function adcp4() {

  var copyText = document.getElementById("250x970");
  copyText.select();
  copyText.setSelectionRange(0, 99999); 
  navigator.clipboard.writeText(copyText.value);
}
function adcp5() {

  var copyText = document.getElementById("90x728");
  copyText.select();
  copyText.setSelectionRange(0, 99999); 
  navigator.clipboard.writeText(copyText.value);
}
</script>
</body>
</html>
