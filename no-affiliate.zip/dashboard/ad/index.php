<?php
$servername = "127.0.0.1:3306";
$username = "root";
$password = "wpH35AZ1Lv3@";
$dbname = "topadn6_project";

try {

	session_start();
	$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	if(isset($_SESSION['email'])){ 

		$email = $_SESSION['email']; 
		$adred = $_GET['a'];

		$statement = $pdo->prepare("SELECT fullname FROM users WHERE email = :email");
		$statement->execute(array('email' => $email));
		$name = $statement->fetchColumn();

		$statement = $pdo->prepare("SELECT id FROM users WHERE email = :email");
		$statement->execute(array('email' => $email));
		$adv_id = $statement->fetchColumn();

		$statement = $pdo->prepare("SELECT id FROM ads_normal WHERE adv_id = :adv_id and redirect = :redirect");
		$statement->execute(array('adv_id' => $adv_id, 'redirect' => $adred));
		$id = $statement->fetchColumn();
		if ($id){
			require "ad-details.php";
		}else{
			header("Location: ../");
		}	
	}else{
		header("Location: ../");
	}	
} catch(PDOException $e) {
	echo "Error: " . $e->getMessage();
	}
?>
