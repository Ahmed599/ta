<?php
session_start();

$servername = "127.0.0.1:3306";
$username = "root";
$password = "wpH35AZ1Lv3@";
$dbname = "topadn6_project";

$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
		header("location: https://www.topad.net/login/");
	}  
    if(isset($_SESSION['email'])){
		$email = $_SESSION['email'];
    $active = '1';
    $usertype = '2';
    $type = '3';
    $statement = $pdo->prepare("SELECT id FROM users WHERE email = :email and active = :active and type = :type");
    $statement->execute(array('email' => $email, 'active' => $active, 'type' => $usertype));
    $id = $statement->fetchColumn();
    
    if($id){
      //include_once('post-ad-more.php');
      include_once('test.php');
    }else{
      header("location: https://www.topad.net");
    }
  }
$category = $country = $language = "";
?>
<html lang="en">
<head>
  <link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@3.6.95/css/materialdesignicons.min.css"> 
<style>
#output {
  padding: 20px;
  background: #dadada;
}

form {
  margin-top: 20px;
}

select {
  width: 300px;
}


.paypal-buy-now-button {
	display: inline-flex;
  position: relative;
  background: #FFC439;
  border-radius: 5px;
  border: 1px solid #DC911D;
  box-shadow: inset 0 1px 0 0 #FFD699;
  font-family: 'Helvetica Neue', Arial, sans-serif;
  font-weight: 700;
  font-size: 12px;
  padding: 0 23px;
  height: 42px;
  justify-content: center;
  align-items: center;
  color: black;
  text-decoration: none;
  cursor: pointer;

  &:before {
    content: "";
    position: absolute;
    top: -1px;
    bottom: -1px;
    left: -1px;
    right: -1px;
    border-radius: 5px;
    background: linear-gradient(to bottom, #FFAF00 0%, #DC911D 100%);
    z-index: 1;
  }

  &:after {
    content: "";
    border-radius: 4px;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: #FFC439;
    box-shadow: inset 0 1px 0 0 #FFD699;
    z-index: 1;
  }

  span {
    padding-top: 3px;
    padding-right: 7px;
    text-shadow: 0 1px 0 #FFD699;
    z-index: 2;
  }

  svg {
    filter: drop-shadow(0 1px 0 #FFFFFF);
    z-index: 2;
  }
}

.row {
    --bs-gutter-x: 0rem;
}
.file-input__input {
  width: 0.1px;
  height: 0.1px;
  opacity: 0;
  overflow: hidden;
  position: absolute;
  z-index: -1;
}

.file-input__label {
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 600;
  color: #fff;
  font-size: 14px;
  padding: 10px 12px;
  background-color: #559ade;
  box-shadow: 0px 0px 2px rgba(0, 0, 0, 0.25);
}

.file-input__label svg {
  height: 16px;
  margin-right: 4px;
}

</style>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Post Ad - Topad.net</title>

<link rel="stylesheet" href="css/materialdesignicons.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css">
<link rel="stylesheet" href="css/vendor.bundle.base.css">
<link rel="stylesheet" href="css/select2.min.css">
<link rel="stylesheet" href="css/select2-bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<script async="" src="js/invisible.js"></script>
</head>
<body style=" background-color: #f1f6f8; ">
<div class="header" style="margin-bottom: 10px;align-content: center;"></div>
<a href="../../" style="text-align: -webkit-center; text-decoration: none;">
<div class="content-wrapper" data-select2-id="10">
  <h2 class="fw-light m-3" style="color: #559ade;font-size: 2rem;">TopAd</h2>
<div class="row" style="place-content: center;--bs-gutter-x: 0rem;">
</a> <div class="col-md-6 grid-margin stretch-card" style="display: contents;">
</div>		  <div class="card" style="min-width: auto; width: 90%;max-width: 600px;">
                <div class="card-body">
				
				<div style="text-align: center; padding-left: 9px; padding-top: 9px; border: 1px solid #ccc!important; color: #0009!important; background-color: #ffdddd!important; margin-top: 16px; margin-bottom: 16px;">
					<p style="font-size: 0.7rem; margin-bottom: 1px;">Please choose your ad images carefully.</p>
				  <p style="font-size: 0.7rem; margin-bottom: 1px;">Ad images should not contain any Adult, political or religious content.</p>
				  <p style="font-size: 0.7rem; margin-bottom: 1px;">All ads are revised carefully.</p>
				  <p style="font-size: 0.7rem; margin-bottom: 1px;">If your ad gets rejected, you get your money back within 48 working hours.</p>
				  <p style="font-size: 0.7rem;">Please repect our policy to enjoy this experience.</p>
				</div>

                  <p></p>
				  <form method="post" enctype="multipart/form-data">
				  <?php if (!empty($msg)): ?>
			  <div class="alert alert-danger alert-dismissible fade show" role="alert">
				<?php echo $msg; ?>
              </div>
			  <?php endif; ?>
			  
			                  <div class="row mb-2">
                  <label for="inputText" class="col-sm-3 col-form-label">Campaign title</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="campaign_name" placeholder="ex: Adam's showroom">
                  </div>
                </div>
                <div class="row mb-2">
                  <label for="inputText" class="col-sm-3 col-form-label">Description</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="description" placeholder="ex: We're specialized in selling luxury cars">
                  </div>
                </div>
				
				<div class="row mb-2">
				<label class="col-sm-3 col-form-label">Category</label>
				<div class="col-sm-9">
				<select name="category[]" id="category[]" class="selectpicker" multiple aria-label="Default select example" data-live-search="true">
					<option value="Autos & Vechicles" <?php if($category== "Autos & Vechicles") echo "selected"; ?>>Autos & Vechicles</option>
                            <option value="Pets & Animals" <?php if($category== "Pets & Animals") echo "selected"; ?>>Pets & Animals</option>
                            <option value="Sports" <?php if($category== "Sports") echo "selected"; ?>>Sports</option>
                            <option value="Travel & Events" <?php if($category== "Travel & Events") echo "selected"; ?>>Travel & Events</option>
                            <option value="Gaming" <?php if($category== "Gaming") echo "selected"; ?>>Gaming</option>
                            <option value="People & Blogs" <?php if($category== "People & Blogs") echo "selected"; ?>>People & Blogs</option>
                            <option value="Comedy" <?php if($category== "Comedy") echo "selected"; ?>>Comedy</option>
                            <option value="Business & Brands" <?php if($category== "Business & Brands") echo "selected"; ?>>Business & Brands</option>
                            <option value="Entertainment" <?php if($category== "Entertainment") echo "selected"; ?>>Entertainment</option>
                            <option value="News & Politics" <?php if($category== "News & Politics") echo "selected"; ?>>News & Politics</option>
                            <option value="Howto & Style" <?php if($category== "Howto & Style") echo "selected"; ?>>Howto & Style</option>
							<option value="Education" <?php if($category== "Education") echo "selected"; ?>>Education</option>
							<option value="Science & Technology" <?php if($category== "Science & Technology") echo "selected"; ?>>Science & Technology</option>
							<option value="Nonprofits & Activism" <?php if($category== "Nonprofits & Activism") echo "selected"; ?>>Nonprofits & Activism</option>
                    </select>
                  </div>
                </div>

				<div class="row mb-2">
				<label class="col-sm-3 col-form-label">Country</label>
				<div class="col-sm-9">
				    <select name="country[]" id="country[]" class="selectpicker" multiple aria-label="Default select example" data-live-search="true">
              <option value="Albania" <?php if($country== "Albania") echo "selected"; ?>>Albania</option>
              <option value="Afghanistan" <?php if($country== "Afghanistan") echo "selected"; ?>>Afghanistan</option>
              <option value="Algeria" <?php if($country== "Algeria") echo "selected"; ?>>Algeria</option>
              <option value="Angola" <?php if($country== "Angola") echo "selected"; ?>>Angola</option>
              <option value="Anguilla" <?php if($country== "Anguilla") echo "selected"; ?>>Anguilla</option>
              <option value="Antarctica" <?php if($country== "Antarctica") echo "selected"; ?>>Antarctica</option>
              <option value="Argentina" <?php if($country== "Argentina") echo "selected"; ?>>Argentina</option>
              <option value="Armenia" <?php if($country== "Armenia") echo "selected"; ?>>Armenia</option>
              <option value="Australia" <?php if($country== "Australia") echo "selected"; ?>>Australia</option>
              <option value="Austria" <?php if($country== "Austria") echo "selected"; ?>>Austria</option>
              <option value="Azerbaijan" <?php if($country== "Azerbaijan") echo "selected"; ?>>Azerbaijan</option>
              <option value="Bahamas" <?php if($country== "Bahamas") echo "selected"; ?>>Bahamas</option>
              <option value="Bahrain" <?php if($country== "Bahrain") echo "selected"; ?>>Bahrain</option>
              <option value="Bangladesh" <?php if($country== "Bangladesh") echo "selected"; ?>>Bangladesh</option>
              <option value="Barbados" <?php if($country== "Barbados") echo "selected"; ?>>Barbados</option>
              <option value="Belarus" <?php if($country== "Belarus") echo "selected"; ?>>Belarus</option>
              <option value="Belgium" <?php if($country== "Belgium") echo "selected"; ?>>Belgium</option>
              <option value="Belize" <?php if($country== "Belize") echo "selected"; ?>>Belize</option>
              <option value="Benin" <?php if($country== "Benin") echo "selected"; ?>>Benin</option>
              <option value="Bhutan" <?php if($country== "Bhutan") echo "selected"; ?>>Bhutan</option>
              <option value="Bolivia" <?php if($country== "Bolivia") echo "selected"; ?>>Bolivia</option>
              <option value="Bosnia and Herzegovina" <?php if($country== "Bosnia and Herzegovina") echo "selected"; ?>>Bosnia and Herzegovina</option>
              <option value="Botswana" <?php if($country== "Botswana") echo "selected"; ?>>Botswana</option>
              <option value="Brazil" <?php if($country== "Brazil") echo "selected"; ?>>Brazil</option>
              <option value="Brunei Darussalam" <?php if($country== "Brunei Darussalam") echo "selected"; ?>>Brunei Darussalam</option>
              <option value="Bulgaria" <?php if($country== "Bulgaria") echo "selected"; ?>>Bulgaria</option>
              <option value="Burkina Faso" <?php if($country== "Burkina Faso") echo "selected"; ?>>Burkina Faso</option>
              <option value="Burundi" <?php if($country== "Burundi") echo "selected"; ?>>Burundi</option>
              <option value="Cambodia" <?php if($country== "Cambodia") echo "selected"; ?>>Cambodia</option>
              <option value="Cameroon" <?php if($country== "Cameroon") echo "selected"; ?>>Cameroon</option>
              <option value="Canada" <?php if($country== "Canada") echo "selected"; ?>>Canada</option>
              <option value="Cape Verde" <?php if($country== "Cape Verde") echo "selected"; ?>>Cape Verde</option>
              <option value="Central African Republic" <?php if($country== "Central African Republic") echo "selected"; ?>>Central African Republic</option>
              <option value="Chad" <?php if($country== "Chad") echo "selected"; ?>>Chad</option>
              <option value="Chile" <?php if($country== "Chile") echo "selected"; ?>>Chile</option>
              <option value="China" <?php if($country== "China") echo "selected"; ?>>China</option>
              <option value="Colombia" <?php if($country== "Colombia") echo "selected"; ?>>Colombia</option>
              <option value="Comoros" <?php if($country== "Comoros") echo "selected"; ?>>Comoros</option>
              <option value="Congo-Brazzaville" <?php if($country== "Congo-Brazzaville") echo "selected"; ?>>Congo-Brazzaville</option>
              <option value="Congo-Kinshasa" <?php if($country== "Congo-Kinshasa") echo "selected"; ?>>Congo-Kinshasa</option>
              <option value="Costa Rica" <?php if($country== "Costa Rica") echo "selected"; ?>>Costa Rica</option>
              <option value="Cote d’Ivoire" <?php if($country== "Cote d’Ivoire") echo "selected"; ?>>Cote d’Ivoire</option>
              <option value="Croatia" <?php if($country== "Croatia") echo "selected"; ?>>Croatia</option>
              <option value="Cuba" <?php if($country== "Cuba") echo "selected"; ?>>Cuba</option>
              <option value="Cyprus" <?php if($country== "Cyprus") echo "selected"; ?>>Cyprus</option>
              <option value="Czechia" <?php if($country== "Czechia") echo "selected"; ?>>Czechia</option>
              <option value="Denmark" <?php if($country== "Denmark") echo "selected"; ?>>Denmark</option>
              <option value="Djibouti" <?php if($country== "Djibouti") echo "selected"; ?>>Djibouti</option>
              <option value="Dominica" <?php if($country== "Dominica") echo "selected"; ?>>Dominica</option>
              <option value="Dominican Republic" <?php if($country== "Dominican Republic") echo "selected"; ?>>Dominican Republic</option>
              <option value="Ecuador" <?php if($country== "Ecuador") echo "selected"; ?>>Ecuador</option>
              <option value="Egypt" <?php if($country== "Egypt") echo "selected"; ?>>Egypt</option>
              <option value="El Salvador" <?php if($country== "El Salvador") echo "selected"; ?>>El Salvador</option>
              <option value="Eritrea" <?php if($country== "Eritrea") echo "selected"; ?>>Eritrea</option>
              <option value="Estonia" <?php if($country== "Estonia") echo "selected"; ?>>Estonia</option>
              <option value="Ethiopia" <?php if($country== "Ethiopia") echo "selected"; ?>>Ethiopia</option>
              <option value="Fiji" <?php if($country== "Fiji") echo "selected"; ?>>Fiji</option>
              <option value="Finland" <?php if($country== "Finland") echo "selected"; ?>>Finland</option>
              <option value="France" <?php if($country== "France") echo "selected"; ?>>France</option>
              <option value="Gabon" <?php if($country== "Gabon") echo "selected"; ?>>Gabon</option>
              <option value="Gambia" <?php if($country== "Gambia") echo "selected"; ?>>Gambia</option>
              <option value="Georgia" <?php if($country== "Georgia") echo "selected"; ?>>Georgia</option>
              <option value="Germany" <?php if($country== "Germany") echo "selected"; ?>>Germany</option>
              <option value="Ghana" <?php if($country== "Ghana") echo "selected"; ?>>Ghana</option>
              <option value="Greece" <?php if($country== "Greece") echo "selected"; ?>>Greece</option>
              <option value="Greenland" <?php if($country== "Greenland") echo "selected"; ?>>Greenland</option>
              <option value="Grenada" <?php if($country== "Grenada") echo "selected"; ?>>Grenada</option>
              <option value="Guadeloupe" <?php if($country== "Guadeloupe") echo "selected"; ?>>Guadeloupe</option>
              <option value="Guam" <?php if($country== "Guam") echo "selected"; ?>>Guam</option>
              <option value="Guatemala" <?php if($country== "Guatemala") echo "selected"; ?>>Guatemala</option>
              <option value="Guinea" <?php if($country== "Guinea") echo "selected"; ?>>Guinea</option>
              <option value="Guinea Bissau" <?php if($country== "Guinea Bissau") echo "selected"; ?>>Guinea Bissau</option>
              <option value="Guyana" <?php if($country== "Guyana") echo "selected"; ?>>Guyana</option>
              <option value="Haiti" <?php if($country== "Haiti") echo "selected"; ?>>Haiti</option>
              <option value="Honduras" <?php if($country== "Honduras") echo "selected"; ?>>Honduras</option>
              <option value="Hungary" <?php if($country== "Hungary") echo "selected"; ?>>Hungary</option>
              <option value="Iceland" <?php if($country== "Iceland") echo "selected"; ?>>Iceland</option>
              <option value="India" <?php if($country== "India") echo "selected"; ?>>India</option>
              <option value="Indonesia" <?php if($country== "Indonesia") echo "selected"; ?>>Indonesia</option>
              <option value="Iraq" <?php if($country== "Iraq") echo "selected"; ?>>Iraq</option>
              <option value="Ireland" <?php if($country== "Ireland") echo "selected"; ?>>Ireland</option>
              <option value="Israel" <?php if($country== "Israel") echo "selected"; ?>>Israel</option>
              <option value="Italy" <?php if($country== "Italy") echo "selected"; ?>>Italy</option>
              <option value="Jamaica" <?php if($country== "Jamaica") echo "selected"; ?>>Jamaica</option>
              <option value="Japan" <?php if($country== "Japan") echo "selected"; ?>>Japan</option>
              <option value="Jordan" <?php if($country== "Jordan") echo "selected"; ?>>Jordan</option>
              <option value="Kazakhstan" <?php if($country== "Kazakhstan") echo "selected"; ?>>Kazakhstan</option>
              <option value="Kenya" <?php if($country== "Kenya") echo "selected"; ?>>Kenya</option>
              <option value="Kiribati" <?php if($country== "Kiribati") echo "selected"; ?>>Kiribati</option>
              <option value="Kosovo" <?php if($country== "Kosovo") echo "selected"; ?>>Kosovo</option>
              <option value="Kuwait" <?php if($country== "Kuwait") echo "selected"; ?>>Kuwait</option>
              <option value="Kyrgyzstan" <?php if($country== "Kyrgyzstan") echo "selected"; ?>>Kyrgyzstan</option>
              <option value="Laos" <?php if($country== "Laos") echo "selected"; ?>>Laos</option>
              <option value="Latvia" <?php if($country== "Latvia") echo "selected"; ?>>Latvia</option>
              <option value="Lebanon" <?php if($country== "Lebanon") echo "selected"; ?>>Lebanon</option>
              <option value="Lesotho" <?php if($country== "Lesotho") echo "selected"; ?>>Lesotho</option>
              <option value="Liberia" <?php if($country== "Liberia") echo "selected"; ?>>Liberia</option>
              <option value="Libya" <?php if($country== "Libya") echo "selected"; ?>>Libya</option>
              <option value="Liechtenstein" <?php if($country== "Liechtenstein") echo "selected"; ?>>Liechtenstein</option>
              <option value="Lithuania" <?php if($country== "Lithuania") echo "selected"; ?>>Lithuania</option>
              <option value="Luxembourg" <?php if($country== "Luxembourg") echo "selected"; ?>>Luxembourg</option>
              <option value="Macedonia" <?php if($country== "Macedonia") echo "selected"; ?>>Macedonia</option>
              <option value="Madagascar" <?php if($country== "Madagascar") echo "selected"; ?>>Madagascar</option>
              <option value="Malawi" <?php if($country== "Malawi") echo "selected"; ?>>Malawi</option>
              <option value="Malaysia" <?php if($country== "Malaysia") echo "selected"; ?>>Malaysia</option>
              <option value="Maldives" <?php if($country== "Maldives") echo "selected"; ?>>Maldives</option>
              <option value="Mali" <?php if($country== "Mali") echo "selected"; ?>>Mali</option>
              <option value="Malta" <?php if($country== "Malta") echo "selected"; ?>>Malta</option>
              <option value="Martinique" <?php if($country== "Martinique") echo "selected"; ?>>Martinique</option>
              <option value="Mauritania" <?php if($country== "Mauritania") echo "selected"; ?>>Mauritania</option>
              <option value="Mauritius" <?php if($country== "Mauritius") echo "selected"; ?>>Mauritius</option>
              <option value="Mexico" <?php if($country== "Mexico") echo "selected"; ?>>Mexico</option>
              <option value="Micronesia" <?php if($country== "Micronesia") echo "selected"; ?>>Micronesia</option>
              <option value="Moldova" <?php if($country== "Moldova") echo "selected"; ?>>Moldova</option>
              <option value="Monaco" <?php if($country== "Monaco") echo "selected"; ?>>Monaco</option>
              <option value="Mongolia" <?php if($country== "Mongolia") echo "selected"; ?>>Mongolia</option>
              <option value="Montenegro" <?php if($country== "Montenegro") echo "selected"; ?>>Montenegro</option>
              <option value="Morocco" <?php if($country== "Morocco") echo "selected"; ?>>Morocco</option>
              <option value="Mozambique" <?php if($country== "Mozambique") echo "selected"; ?>>Mozambique</option>
              <option value="Myanmar" <?php if($country== "Myanmar") echo "selected"; ?>>Myanmar</option>
              <option value="Namibia" <?php if($country== "Namibia") echo "selected"; ?>>Namibia</option>
              <option value="Nauru" <?php if($country== "Nauru") echo "selected"; ?>>Nauru</option>
              <option value="Nepal" <?php if($country== "Nepal") echo "selected"; ?>>Nepal</option>
              <option value="Netherlands" <?php if($country== "Netherlands") echo "selected"; ?>>Netherlands</option>
              <option value="New Caledonia" <?php if($country== "New Caledonia") echo "selected"; ?>>New Caledonia</option>
              <option value="New Zealand" <?php if($country== "New Zealand") echo "selected"; ?>>New Zealand</option>
              <option value="Nicaragua" <?php if($country== "Nicaragua") echo "selected"; ?>>Nicaragua</option>
              <option value="Niger" <?php if($country== "Niger") echo "selected"; ?>>Niger</option>
              <option value="Nigeria" <?php if($country== "Nigeria") echo "selected"; ?>>Nigeria</option>
              <option value="Niue" <?php if($country== "Niue") echo "selected"; ?>>Niue</option>
              <option value="Norway" <?php if($country== "Norway") echo "selected"; ?>>Norway</option>
              <option value="Oman" <?php if($country== "Oman") echo "selected"; ?>>Oman</option>
              <option value="Pakistan" <?php if($country== "Pakistan") echo "selected"; ?>>Pakistan</option>
              <option value="Palau" <?php if($country== "Palau") echo "selected"; ?>>Palau</option>
              <option value="Palestine" <?php if($country== "Palestine") echo "selected"; ?>>Palestine</option>
              <option value="Panama" <?php if($country== "Panama") echo "selected"; ?>>Panama</option>
              <option value="Papua New Guinea" <?php if($country== "Papua New Guinea") echo "selected"; ?>>Papua New Guinea</option>
              <option value="Paraguay" <?php if($country== "Paraguay") echo "selected"; ?>>Paraguay</option>
              <option value="Peru" <?php if($country== "Peru") echo "selected"; ?>>Peru</option>
              <option value="Philippines" <?php if($country== "Philippines") echo "selected"; ?>>Philippines</option>
              <option value="Poland" <?php if($country== "Poland") echo "selected"; ?>>Poland</option>
              <option value="Portugal" <?php if($country== "Portugal") echo "selected"; ?>>Portugal</option>
              <option value="Qatar" <?php if($country== "Qatar") echo "selected"; ?>>Qatar</option>
              <option value="Romania" <?php if($country== "Romania") echo "selected"; ?>>Romania</option>
              <option value="Russia" <?php if($country== "Russia") echo "selected"; ?>>Russia</option>
              <option value="Rwanda" <?php if($country== "Rwanda") echo "selected"; ?>>Rwanda</option>
              <option value="Saint Lucia" <?php if($country== "Saint Lucia") echo "selected"; ?>>Saint Lucia</option>
              <option value="Samoa" <?php if($country== "Samoa") echo "selected"; ?>>Samoa</option>
              <option value="San Marino" <?php if($country== "San Marino") echo "selected"; ?>>San Marino</option>
              <option value="Saudi Arabia" <?php if($country== "Saudi Arabia") echo "selected"; ?>>Saudi Arabia</option>
              <option value="Senegal" <?php if($country== "Senegal") echo "selected"; ?>>Senegal</option>
              <option value="Serbia" <?php if($country== "Serbia") echo "selected"; ?>>Serbia</option>
              <option value="Seychelles" <?php if($country== "Seychelles") echo "selected"; ?>>Seychelles</option>
              <option value="Sierra Leone" <?php if($country== "Sierra Leone") echo "selected"; ?>>Sierra Leone</option>
              <option value="Singapore" <?php if($country== "Singapore") echo "selected"; ?>>Singapore</option>
              <option value="Slovakia" <?php if($country== "Slovakia") echo "selected"; ?>>Slovakia</option>
              <option value="Slovenia" <?php if($country== "Slovenia") echo "selected"; ?>>Slovenia</option>
              <option value="Somalia" <?php if($country== "Somalia") echo "selected"; ?>>Somalia</option>
              <option value="South Africa" <?php if($country== "South Africa") echo "selected"; ?>>South Africa</option>
              <option value="South Korea" <?php if($country== "South Korea") echo "selected"; ?>>South Korea</option>
              <option value="Spain" <?php if($country== "Spain") echo "selected"; ?>>Spain</option>
              <option value="Sri Lanka" <?php if($country== "Sri Lanka") echo "selected"; ?>>Sri Lanka</option>
              <option value="Suriname" <?php if($country== "Suriname") echo "selected"; ?>>Suriname</option>
              <option value="Swaziland" <?php if($country== "Swaziland") echo "selected"; ?>>Swaziland</option>
              <option value="Sweden" <?php if($country== "Sweden") echo "selected"; ?>>Sweden</option>
              <option value="Switzerland" <?php if($country== "Switzerland") echo "selected"; ?>>Switzerland</option>
              <option value="Taiwan" <?php if($country== "Taiwan") echo "selected"; ?>>Taiwan</option>
              <option value="Tajikistan" <?php if($country== "Tajikistan") echo "selected"; ?>>Tajikistan</option>
              <option value="Tanzania" <?php if($country== "Tanzania") echo "selected"; ?>>Tanzania</option>
              <option value="Thailand" <?php if($country== "Thailand") echo "selected"; ?>>Thailand</option>
              <option value="United Arab Emirates" <?php if($country== "United Arab Emirates") echo "selected"; ?>>United Arab Emirates</option>
              <option value="Togo" <?php if($country== "Togo") echo "selected"; ?>>Togo</option>
              <option value="Tonga" <?php if($country== "Tonga") echo "selected"; ?>>Tonga</option>
              <option value="Trinidad and Tobago" <?php if($country== "Trinidad and Tobago") echo "selected"; ?>>Trinidad and Tobago</option>
              <option value="Tunisia" <?php if($country== "Tunisia") echo "selected"; ?>>Tunisia</option>
              <option value="Turkey" <?php if($country== "Turkey") echo "selected"; ?>>Turkey</option>
              <option value="Turkmenistan" <?php if($country== "Turkmenistan") echo "selected"; ?>>Turkmenistan</option>
              <option value="Tuvalu" <?php if($country== "Tuvalu") echo "selected"; ?>>Tuvalu</option>
              <option value="Uganda" <?php if($country== "Uganda") echo "selected"; ?>>Uganda</option>
              <option value="Ukraine" <?php if($country== "Ukraine") echo "selected"; ?>>Ukraine</option>
              <option value="United Kingdom" <?php if($country== "United Kingdom") echo "selected"; ?>>United Kingdom</option>
              <option value="United States" <?php if($country== "United States") echo "selected"; ?>>United States</option>
              <option value="Uruguay" <?php if($country== "Uruguay") echo "selected"; ?>>Uruguay</option>
              <option value="Uzbekistan" <?php if($country== "Uzbekistan") echo "selected"; ?>>Uzbekistan</option>
              <option value="Vanuatu" <?php if($country== "Vanuatu") echo "selected"; ?>>Vanuatu</option>
              <option value="Vatican City" <?php if($country== "Vatican City") echo "selected"; ?>>Vatican City</option>
              <option value="Venezuela" <?php if($country== "Venezuela") echo "selected"; ?>>Venezuela</option>
              <option value="Vietnam" <?php if($country== "Vietnam") echo "selected"; ?>>Vietnam</option>
              <option value="Yemen" <?php if($country== "Yemen") echo "selected"; ?>>Yemen</option>
              <option value="Zambia" <?php if($country== "Zambia") echo "selected"; ?>>Zambia</option>
              <option value="Zimbabwe" <?php if($country== "Zimbabwe") echo "selected"; ?>>Zimbabwe</option>
                    </select>
					</div>
					</div>
				
				<div class="row mb-2">
				<label class="col-sm-3 col-form-label">Language</label>
				<div class="col-sm-9">
				  <select name="language[]" id="language[]" class="selectpicker" multiple aria-label="Default select example" data-live-search="true">
							<option value="Arabic" <?php if($language== "Arabic") echo "selected"; ?>>Arabic</option>
              <option value="Bengali" <?php if($language== "Bengali") echo "selected"; ?>>Bengali</option>
              <option value="Bulgarian" <?php if($language== "Bulgarian") echo "selected"; ?>>Bulgarian</option>
              <option value="Catalan" <?php if($language== "Catalan") echo "selected"; ?>>Catalan</option>
              <option value="Chinese" <?php if($language== "Chinese") echo "selected"; ?>>Chinese</option>
              <option value="Croatian" <?php if($language== "Croatian") echo "selected"; ?>>Croatian</option>
              <option value="Czech" <?php if($language== "Czech") echo "selected"; ?>>Czech</option>
              <option value="Danish" <?php if($language== "Danish") echo "selected"; ?>>Danish</option>
              <option value="Dutch" <?php if($language== "Dutch") echo "selected"; ?>>Dutch</option>
              <option value="English" <?php if($language== "English") echo "selected"; ?>>English</option>
							<option value="Estonian" <?php if($language== "Estonian") echo "selected"; ?>>Estonian</option>
							<option value="Filipino" <?php if($language== "Filipino") echo "selected"; ?>>Filipino</option>
							<option value="Finnish" <?php if($language== "Finnish") echo "selected"; ?>>Finnish</option>
							<option value="French" <?php if($language== "French") echo "selected"; ?>>French</option>
							<option value="German" <?php if($language== "German") echo "selected"; ?>>German</option>
							<option value="Greek" <?php if($language== "Greek") echo "selected"; ?>>Greek</option>
							<option value="Gujarati" <?php if($language== "Gujarati") echo "selected"; ?>>Gujarati</option>
							<option value="Hebrew" <?php if($language== "Hebrew") echo "selected"; ?>>Hebrew</option>
							<option value="Hindi" <?php if($language== "Hindi") echo "selected"; ?>>Hindi</option>
							<option value="Hungarian" <?php if($language== "Hungarian") echo "selected"; ?>>Hungarian</option>
							<option value="Icelandic" <?php if($language== "Icelandic") echo "selected"; ?>>Icelandic</option>
							<option value="Indonesian" <?php if($language== "Indonesian") echo "selected"; ?>>Indonesian</option>
							<option value="Italian" <?php if($language== "Italian") echo "selected"; ?>>Italian</option>
							<option value="Japanese" <?php if($language== "Japanese") echo "selected"; ?>>Japanese</option>
							<option value="Kannada" <?php if($language== "Kannada") echo "selected"; ?>>Kannada</option>
							<option value="Korean" <?php if($language== "Korean") echo "selected"; ?>>Korean</option>
							<option value="Latvian" <?php if($language== "Latvian") echo "selected"; ?>>Latvian</option>
							<option value="Lithuanian" <?php if($language== "Lithuanian") echo "selected"; ?>>Lithuanian</option>
							<option value="Malay" <?php if($language== "Malay") echo "selected"; ?>>Malay</option>
							<option value="Malayalam" <?php if($language== "Malayalam") echo "selected"; ?>>Malayalam</option>
							<option value="Marathi" <?php if($language== "Marathi") echo "selected"; ?>>Marathi</option>
							<option value="Norwegian" <?php if($language== "Norwegian") echo "selected"; ?>>Norwegian</option>
							<option value="Persian" <?php if($language== "Persian") echo "selected"; ?>>Persian</option>
							<option value="Polish" <?php if($language== "Polish") echo "selected"; ?>>Polish</option>
							<option value="Portuguese" <?php if($language== "Portuguese") echo "selected"; ?>>Portuguese</option>
							<option value="Punjabi" <?php if($language== "Punjabi") echo "selected"; ?>>Punjabi</option>
							<option value="Romanian" <?php if($language== "Romanian") echo "selected"; ?>>Romanian</option>
							<option value="Russian" <?php if($language== "Russian") echo "selected"; ?>>Russian</option>
							<option value="Serbian" <?php if($language== "Serbian") echo "selected"; ?>>Serbian</option>
							<option value="Slovak" <?php if($language== "Slovak") echo "selected"; ?>>Slovak</option>
							<option value="Slovenian" <?php if($language== "Slovenian") echo "selected"; ?>>Slovenian</option>
							<option value="Spanish" <?php if($language== "Spanish") echo "selected"; ?>>Spanish</option>
							<option value="Swedish" <?php if($language== "Swedish") echo "selected"; ?>>Swedish</option>
							<option value="Tamil" <?php if($language== "Tamil") echo "selected"; ?>>Tamil</option>
							<option value="Telugu" <?php if($language== "Telugu") echo "selected"; ?>>Telugu</option>
							<option value="Thai" <?php if($language== "Thai") echo "selected"; ?>>Thai</option>
							<option value="Turkish" <?php if($language== "Turkish") echo "selected"; ?>>Turkish</option>
							<option value="Ukrainian" <?php if($language== "Ukrainian") echo "selected"; ?>>Ukrainian</option>
							<option value="Urdu" <?php if($language== "Urdu") echo "selected"; ?>>Urdu</option>
							<option value="Vietnamese" <?php if($language== "Vietnamese") echo "selected"; ?>>Vietnamese</option>
				  </select>
				</div>
					</div>
					
				<div class="row mb-2">
                  <label for="inputNumber" class="col-sm-3 col-form-label">First Image</label>
                  <div class="col-sm-9">
				<div class="image1">
				  <input
					type="file"
					name="image1"
					id="image1"
					class="file-input__input"/>
				  <label class="file-input__label" for="image1">
					<svg
					  aria-hidden="true"
					  focusable="false"
					  data-prefix="fas"
					  data-icon="upload"
					  class="svg-inline--fa fa-upload fa-w-16"
					  role="img"
					  xmlns="http://www.w3.org/2000/svg"
					  viewBox="0 0 512 512">
					  <path
						fill="currentColor"
						d="M296 384h-80c-13.3 0-24-10.7-24-24V192h-87.7c-17.8 0-26.7-21.5-14.1-34.1L242.3 5.7c7.5-7.5 19.8-7.5 27.3 0l152.2 152.2c12.6 12.6 3.7 34.1-14.1 34.1H320v168c0 13.3-10.7 24-24 24zm216-8v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h136v8c0 30.9 25.1 56 56 56h80c30.9 0 56-25.1 56-56v-8h136c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
					</svg>
					<span>Upload Image</span></label>
				</div>
				</div>
				</div>
				
				<div class="row mb-2">
                  <label for="inputNumber" class="col-sm-3 col-form-label">Second Image</label>
                  <div class="col-sm-9">
				<div class="image2">
				  <input
					type="file"
					name="image2"
					id="image2"
					class="file-input__input"/>
				  <label class="file-input__label" for="image2">
					<svg
					  aria-hidden="true"
					  focusable="false"
					  data-prefix="fas"
					  data-icon="upload"
					  class="svg-inline--fa fa-upload fa-w-16"
					  role="img"
					  xmlns="http://www.w3.org/2000/svg"
					  viewBox="0 0 512 512">
					  <path
						fill="currentColor"
						d="M296 384h-80c-13.3 0-24-10.7-24-24V192h-87.7c-17.8 0-26.7-21.5-14.1-34.1L242.3 5.7c7.5-7.5 19.8-7.5 27.3 0l152.2 152.2c12.6 12.6 3.7 34.1-14.1 34.1H320v168c0 13.3-10.7 24-24 24zm216-8v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h136v8c0 30.9 25.1 56 56 56h80c30.9 0 56-25.1 56-56v-8h136c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
					</svg>
					<span>Upload Image</span></label>
				</div>
				</div>
				</div>
				
				<div class="row mb-2">
                  <label for="inputNumber" class="col-sm-3 col-form-label">Third Image</label>
                  <div class="col-sm-9">
				<div class="image3">
				  <input
					type="file"
					name="image3"
					id="image3"
					class="file-input__input"/>
				  <label class="file-input__label" for="image3">
					<svg
					  aria-hidden="true"
					  focusable="false"
					  data-prefix="fas"
					  data-icon="upload"
					  class="svg-inline--fa fa-upload fa-w-16"
					  role="img"
					  xmlns="http://www.w3.org/2000/svg"
					  viewBox="0 0 512 512">
					  <path
						fill="currentColor"
						d="M296 384h-80c-13.3 0-24-10.7-24-24V192h-87.7c-17.8 0-26.7-21.5-14.1-34.1L242.3 5.7c7.5-7.5 19.8-7.5 27.3 0l152.2 152.2c12.6 12.6 3.7 34.1-14.1 34.1H320v168c0 13.3-10.7 24-24 24zm216-8v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h136v8c0 30.9 25.1 56 56 56h80c30.9 0 56-25.1 56-56v-8h136c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
					</svg>
					<span>Upload Image</span></label>
				</div>
				</div>
				</div>
				
				<div class="row mb-2">
                  <label for="inputNumber" class="col-sm-3 col-form-label">Fourth Image</label>
                  <div class="col-sm-9">
				<div class="image4">
				  <input
					type="file"
					name="image4"
					id="image4"
					class="file-input__input"/>
				  <label class="file-input__label" for="image4">
					<svg
					  aria-hidden="true"
					  focusable="false"
					  data-prefix="fas"
					  data-icon="upload"
					  class="svg-inline--fa fa-upload fa-w-16"
					  role="img"
					  xmlns="http://www.w3.org/2000/svg"
					  viewBox="0 0 512 512">
					  <path
						fill="currentColor"
						d="M296 384h-80c-13.3 0-24-10.7-24-24V192h-87.7c-17.8 0-26.7-21.5-14.1-34.1L242.3 5.7c7.5-7.5 19.8-7.5 27.3 0l152.2 152.2c12.6 12.6 3.7 34.1-14.1 34.1H320v168c0 13.3-10.7 24-24 24zm216-8v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h136v8c0 30.9 25.1 56 56 56h80c30.9 0 56-25.1 56-56v-8h136c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
					</svg>
					<span>Upload Image</span></label>
				</div>
				</div>
				</div>
				
        <div class="row mb-2">
      <label for="inputText" class="col-sm-3 col-form-label">URL</label>
      <div class="col-sm-9">
        <input type="url" name="url" class="form-control" placeholder="https://Where-Visitors-Redirected">
      </div>
    </div>

				<div class="row mb-4">
                  <label for="inputText" class="col-sm-3 col-form-label">Budget</label>
                  <div class="col-sm-9">
                    <input type="number" id="myRange" name="budget" id="budget" class="form-control">
                  </div>
                </div>
    			</div>
				<div class="row" style="place-content: center; padding-bottom: 2rem;">
					<button type="submit" name="submit"  class="paypal-buy-now-button" style="width: 200px;">
					   <span>Pay with</span> 
					   <svg aria-label="PayPal" xmlns="http://www.w3.org/2000/svg" width="90" height="33" viewBox="34.417 0 90 33">
						  <path fill="#253B80" d="M46.211 6.749h-6.839a.95.95 0 0 0-.939.802l-2.766 17.537a.57.57 0 0 0 .564.658h3.265a.95.95 0 0 0 .939-.803l.746-4.73a.95.95 0 0 1 .938-.803h2.165c4.505 0 7.105-2.18 7.784-6.5.306-1.89.013-3.375-.872-4.415-.972-1.142-2.696-1.746-4.985-1.746zM47 13.154c-.374 2.454-2.249 2.454-4.062 2.454h-1.032l.724-4.583a.57.57 0 0 1 .563-.481h.473c1.235 0 2.4 0 3.002.704.359.42.469 1.044.332 1.906zM66.654 13.075h-3.275a.57.57 0 0 0-.563.481l-.146.916-.229-.332c-.709-1.029-2.29-1.373-3.868-1.373-3.619 0-6.71 2.741-7.312 6.586-.313 1.918.132 3.752 1.22 5.03.998 1.177 2.426 1.666 4.125 1.666 2.916 0 4.533-1.875 4.533-1.875l-.146.91a.57.57 0 0 0 .562.66h2.95a.95.95 0 0 0 .939-.804l1.77-11.208a.566.566 0 0 0-.56-.657zm-4.565 6.374c-.316 1.871-1.801 3.127-3.695 3.127-.951 0-1.711-.305-2.199-.883-.484-.574-.668-1.392-.514-2.301.295-1.855 1.805-3.152 3.67-3.152.93 0 1.686.309 2.184.892.499.589.697 1.411.554 2.317zM84.096 13.075h-3.291a.955.955 0 0 0-.787.417l-4.539 6.686-1.924-6.425a.953.953 0 0 0-.912-.678H69.41a.57.57 0 0 0-.541.754l3.625 10.638-3.408 4.811a.57.57 0 0 0 .465.9h3.287a.949.949 0 0 0 .781-.408l10.946-15.8a.57.57 0 0 0-.469-.895z"></path>
						  <path fill="#179BD7" d="M94.992 6.749h-6.84a.95.95 0 0 0-.938.802l-2.767 17.537a.57.57 0 0 0 .563.658h3.51a.665.665 0 0 0 .656-.563l.785-4.971a.95.95 0 0 1 .938-.803h2.164c4.506 0 7.105-2.18 7.785-6.5.307-1.89.012-3.375-.873-4.415-.971-1.141-2.694-1.745-4.983-1.745zm.789 6.405c-.373 2.454-2.248 2.454-4.063 2.454h-1.031l.726-4.583a.567.567 0 0 1 .562-.481h.474c1.233 0 2.399 0 3.002.704.358.42.467 1.044.33 1.906zM115.434 13.075h-3.272a.566.566 0 0 0-.562.481l-.146.916-.229-.332c-.709-1.029-2.289-1.373-3.867-1.373-3.619 0-6.709 2.741-7.312 6.586-.312 1.918.131 3.752 1.22 5.03 1 1.177 2.426 1.666 4.125 1.666 2.916 0 4.532-1.875 4.532-1.875l-.146.91a.57.57 0 0 0 .563.66h2.949a.95.95 0 0 0 .938-.804l1.771-11.208a.57.57 0 0 0-.564-.657zm-4.565 6.374c-.314 1.871-1.801 3.127-3.695 3.127-.949 0-1.711-.305-2.199-.883-.483-.574-.666-1.392-.514-2.301.297-1.855 1.805-3.152 3.67-3.152.93 0 1.686.309 2.184.892.501.589.699 1.411.554 2.317zM119.295 7.23l-2.807 17.858a.569.569 0 0 0 .562.658h2.822c.469 0 .866-.34.938-.803l2.769-17.536a.57.57 0 0 0-.562-.659h-3.16a.571.571 0 0 0-.562.482z"></path>
					   </svg>
					</button>
                </div>
                 </div> </div> </div> </div> </div>
</form>
				 <p style="font-size: 0.8em;text-align: center; margin-top: 0.6rem;">Topad.net © <?php echo date("Y"); ?></p> 
		<script src="js/template.js"></script>
		<script src="js/file-upload.js"></script>
		<script src="js/typeahead.js"></script>
		<script src="js/select2.js"></script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js"></script>
<script>
$(document).ready(function() {

          var last_valid_selection = null;

          $('#category[]').change(function(event) {

            if ($(this).val().length > 3) {

              $(this).val(last_valid_selection);
            } else {
              last_valid_selection = $(this).val();
            }
          });
        });
</script>
</body></html>
