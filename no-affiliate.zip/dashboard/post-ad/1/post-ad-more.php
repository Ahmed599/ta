<?php
if(!isset($_SESSION)) 
{ 
    session_start(); 
}
?>
<?php
        
$msg = $msg_class = $category = $language= $duration = $country = $size1 = $size2 = $size3 = $size4 = '';
$zero = 0;

if (isset($_POST['submit'])) {

    function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

    //$ad_redirect = test_input($_GET['a']);

    
    // NEW NEW NEW NEW NEW 

    $im1 = $_FILES['image1']['name'];
    $im2 = $_FILES['image2']['name'];
    $im3 = $_FILES['image3']['name'];
    $im4 = $_FILES['image4']['name'];

    $ext1 = pathinfo($im1, PATHINFO_EXTENSION);
    $ext2 = pathinfo($im2, PATHINFO_EXTENSION);
    $ext3 = pathinfo($im3, PATHINFO_EXTENSION);
    $ext4 = pathinfo($im4, PATHINFO_EXTENSION);

    //

    $image1 = rand(10000,time()) . '-' . md5(($_FILES["image1"]["name"]) . rand(1,100)) . '.' . $ext1;
    $image2 = rand(10000,time()) . '-' . md5(($_FILES["image2"]["name"]) . rand(1,100)) . '.' . $ext2;
    $image3 = rand(10000,time()) . '-' . md5(($_FILES["image3"]["name"]) . rand(1,100)) . '.' . $ext3;
    $image4 = rand(10000,time()) . '-' . md5(($_FILES["image4"]["name"]) . rand(1,100)) . '.' . $ext4;
    $campaign_name = test_input($_POST['campaign_name']);
    $description = test_input($_POST['description']);
    //$duration = test_input($_POST['duration']);
    $campaign_name = $_POST['campaign_name'];
    $description = $_POST['description'];
    //$duration = $_POST['duration'];
    $url = $_POST['url'];
    if(!(empty(($_POST["category"])))){
        //$category = implode(', ', test_input($_POST['category']));
        $category = implode(', ', $_POST['category']);
        //$category = $_POST['category'];
    }
    if(!(empty(($_POST["language"])))){
        //$language = implode(', ', test_input($_POST['language']));
        $language = implode(', ', $_POST['language']);
        //$language = $_POST['language'];
    }
    if(!(empty(($_POST["country"])))){
        //$country = implode(', ', test_input($_POST['country']));
        $country = implode(', ', $_POST['country']);
        //$country = $_POST['country'];
    }
    $budget = test_input($_POST['budget']);
    $budget = $_POST['budget'];
    $size1 = $size2 = $size3 = $size4 = '0';
    $adv_id = $_SESSION['id'];

    function validate_url($url) {
        $path = parse_url($url, PHP_URL_PATH);
        $encoded_path = array_map('urlencode', explode('/', $path));
        $url = str_replace($path, implode('/', $encoded_path), $url);
        return filter_var($url, FILTER_VALIDATE_URL) ? true : false;
    }


    /* For image1 upload */

    if(!(empty($_FILES['image1']['name']))){
        $target_dir = "../../../images/";
        $target_file = $target_dir . basename($image1);
        $initdata = file_get_contents($_FILES["image1"]["tmp_name"]);
        $data = \getimagesizefromstring($initdata);
        $width = ($data[0]);
        $height = ($data[1]);
    }


    /* For image2 upload */

    if(!(empty($_FILES['image2']['name']))){
        $target_dir1 = "../../../images/";
        $target_file1 = $target_dir1 . basename($image2);
        $initdata1 = file_get_contents($_FILES["image2"]["tmp_name"]);
        $data1 = \getimagesizefromstring($initdata1);
        $width1 = ($data1[0]);
        $height1 = ($data1[1]);
    }


    /* For image3 upload*/

    if(!(empty($_FILES['image3']['name']))){
        $target_dir2 = "../../../images/";
        $target_file2 = $target_dir2 . basename($image3);
        $initdata2 = file_get_contents($_FILES["image3"]["tmp_name"]);
        $data2 = \getimagesizefromstring($initdata2);
        $width2 = ($data2[0]);
        $height2 = ($data2[1]);
    }


    /* For image4 upload */

    if(!(empty($_FILES['image4']['name']))){
        $target_dir3 = "../../../images/";
        $target_file3 = $target_dir3 . basename($image4);
        $initdata3 = file_get_contents($_FILES["image4"]["tmp_name"]);
        $data3 = \getimagesizefromstring($initdata3);
        $width3 = ($data3[0]);
        $height3 = ($data3[1]);
    }

    // NEW NEW NEW NEW NEW 

    /*if(!(empty($_FILES['image1']['name']))){
        if(@is_array(getimagesize($initdata))){
        } else {
            $msg = "Please select a real image."; 
            $msg_class = "alert-danger";
        }
    }
    if(!(empty($_FILES['image2']['name']))){
        if(@is_array(getimagesize($initdata1))){
        } else {
            $msg = "Please select a real image."; 
            $msg_class = "alert-danger";
        }
    }
    if(!(empty($_FILES['image3']['name']))){
        if(@is_array(getimagesize($initdata2))){
        } else {
            $msg = "Please select a real image."; 
            $msg_class = "alert-danger";
        }
    }
    if(!(empty($_FILES['image4']['name']))){
        if(@is_array(getimagesize($initdata3))){
        } else {
            $msg = "Please select a real image."; 
            $msg_class = "alert-danger";
        }
    }*/

    ///////

    /*if(!(empty($_FILES['image2']['name']))){
        if(@is_array(getimagesize($initdata1))){
        } else {
            $msg = "Please select a real image."; 
            $msg_class = "alert-danger";
        }
    }
    if(!(empty($_FILES['image3']['name']))){
        if(@is_array(getimagesize($initdata2))){
        } else {
            $msg = "Please select a real image."; 
            $msg_class = "alert-danger";
        }
    }
    if(!(empty($_FILES['image4']['name']))){
        if(@is_array(getimagesize($initdata3))){
        } else {
            $msg = "Please select a real image."; 
            $msg_class = "alert-danger";
        }
    }*/



    if(!(empty($_FILES['image1']['name']))){
        if (($width == "728" and $height == "90") or ($width <= "728" and $height <= "90" and ($width/$height) > (0.8*(728/90)))){
            $size1 = "1";
        }elseif(($width == "970" and $height == "250") or ($width <= "970" and $height <= "250" and ($width/$height) > (0.8*(970/250)))){
            $size1 = "2";
        }elseif(($width == "300" and $height == "250") or ($width <= "300" and $height <= "250" and ($width/$height) > (0.8*(300/250)))){
            $size1 = "3";
        }elseif(($width == "300" and $height == "600") or ($width <= "300" and $height <= "600" and ($width/$height) > (0.8*(300/600)))){
            $size1 = "4";
        }elseif(($width == "160" and $height == "600") or ($width <= "160" and $height <= "600" and ($width/$height) > (0.8*(160/600)))){
            $size1 = "5";
        }
    }
    if(!(empty($_FILES['image2']['name']))){
        if (($width1 == "728" and $height1 == "90") or ($width1 <= "728" and $height1 <= "90" and ($width1/$height1) > (0.8*(728/90)))){
            $size2 = "1";
        }elseif(($width1 == "970" and $height1 == "250") or ($width1 <= "970" and $height1 <= "250" and ($width1/$height1) > (0.8*(970/250)))){
            $size2 = "2";
        }elseif(($width1 == "300" and $height1 == "250") or ($width1 <= "300" and $height1 <= "250" and ($width1/$height1) > (0.8*(300/250)))){
            $size2 = "3";
        }elseif(($width1 == "300" and $height1 == "600") or ($width1 <= "300" and $height1 <= "600" and ($width1/$height1) > (0.8*(300/600)))){
            $size2 = "4";
        }elseif(($width1 == "160" and $height1 == "600") or ($width1 <= "160" and $height1 <= "600" and ($width1/$height1) > (0.8*(160/600)))){
            $size2 = "5";
        }
    }
    if(!(empty($_FILES['image3']['name']))){
        if (($width2 == "728" and $height2 == "90") or ($width2 <= "728" and $height2 <= "90" and ($width2/$height2) > (0.8*(728/90)))){
            $size3 = "1";
        }elseif(($width2 == "970" and $height2 == "250") or ($width2 <= "970" and $height2 <= "250" and ($width2/$height2) > (0.8*(970/250)))){
            $size3 = "2";
        }elseif(($width2 == "300" and $height2 == "250") or ($width2 <= "300" and $height2 <= "250" and ($width2/$height2) > (0.8*(300/250)))){
            $size3 = "3";
        }elseif(($width2 == "300" and $height2 == "600") or ($width2 <= "300" and $height2 <= "600" and ($width2/$height2) > (0.8*(300/600)))){
            $size3 = "4";
        }elseif(($width2 == "160" and $height2 == "600") or ($width2 <= "160" and $height2 <= "600" and ($width2/$height2) > (0.8*(160/600)))){
            $size3 = "5";
        }
    }
    if(!(empty($_FILES['image4']['name']))){
        if (($width3 == "728" and $height3 == "90") or ($width3 <= "728" and $height3 <= "90" and ($width3/$height3) > (0.8*(728/90)))){
            $size4 = "1";
        }elseif(($width3 == "970" and $height3 == "250") or ($width3 <= "970" and $height3 <= "250" and ($width3/$height3) > (0.8*(970/250)))){
            $size4 = "2";
        }elseif(($width3 == "300" and $height3 == "250") or ($width3 <= "300" and $height3 <= "250" and ($width3/$height3) > (0.8*(300/250)))){
            $size4 = "3";
        }elseif(($width3 == "300" and $height3 == "600") or ($width3 <= "300" and $height3 <= "600" and ($width3/$height3) > (0.8*(300/600)))){
            $size4 = "4";
        }elseif(($width3 == "160" and $height3 == "600") or ($width3 <= "160" and $height3 <= "600" and ($width3/$height3) > (0.8*(160/600)))){
            $size4 = "5";
        }
    }

    if(!(empty($_FILES['image1']['name']))){
        if (!($width == "728" and $height == "90") and !($width == "970" and $height == "250") and 
        !($width == "300" and $height == "600") and !($width == "160" and $height == "600") and 
        !($width == "300" and $height == "250") and !($width <= "728" and $height <= "90" and ($width/$height) > (0.8*(728/90))) and 
        !($width <= "970" and $height <= "250" and ($width/$height) > (0.8*(970/250))) and !($width <= "300" and $height <= "250" and ($width/$height) > (0.8*(300/250))) and
        !($width <= "300" and $height <= "600" and ($width/$height) > (0.8*(300/600))) and !($width <= "160" and $height <= "600" and ($width/$height) > (0.8*(160/600))))
        {
            $msg = "Try to upload images with sizes close to (728x90), (970x250), (300x600), (160x600) or (300x250).";
            $msg_class = "alert-danger";
        }
    }

    if(!(empty($_FILES['image2']['name']))){
        if (!($width1 == "728" and $height1 == "90") and !($width1 == "970" and $height1 == "250") and 
        !($width1 == "300" and $height1 == "600") and !($width1 == "160" and $height1 == "600") and 
        !($width1 == "300" and $height1 == "250") and !($width1 <= "728" and $height1 <= "90" and ($width1/$height1) > (0.8*(728/90))) and 
        !($width1 <= "970" and $height1 <= "250" and ($width1/$height1) > (0.8*(970/250))) and !($width1 <= "300" and $height1 <= "250" and ($width1/$height1) > (0.8*(300/250))) and
        !($width1 <= "300" and $height1 <= "600" and ($width1/$height1) > (0.8*(300/600))) and !($width1 <= "160" and $height1 <= "600" and ($width1/$height1) > (0.8*(160/600))))
        {
            $msg = "Try to upload images with sizes close to (728x90), (970x250), (300x600), (160x600) or (300x250).";
            $msg_class = "alert-danger";
        }
    }

    if(!(empty($_FILES['image3']['name']))){
        if (!($width2 == "728" and $height2 == "90") and !($width2 == "970" and $height2 == "250") and 
        !($width2 == "300" and $height2 == "600") and !($width2 == "160" and $height2 == "600") and 
        !($width2 == "300" and $height2 == "250") and !($width2 <= "728" and $height2 <= "90" and ($width2/$height2) > (0.8*(728/90))) and 
        !($width2 <= "970" and $height2 <= "250" and ($width2/$height2) > (0.8*(970/250))) and !($width2 <= "300" and $height2 <= "250" and ($width2/$height2) > (0.8*(300/250))) and
        !($width2 <= "300" and $height2 <= "600" and ($width2/$height2) > (0.8*(300/600))) and !($width2 <= "160" and $height2 <= "600" and ($width2/$height2) > (0.8*(160/600))))
        {
            $msg = "Try to upload images with sizes close to (728x90), (970x250), (300x600), (160x600) or (300x250).";
            $msg_class = "alert-danger";
        }
    }

    if(!(empty($_FILES['image4']['name']))){
        if (!($width3 == "728" and $height3 == "90") and !($width3 == "970" and $height3 == "250") and 
        !($width3 == "300" and $height3 == "600") and !($width3 == "160" and $height3 == "600") and 
        !($width3 == "300" and $height3 == "250") and !($width3 <= "728" and $height3 <= "90" and ($width3/$height3) > (0.8*(728/90))) and 
        !($width3 <= "970" and $height3 <= "250" and ($width3/$height3) > (0.8*(970/250))) and !($width3 <= "300" and $height3 <= "250" and ($width3/$height3) > (0.8*(300/250))) and
        !($width3 <= "300" and $height3 <= "600" and ($width3/$height3) > (0.8*(300/600))) and !($width3 <= "160" and $height3 <= "600" and ($width3/$height3) > (0.8*(160/600))))
        {
            $msg = "Try to upload images with sizes close to (728x90), (970x250), (300x600), (160x600) or (300x250).";
            $msg_class = "alert-danger";
        }
    }


    elseif((empty($_FILES['image1']['name'])) && (empty($_FILES['image2']['name'])) && (empty($_FILES['image3']['name'])) && (empty($_FILES['image4']['name']))){
        $msg = "Please select an image."; 
        $msg_class = "alert-danger";
    }

    elseif(empty(trim($_POST["campaign_name"]))){ 
        $msg = "Please enter a name for your advertising campaign."; 
        $msg_class = "alert-danger";
    }
    /*elseif(empty(trim($_POST["duration"]))){ 
        $msg = "Please set a duration for your advertising campaign."; 
        $msg_class = "alert-danger";
    }*/
    elseif(empty(trim($_POST["description"]))){
        $msg = "Please enter your campaign description."; 
        $msg_class = "alert-danger";
    }
    elseif(empty(array_filter($_POST["category"]))){
        $msg = "Please choose matching categories for your campaign."; 
        $msg_class = "alert-danger";
    }
    elseif(empty(array_filter($_POST["country"]))){
        $msg = "Please choose your target clients countries."; 
        $msg_class = "alert-danger";
    }
    elseif(empty(array_filter($_POST["language"]))){
        $msg = "Please choose your target clients languages."; 
        $msg_class = "alert-danger";
    }
    elseif((empty(trim($_POST["url"]))) or (!validate_url($_POST["url"]))){
        $msg = "Please enter your website/page URL."; 
        $msg_class = "alert-danger";
    }
    elseif(empty(trim($_POST["budget"]))){
        $msg = "Please set your budget."; 
        $msg_class = "alert-danger";
    }


    elseif( is_int($budget) && (5 <= $budget) && ($budget <= 10000)) {
        $msg = "Please set a real budget.";
        $msg_class = "alert-danger";
    }

    $campaign_name = htmlspecialchars($campaign_name, ENT_QUOTES, 'UTF-8');
    //$duration = htmlspecialchars($duration, ENT_QUOTES, 'UTF-8');
    $description = htmlspecialchars($description, ENT_QUOTES, 'UTF-8');
    //$category = htmlspecialchars($category, ENT_QUOTES, 'UTF-8');
    //$country = htmlspecialchars($country, ENT_QUOTES, 'UTF-8');
    //$language = htmlspecialchars($language, ENT_QUOTES, 'UTF-8');

    $url = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    $budget = htmlspecialchars($budget, ENT_QUOTES, 'UTF-8');

    $redirect = md5($_SESSION['email'] . time());
    $paypal_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; 
    //$paypal_email = 'mariam@topad.net';
    $paypal_email = '26dec@26dec.com';

    require 'add-ad.php';

    if (empty($msg)) {
        $host     = "127.0.0.1:3306";//Ip of database, in this case my host machine    
        $user     = "root";	//Username to use
        $pass     = "";//Password for that user
        $dbname   = "topadn6_project";//Name of the database

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if(!(empty($_FILES['image1']['name'])) and !(empty($_FILES['image2']['name'])) and !(empty($_FILES['image3']['name'])) and !(empty($_FILES['image4']['name']))){

        require 'cases/case1.php';
    }


    if((empty($_FILES['image1']['name'])) and !(empty($_FILES['image2']['name'])) and !(empty($_FILES['image3']['name'])) and !(empty($_FILES['image4']['name']))){

        require 'cases/case2.php';
    }



    if(!(empty($_FILES['image1']['name'])) and (empty($_FILES['image2']['name'])) and !(empty($_FILES['image3']['name'])) and !(empty($_FILES['image4']['name']))){

        require 'cases/case3.php';
    }


    if(!(empty($_FILES['image1']['name'])) and !(empty($_FILES['image2']['name'])) and (empty($_FILES['image3']['name'])) and !(empty($_FILES['image4']['name']))){

        require 'cases/case4.php';
    }


    if(!(empty($_FILES['image1']['name'])) and !(empty($_FILES['image2']['name'])) and !(empty($_FILES['image3']['name'])) and (empty($_FILES['image4']['name']))){

        require 'cases/case5.php';
    }


    if(!(empty($_FILES['image1']['name'])) and !(empty($_FILES['image2']['name'])) and (empty($_FILES['image3']['name'])) and (empty($_FILES['image4']['name']))){

        require 'cases/case6.php';
    }


    if(!(empty($_FILES['image1']['name'])) and (empty($_FILES['image2']['name'])) and !(empty($_FILES['image3']['name'])) and (empty($_FILES['image4']['name']))){

        require 'cases/case7.php';
    }


    if(!(empty($_FILES['image1']['name'])) and (empty($_FILES['image2']['name'])) and (empty($_FILES['image3']['name'])) and !(empty($_FILES['image4']['name']))){

        require 'cases/case8.php';
    }



    if((empty($_FILES['image1']['name'])) and !(empty($_FILES['image2']['name'])) and !(empty($_FILES['image3']['name'])) and (empty($_FILES['image4']['name']))){

        require 'cases/case9.php';
            
    }



    if((empty($_FILES['image1']['name'])) and !(empty($_FILES['image2']['name'])) and (empty($_FILES['image3']['name'])) and !(empty($_FILES['image4']['name']))){
            
        require 'cases/case10.php';

    }


    if((empty($_FILES['image1']['name'])) and (empty($_FILES['image2']['name'])) and !(empty($_FILES['image3']['name'])) and !(empty($_FILES['image4']['name']))){
            
        require 'cases/case11.php';

    }


    if(!(empty($_FILES['image1']['name'])) and (empty($_FILES['image2']['name'])) and (empty($_FILES['image3']['name'])) and (empty($_FILES['image4']['name']))){
        
        require 'cases/case12.php';

    }


    if((empty($_FILES['image1']['name'])) and !(empty($_FILES['image2']['name'])) and (empty($_FILES['image3']['name'])) and (empty($_FILES['image4']['name']))){
            
        require 'cases/case13.php';

    }


    if((empty($_FILES['image1']['name'])) and (empty($_FILES['image2']['name'])) and !(empty($_FILES['image3']['name'])) and (empty($_FILES['image4']['name']))){
        
        require 'cases/case14.php';

    }


    if((empty($_FILES['image1']['name'])) and (empty($_FILES['image2']['name'])) and (empty($_FILES['image3']['name'])) and !(empty($_FILES['image4']['name']))){
            
        require 'cases/case15.php';

    }


    }catch(PDOException $e){
        echo $e->getMessage();
        
        }
    }
}
?>
