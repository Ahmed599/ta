<?php
//$sql = "INSERT INTO ads_normal (views, clicks, image1, image2, image3, image4, description, campaign_name, url, category, budget, spent, language, country, size1, size2, size3, size4, adv_id, keywords, redirect, remains) VALUES (:views, :clicks, :image1, :image2, :image3, :image4, :description, :campaign_name, :url, :category, :budget, :spent, :language, :country, :size1, :size2, :size3, :size4, :adv_id, :keywords, :redirect, :budget)";
$sql = "INSERT INTO ads_normal (type, adv_id, campaign_name, description, payment, category, country, language, image1, image2, image3, image4, size1, size2, size3, size4, views1, views2, views3, views4, clicks1, clicks2, clicks3, clicks4, url, budget, spent, remains, totalspent, views, total_views, clicks, status, redirect, paid, step, active, pastspent) VALUES (:type, :adv_id, :campaign_name, :description, :payment, :category, :country, :language, :image1, :image2, :image3, :image4, :size1, :size2, :size3, :size4, :views1, :views2, :views3, :views4, :clicks1, :clicks2, :clicks3, :clicks4, :url, :budget, :spent, :remains, :totalspent, :views, :total_views, :clicks, :status, :redirect, :paid, :step, :active, :pastspent)";	
if($stmt = $pdo->prepare($sql)){
// Bind variables to the prepared statement as parameters
$stmt->bindParam(":views", $param_views, PDO::PARAM_STR);
$stmt->bindParam(":clicks", $param_clicks, PDO::PARAM_STR);
$stmt->bindParam(":image1", $zero, PDO::PARAM_STR);
$stmt->bindParam(":image2", $param_image2, PDO::PARAM_STR);
$stmt->bindParam(":image3", $param_image3, PDO::PARAM_STR);
$stmt->bindParam(":image4", $param_image4, PDO::PARAM_STR);
$stmt->bindParam(":description", $param_description, PDO::PARAM_STR);
$stmt->bindParam(":campaign_name", $param_campaign_name, PDO::PARAM_STR);
$stmt->bindParam(":url", $param_url, PDO::PARAM_STR);
$stmt->bindParam(":category", $param_category, PDO::PARAM_STR);
$stmt->bindParam(":budget", $param_budget, PDO::PARAM_STR);
$stmt->bindParam(":spent", $param_spent, PDO::PARAM_STR);
$stmt->bindParam(":language", $param_language, PDO::PARAM_STR);
$stmt->bindParam(":country", $param_country, PDO::PARAM_STR);
$stmt->bindParam(":size1", $zero, PDO::PARAM_STR);
$stmt->bindParam(":size2", $param_size2, PDO::PARAM_STR);
$stmt->bindParam(":size3", $param_size3, PDO::PARAM_STR);
$stmt->bindParam(":size4", $param_size4, PDO::PARAM_STR);
$stmt->bindParam(":adv_id", $param_adv_id, PDO::PARAM_STR);
$stmt->bindParam(":redirect", $param_redirect, PDO::PARAM_STR);

$stmt->bindParam(":payment", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":views1", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":views2", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":views3", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":views4", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":clicks1", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":clicks2", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":clicks3", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":clicks4", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":totalspent", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":total_views", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":status", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":paid", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":step", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":active", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":pastspent", $param_zero, PDO::PARAM_STR);
$stmt->bindParam(":remains", $param_budget, PDO::PARAM_STR);
$stmt->bindParam(":type", $param_type, PDO::PARAM_STR);	
$param_type = $type;
$param_zero = $zero;
$param_redirect = $redirect;
$param_views = $views;
$param_clicks = $clicks;
$param_image2 = $fileName2;
$param_image3 = $fileName3;
$param_image4 = $fileName4;
$param_description = $description;
$param_campaign_name = $campaign_name;
$param_url = $url;
$param_category = $category;
$param_budget = $budget;
$param_spent = $spent;
$param_language = $language;
$param_country = $country;
$param_size2 = $size2;
$param_size3 = $size3;
$param_size4 = $size4;
$param_adv_id = $adv_id;

if($stmt->execute()){
            echo "<form action=\"$paypal_url\" id=\"form\" method=\"post\" enctype=\"multipart/form-data\">
            <!-- Paypal business test account email id so that you can collect the payments. -->
            <input type=\"hidden\" name=\"business\" value=\"$paypal_email\">
            <!-- Buy Now button. -->
            <input type=\"hidden\" name=\"cmd\" value=\"_xclick\">
            <input type=\"hidden\" name=\"item_name\" value=\"Advertising service\">
            <input type=\"hidden\" name=\"item_number\" value=\"1\">
            <input type=\"hidden\" name=\"currency_code\" value=\"USD\">
            <input type=\"hidden\" id=\"amount\" name=\"amount\" value=\"$budget\">
            <!-- URLs -->
            <input type='hidden' name='cancel_return' value='http://www.topad.net/dashboard/'>
            <input type='hidden' name='return' value='http://www.topad.net/val/?a=$redirect&r=$adv_id'>
            <!-- payment button. -->
            </form>
            <script type=\"text/javascript\">
            document.getElementById('form').submit(); // SUBMIT FORM
            </script>";

  //header("location: profiles.php");
}
// Attempt to execute the prepared statement

unset($stmt);
}
unset($pdo);
?>