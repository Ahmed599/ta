<html lang="en">
<head>
<meta charset="UTF-8">
<title>Choose your advertising strategy - Topad.net</title>
<meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style class="INLINE_PEN_STYLESHEET_ID"> body {
}
p {
  margin-top: 0rem;
  margin-bottom: 0rem;
}
a { color: #000;
text-decoration: auto;
}
a:hover, a:active, a:focus { color:#000;
}
@-webkit-keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
@keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
h1 { font-size: 3em; font-weight: bold;
}
h3 { display: block; font-size: 1.5em; margin-left: 0; margin-right: 0; font-weight: bold;
}
.h-100 { margin: 0;
	/*height: 100%!important;*/
}
.text-white {
    color: #6a6e72!important;
}
.cent {
    margin-top: 2rem!important;
    margin-bottom: 2rem!important;
}
.bottom {
font-size: 0.8rem;
color: #6a6e72;
text-decoration: auto;
}
footer {
  text-align: center;
  padding: 3px;
  color: white;
}
  </style>
</head>
<body>
<div class="header">
<a href="../../" style="float: left;"><h2 class="fw-light m-3" style="color: #559ade; font-size: 2rem;">TopAd</h2></a></div>
<div class="d-flex flex-column justify-content-center w-100">
<div class="d-flex flex-column justify-content-center align-items-center" style="padding: 1rem;">
<h2 class="fw-light text-white m-3" style="text-align: -webkit-center;font-weight: 400!important;">Set Your Strategy :)</h2>
<h3 style="padding-right: 10%;padding-left: 10%;text-align: center;font-size: 1.3rem;max-width: 1360px;padding-bottom: 1rem;" class="fw-light text-white m-2">What do you really want from your advertising campaign?</h3>
<br><div class="btn-group cent" style="margin-top: 1rem!important;text-align: -webkit-center;margin-bottom: 1rem!important;">
  <h4 style="padding-right: 10%;padding-left: 10%;text-align: center;font-size: 1.3rem;max-width: 1360px;padding-bottom: 1rem;" class="fw-light text-white m-2">$0.001 per view | $0.08 per click</h4>
<span style="width: 1rem;"></span>
<a href="1/"><button class="btn btn-outline-dark" style="border-top-left-radius: 4px;border-bottom-left-radius: 4px;padding: 0.6rem;max-width: 364px;">Show people your ad and if someone is interested, he can click and visit your webpage</button></a>
</div>
<div class="btn-group cent" style="margin-top: 1rem!important;text-align: -webkit-center;margin-bottom: 1rem!important;">
    <h4 style="padding-right: 10%;padding-left: 10%;text-align: center;font-size: 1.3rem;max-width: 1360px;padding-bottom: 1rem;" class="fw-light text-white m-2">$0.001 per view | $0.00 per click</h4>
<span style="width: 1rem;"></span>
<a href="2/"><button class="btn btn-outline-dark" style="border-top-left-radius: 4px;border-bottom-left-radius: 4px;padding: 0.6rem;max-width: 364px;">Show people your ad without any need to redirect them to a webpage</button></a>
</div><div class="btn-group cent" style="margin-top: 1rem!important;text-align: -webkit-center;margin-bottom: 1rem!important;">
    <h4 style="padding-right: 10%;padding-left: 10%;text-align: center;font-size: 1.3rem;max-width: 1360px;padding-bottom: 1rem;" class="fw-light text-white m-2">$0.00 per view | $0.12 per click</h4>
<span style="width: 1rem;"></span>
<a href="3/"><button class="btn btn-outline-dark" style="border-top-left-radius: 4px;border-bottom-left-radius: 4px;padding: 0.6rem;max-width: 364px;">More visits to your webpage and do not care about how many people saw your ad</button></a>
</div> 
</div>
</div>
<div style="text-align: -webkit-center;"><hr style="width:35%;"></div>
<footer>
<p class="fw-light text-white bottom" style="text-align: -webkit-center;">Topad.net © <?php echo date("Y"); ?></p>
</footer>
</body></html>