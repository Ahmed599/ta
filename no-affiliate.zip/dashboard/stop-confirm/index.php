<?php
require_once "../../connect/connect.php";
//if(isset($_SESSION['email'])){
	//	$email      =$_SESSION['email']; 
                		//$keywords  = array("SELECT", "UPDATE", "DELETE", "ORDER BY", "INSERT", "LIMIT", "UNION", "CASE", "GROUP BY", "WHERE", "select", "update", "delete", "order by", "insert", "limit", "union", "case", "group by", "where", "=", "*", ",");
				//$replace = array("SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "SLCT", "UPDT", "DLT", "ORDBY", "NSRT", "LMT", "UN", "CS", "GRPBY", "WER", "", "", "");

				$adred = $_GET['a'];
				$advred = $_GET['r'];
				$rand1 = rand(10000000000,10000000000000);
				$rand2 = md5($rand1);
				$rand3 = base64_encode($rand2);
				$date = date("Y-m-d");
				//$adred = str_replace($keywords, $replace, $adred);
				//$advred = str_replace($keywords, $replace, $advred);
				$stmt = $pdo->prepare('SELECT * FROM users WHERE redirect = ?');
				$stmt->execute([$advred]);
				$data = $stmt->fetch();
				if ($data){
					$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE redirect = ?');
          $stmt->execute([$adred]);
          $data = $stmt->fetch();
					if($data){
						echo "<!DOCTYPE html>
<html>
<style>
body {font-family: Arial, Helvetica, sans-serif;background-color: #f5f8fe;}

form {
  border: 3px solid #f1f1f1;
  font-family: Arial;
}

.container {
  padding: 20px;
  text-align: center;
}

.btn {
  border: 2px solid black;
  border-radius: 5px;
  background-color: white;
  color: black;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
}
a{
    text-decoration: none;
    color: black;
}

.info {
  border-color: #2196F3;
  color: dodgerblue
}


.default {
  border-color: #e7e7e7;
  color: black;
}

</style>
<body>
  <div class=\"container\">
  <span style=\"font-size:60px;\">&#128532;</span>
    <h2>Are you sure you want to stop it ?</h2>
    <p>If something wrong happend or you couldn't get satisfied by our service, you can contact us and we will do our best to make you feel more than satisfied.</p>
        <p> But if you really want to stop it, then we wish you all the best and you will get your money back within 48 working hours.</p>
    <div>
<button class=\"btn default\"><a href=\"../stop/?a=$adred&kf=$rand1&led=$rand2&_p=$rand3&r=$advred&d=$date\">Yes</a></button>
<button class=\"btn info\"><a href=\"../back/?a=$adred&kf=$rand1&led=$rand2&_p=$rand3&r=$advred&d=$date\">No, thanks</a></button>
    </div>
  </div>


</body>
</html>
";
					}else{
					}
				}else{
					}
					?>
