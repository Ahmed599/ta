<?php
$servername = "127.0.0.1:3306";
$username = "root";
$password = "wpH35AZ1Lv3@";
$dbname = "topadn6_project";

try {

	session_start();
	$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	$email = $_SESSION['email']; 
	$Ad_redirect = $_GET['a'];
	$Adv_redirect = $_GET['r'];		

	$statement = $pdo->prepare("SELECT id FROM users WHERE redirect = :redirect and email = :email");
	$statement->execute(array('redirect' => $Adv_redirect, 'email' => $email));
	$id = $statement->fetchColumn();
	if($id){
		$statement = $pdo->prepare("SELECT id FROM ads_normal WHERE redirect = :adredirect and adv_id = :id");
		$statement->execute(array('adredirect' => $Ad_redirect, 'id' => $id));
		$ad_id = $statement->fetchColumn();
			if ($ad_id){
				$status = '1';
				$statement = $pdo->prepare("UPDATE ads_normal SET status = :status WHERE redirect = :adredirect");
				$statement->execute(array('status' => $status, 'adredirect' => $Ad_redirect));
				header("Location: ../");
			}
		}
} catch(PDOException $e) {
	echo "Error: " . $e->getMessage();
	}
?>
