<?php
header("Location: ../");
?>
