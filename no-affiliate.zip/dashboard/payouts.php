<html>
<head>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

tr {
  border-bottom: 1px solid #ddd;
}
</style>
</head>
<body>
<table style="text-align: center;">
  <tr>
    <th>id</th>
    <th>fullname</th>
  <th>email</th>
  <th>paypal</th>
    <th>country</th>
  <th>coming payment</th>
  <th>total payments</th>
  <th>Action</th>
  </tr>
<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'topadn6_project');

try{
    $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    die("ERROR: Could not connect. " . $e->getMessage());
}
		$pub = 1;
		$aff = 3;
		$active = 1;
		$zero = 0;
		$coming_payment = 0;
		$total_payment = 0;
		$coming_payment_pub = 0;
		$total_payment_pub = 0;
		$coming_payment_aff = 0;
		$total_payment_aff = 0;
		$coming_payment_topad = 0;
		$total_payment_topad = 0;
		$stmt = $pdo->prepare("SELECT * FROM users WHERE (type=? or type=?) and active=?");
		$stmt->execute([$pub, $aff, $active]); 
		$data = $stmt->fetchAll();
		foreach ($data as $row) {
				/*echo '<tr><td>' . $row['id'] . '</td>
					<td>' . $row['fullname'] . '</td>
					<td>' . $row['email'] . '</td>
					<td>' . $row['paypal'] . '</td>
					<td>' . $row['country'] . '</td>
					<td>' . $row['coming_payment'] . '</td>
					<td>' . $row['total_payment'] . '</td>';
					$redirect = $row['redirect'];
					if($_SERVER["REQUEST_METHOD"] == "POST"){	
						$sql = "UPDATE users SET coming_payment=? WHERE redirect=?";
						$stmt= $pdo->prepare($sql);
						$stmt->execute([$zero, $redirect]);
					}
					echo '<td><a href="' . $_SERVER["PHP_SELF"] . '">DONE ? ' . '</a></td></tr>';
			*/
				$coming_payment += $row['coming_payment'];
				$total_payment += $row['total_payment'];
			}
		$stmt = $pdo->prepare("SELECT * FROM users WHERE type=? and active=?");
		$stmt->execute([$pub, $active]); 
		$data = $stmt->fetchAll();
		foreach ($data as $row) {
				echo '<tr><td>' . $row['id'] . '</td>
					<td>' . $row['fullname'] . '</td>
					<td>' . $row['email'] . '</td>
					<td>' . $row['paypal'] . '</td>
					<td>' . $row['country'] . '</td>
					<td>' . number_format($row['coming_payment'], 2) . '</td>
					<td>' . number_format($row['total_payment'], 2) . '</td>';
					$redirect = $row['redirect'];
					echo '<td><a href="' . $_SERVER["PHP_SELF"] . '">DONE ? ' . '</a></td></tr>';
					if($_SERVER["REQUEST_METHOD"] == "POST"){	
						$sql = "UPDATE users SET coming_payment=? WHERE redirect=?";
						$stmt= $pdo->prepare($sql);
						$stmt->execute([$zero, $redirect]);
					}

				$coming_payment_pub += $row['coming_payment'];
				$total_payment_pub += $row['total_payment'];
			}
		$stmt = $pdo->prepare("SELECT * FROM users WHERE type=? and active=?");
		$stmt->execute([$aff, $active]); 
		$data = $stmt->fetchAll();
		foreach ($data as $row) {
				echo '<tr><td>' . $row['id'] . '</td>
					<td>' . $row['fullname'] . '</td>
					<td>' . $row['email'] . '</td>
					<td>' . $row['paypal'] . '</td>
					<td>' . $row['country'] . '</td>
					<td>' . number_format($row['coming_payment'], 2) . '</td>
					<td>' . number_format($row['total_payment'], 2) . '</td>';
					$redirect = $row['redirect'];
					echo '<td><a href="' . $_SERVER["PHP_SELF"] . '">DONE ? ' . '</a></td></tr>';
					if($_SERVER["REQUEST_METHOD"] == "POST"){	
						$sql = "UPDATE users SET coming_payment=? WHERE redirect=?";
						$stmt= $pdo->prepare($sql);
						$stmt->execute([$zero, $redirect]);
					}
					
				$coming_payment_aff += $row['coming_payment'];
				$total_payment_aff += $row['total_payment'];
			}
		$currentspent = $totalspent = 0;
		$one = 1;	
		$stmt = $pdo->prepare("SELECT * FROM ads_normal WHERE payment=? AND currentspent > ?");
		$stmt->execute([$one, $zero]);
		$data = $stmt->fetchAll();
		foreach ($data as $row) {
			
						$currentspent += $row['currentspent'];
						$totalspent += $row['totalspent'];
					
					
				}
			
			//$coming_payment = $coming_payment_pub + $coming_payment_aff;
			//$total_payment = $total_payment_pub + $total_payment_aff;
			
			$coming_payment_topad = $currentspent - ($coming_payment_pub + $coming_payment_aff);
			$total_payment_topad = $totalspent - ($total_payment_pub + $total_payment_aff);
			
			
			
			echo '<tr><td colspan="5"style="font-weight: bold;text-align: right;">TOTAL SPENT</td>
				<td style="font-weight: bold;">$' . number_format($currentspent, 2). '</td>
				<td style="font-weight: bold;">$' . number_format($totalspent, 2) . '</td></tr>';
			echo '<tr><td colspan="5" style="font-weight: bold;text-align: right;">Publisers</td>
				<td style="font-weight: bold;">$' . number_format($coming_payment_pub, 2) . '</td>
				<td style="font-weight: bold;">$' . number_format($total_payment_pub, 2) . '</td></tr>';
			echo '<tr><td colspan="5" style="font-weight: bold;text-align: right;">Affiliates</td>
				<td style="font-weight: bold;">$' . number_format($coming_payment_aff, 2) . '</td>
				<td style="font-weight: bold;">$' . number_format($total_payment_aff, 2) . '</td></tr>';
			echo '<tr><td colspan="5" style="font-weight: bold;text-align: right;">Topad</td>
				<td style="font-weight: bold;">$' . number_format($coming_payment_topad, 2) . '</td>
				<td style="font-weight: bold;">$' . number_format($coming_payment_topad, 2) . '</td></tr>';
		
		
	
?>


</body>
</html>