<html>
<head>
</head>
<body>
<?php 
    session_start();
	 
	// Check if the user is logged in, if not then redirect him to login page
	if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
		header("location: ../login/");
	}

  
    if(isset($_SESSION['email'])){
		$email      =$_SESSION['email'];
		$servername = "127.0.0.1:3306";
		$username = "root";
		$password = "wpH35AZ1Lv3@";
		$dbname = "topadn6_project";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
		  die("Connection failed: " . $conn->connect_error);
		}

		$sql = "SELECT * FROM users WHERE email='$email'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {

		  //while($row = $result->fetch_assoc()) {
			  $row = $result->fetch_assoc();

			  if($row["type"]==1 AND $row["active"] == "1"){ //publisher
				//header("location: pub.php");
				include "pub.php";
							  }
			  if($row["type"]==2 AND $row["active"] == "1"){ //advertiser
				//header("location: adv.php");
				include "friday1.php";
							  }
							  
			  if ($row["active"]== "0"){ //not verified yet
				echo("<script>location.href = '../not-verified/';</script>");
				//header("location: ../not-verified.php");
				}
			  if ($row["active"]== "2"){
				echo("<script>location.href = '../error/';</script>");
				//header("location: blocked.php");
			  }
		  //}
		}else{
			
		}
			$conn->close();
			//exit;
	}
?>
</body>
</html>