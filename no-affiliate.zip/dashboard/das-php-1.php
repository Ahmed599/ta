<?php

$servername = "127.0.0.1:3306";
$username = "root";
$password = "wpH35AZ1Lv3@";
$dbname = "topadn6_project";
                
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
}
				$email =$_SESSION['email'];
				$sql = "SELECT * FROM users WHERE email='$email'";
                $result = $conn->query($sql);
				$result = mysqli_fetch_all($result, MYSQLI_ASSOC);
					foreach ($result as $res){
						$id = $res['id'];
						$name = $res['fullname'];
						$redirect = $res['redirect'];
						$impressions = $res['impressions_map'];
						$clicks = $res['clicks_map'];
						$views = $res['views_map'];
						$payment = $res['payment_map'];
						$comingimps = $res['coming_imps'];
						$comingviews = $res['coming_views'];
						$comingclicks = $res['coming_clicks'];
						$comingpayment = $res['coming_payment'];
						$impressions_chart = array();
						$clicks_chart = array();
						$views_chart = array();
						$days_chart = array();
						$payment_chart = array();			
				}

				$day = date("j");
				$mon = date("F");
				$year = date("Y");
				$json0 = json_encode($impressions);
				$json = json_decode($impressions);
				$json01 = json_encode($clicks);
				$json1 = json_decode($clicks);
				$json02 = json_encode($views);
				$json2 = json_decode($views);
				$json03 = json_encode($payment);
				$json3 = json_decode($payment);

					for ($x = 0; $x <= 7; $x++) {
						$key = date('j',strtotime("-$x days"));
						$key2 = date('F',strtotime("-$x days"));
						$key3 = date('Y',strtotime("-$x days"));
						$days_chart[] = $key;
						$impressions_chart[] = $json->$key3->$key2->$key;
						$clicks_chart[] = $json1->$key3->$key2->$key;
						$views_chart[] = $json2->$key3->$key2->$key;
						$payment_chart[] = $json3->$key3->$key2->$key;
						
					}

						$pay_amount = 0;
						$impressions_array = json_encode(array_reverse($impressions_chart));
						$clicks_array = json_encode(array_reverse($clicks_chart));
						$views_array = json_encode(array_reverse($views_chart));
						$payment_array = json_encode(array_reverse($payment_chart));
						$days_array = json_encode(array_reverse($days_chart));
						$days_array = str_replace('"','', $days_array);
						$monthis29 = array();
						$monthis30 = array();
						$monthis31 = array();
						$yes0 = date('j',strtotime("-1 days"));
						$mon0 = date('F',strtotime("-1 days"));
						$year0 = date('Y',strtotime("-1 days"));
						$yes1 = date('j',strtotime("-2 days"));
						$mon1 = date('F',strtotime("-2 days"));
						$year1 = date('Y',strtotime("-2 days"));
						$yes2 = date('j',strtotime("-3 days"));
						$mon2 = date('F',strtotime("-3 days"));
						$year2 = date('Y',strtotime("-3 days"));
						$lyear = date('Y',strtotime("-1000 days"));
						$lmon = date('F',strtotime("-1000 days"));
						$lday = date('j',strtotime("-1000 days"));
						$monthis29[] = date('F',strtotime("-29 days"));
						$monthis30[] = date('F',strtotime("-30 days"));
						$monthis31[] = date('F',strtotime("-31 days"));
						
						
						$imp_today = $json->$year->$mon->$day;
						$imp_yesterday = $json->$year0->$mon0->$yes0;
						$imp_yesterday1 = $json->$year1->$mon1->$yes1;
						$imp_yesterday2 = $json->$year2->$mon2->$yes2;
						
						$imp_avg = (($imp_today + $imp_yesterday + $imp_yesterday1 + $imp_yesterday2)/4 * 1.25);
						
						$clicks_today = $json1->$year->$mon->$day;
						$clicks_yesterday = $json1->$year0->$mon0->$yes0;
						$clicks_yesterday1 = $json1->$year1->$mon1->$yes1;
						$clicks_yesterday2 = $json1->$year2->$mon2->$yes2;
						
						$views_today = $json2->$year->$mon->$day;
						$views_yesterday = $json2->$year0->$mon0->$yes0;
						$views_yesterday1 = $json2->$year1->$mon1->$yes1;
						$views_yesterday2 = $json2->$year2->$mon2->$yes2;
						
						$payment_today = 0;
						$payment_yesterday = 0;
						$payment_yesterday1 = 0;
						$payment_yesterday2 = 0;
						
						$payment_today = $json3->$year->$mon->$day;
						$payment_yesterday = $json3->$year0->$mon0->$yes0;
						$payment_yesterday1 = $json3->$year1->$mon1->$yes1;
						$payment_yesterday2 = $json3->$year2->$mon2->$yes2;
						
						$weekimps = 0;
						$weekclicks = 0;
						$weekviews = 0;
						$weekpayments = 0;
								
						if ($day >= 1 && $day <= 7) {
							$diff = $day - 1;
							for ($x = 0; $x <= $diff; $x++) {
								$daytot = date('j',strtotime("-$x days"));
								$montot = date('F',strtotime("-$x days"));
								$yeartot = date('Y',strtotime("-$x days"));
								$weekimps += $json->$yeartot->$montot->$daytot;
								$weekclicks += $json1->$yeartot->$montot->$daytot;
								$weekviews += $json2->$yeartot->$montot->$daytot;
								$weekpayments += $json3->$yeartot->$montot->$daytot;
							}
							
						}elseif ($day >= 8 && $day <= 14) {
							$diff = $day - 8;
							for ($x = 0; $x <= $diff; $x++) {
								$daytot = date('j',strtotime("-$x days"));
								$montot = date('F',strtotime("-$x days"));
								$yeartot = date('Y',strtotime("-$x days"));
								$weekimps += $json->$yeartot->$montot->$daytot;
								$weekclicks += $json1->$yeartot->$montot->$daytot;
								$weekviews += $json2->$yeartot->$montot->$daytot;
								$weekpayments += $json3->$yeartot->$montot->$daytot;
							}
							
						}elseif ($day >= 15 && $day <= 21) {
							$diff = $day - 15;
							for ($x = 0; $x <= $diff; $x++) {
								$daytot = date('j',strtotime("-$x days"));
								$montot = date('F',strtotime("-$x days"));
								$yeartot = date('Y',strtotime("-$x days"));
								$weekimps += $json->$yeartot->$montot->$daytot;
								$weekclicks += $json1->$yeartot->$montot->$daytot;
								$weekviews += $json2->$yeartot->$montot->$daytot;
								$weekpayments += $json3->$yeartot->$montot->$daytot;
							}
							
						}elseif ($day >= 22 && $day <= 28) {
							$diff = $day - 22;
							for ($x = 0; $x <= $diff; $x++) {
								$daytot = date('j',strtotime("-$x days"));
								$montot = date('F',strtotime("-$x days"));
								$yeartot = date('Y',strtotime("-$x days"));
								$weekimps += $json->$yeartot->$montot->$daytot;
								$weekclicks += $json1->$yeartot->$montot->$daytot;
								$weekviews += $json2->$yeartot->$montot->$daytot;
								$weekpayments += $json3->$yeartot->$montot->$daytot;
							}
							
						}elseif ($day >= 25 && $day <= 31) {
							$diff = $day - 25;
							for ($x = 0; $x <= $diff; $x++) {
								$daytot = date('j',strtotime("-$x days"));
								$montot = date('F',strtotime("-$x days"));
								$yeartot = date('Y',strtotime("-$x days"));
								$weekimps += $json->$yeartot->$montot->$daytot;
								$weekclicks += $json1->$yeartot->$montot->$daytot;
								$weekviews += $json2->$yeartot->$montot->$daytot;
								$weekpayments += $json3->$yeartot->$montot->$daytot;
							}
						}else{
							echo "";
						}
						
						$monthimps = 0;
						$monthclicks = 0;
						$monthviews = 0;
						$monthpayments = 0;
						
						if ($day >= 1 && $day <= 31 and $mon=$mon) {
							$diff = $day - 1;
							for ($x = 0; $x <= $diff; $x++) {
								$daytot = date('j',strtotime("-$x days"));
								$montot = date('F',strtotime("-$x days"));
								$yeartot = date('Y',strtotime("-$x days"));
								$monthimps += $json->$yeartot->$montot->$daytot;
								$monthclicks += $json1->$yeartot->$montot->$daytot;
								$monthviews += $json2->$yeartot->$montot->$daytot;
								$monthpayments += $json3->$yeartot->$montot->$daytot;
							}
							
						}
						
						$totalimps = 0;
						$totalclicks = 0;
						$totalviews = 0;
						$totalpayments = 0;
						$now = time(); // or your date as well
						$your_date = strtotime("2023-09-07");
						$datediff = $now - $your_date;
						$final = round($datediff / (60 * 60 * 24));
						
						for ($x = 0; $x < $final; $x++) {
								$daytot = date('j',strtotime("-$x days"));
								$montot = date('F',strtotime("-$x days"));
								$yeartot = date('Y',strtotime("-$x days"));
								$totalimps += $json->$yeartot->$montot->$daytot;
								$totalclicks += $json1->$yeartot->$montot->$daytot;
								$totalviews += $json2->$yeartot->$montot->$daytot;
								$totalpayments += $json3->$yeartot->$montot->$daytot;
							}
							
							
						?>