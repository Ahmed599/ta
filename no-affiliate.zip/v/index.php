<?php
$servername = "127.0.0.1:3306";
$username = "root";
$password = "wpH35AZ1Lv3@";
$dbname = "topadn6_project";

try {
  $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $code = $_GET['r'];
  $zero = '0';
  $one = '1';

  $statement = $pdo->prepare("SELECT id FROM users WHERE code = :code and active = :zero");
  $statement->execute(array('code' => $code, 'zero' => $zero));
  $id = $statement->fetchColumn();

  if($id){
    $statement = $pdo->prepare("UPDATE users SET active = :one WHERE code = :code");
    $statement->execute(array('one' => $one, 'code' => $code));
    header("location: https://www.topad.net/login");

  }else{

    header("location: https://www.topad.net");
    
  }
} catch(PDOException $e) {

    header("location: https://www.topad.net/error");
}

?>

