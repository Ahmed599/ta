<html lang="en" class=""><head>
<meta charset="UTF-8">
<title>Error - Topad.net</title>
<meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style class="INLINE_PEN_STYLESHEET_ID"> body {
}
p {
    margin-top: 0rem;
    margin-bottom: 0rem;
}
a { color: #000;
text-decoration: auto;
}
a:hover, a:active, a:focus { color:#000;
}
@-webkit-keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
@keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
h1 { font-size: 3em; font-weight: bold;
}
h3 { display: block; font-size: 1.5em; margin-left: 0; margin-right: 0; font-weight: bold;
}
.h-100 { height: 83%!important;
}
.text-white {
    color: #6a6e72!important;
}
.cent {
    margin-top: 2rem!important;
    margin-bottom: 2rem!important;
}
.bottom {
font-size: 0.8rem;
color: #6a6e72;
text-decoration: auto;
}
  </style>
</head>
<body>
<div class="header">
<a href="../" style="float: left;"><h2 class="fw-light m-3" style="color: #559ade; font-size: 2rem;">TopAd</h2></a>
</div>
<div class="d-flex flex-column justify-content-center w-100 h-100">
<div class="d-flex flex-column justify-content-center align-items-center" style="min-width: 385px; max-width: 700px; align-self: center;">
<h2 class="fw-light text-white m-3" style="text-align: -webkit-center;font-weight: 400!important;color: white;">Oops!</h2>

<h3 style="padding-right: 10%;padding-left: 10%;text-align: center;font-size: 1.3rem;color: white;max-width: 1360px;" class="text-white fw-light m-2">You're not in the right page. Please go back and try again.</h3>
<h6 class="fw-light text-white m-3 text-decoration-none" style="text-align: -webkit-center;"><a href="">Click here to go back</a></h6>
</div>
</div>
<div style="text-align: center; margin-bottom: 1rem;"><a href="../how-it-works/" class="bottom">How it works</a>&emsp;<a href="../pricing/" class="bottom">Pricing</a>&emsp;<a href="../contact-us/" class="bottom">Contact us</a>
&emsp;<a href="../about/" class="bottom">About</a></div>
<p class="fw-light text-white bottom" style="text-align: -webkit-center;">Topad.net © <?php echo date("Y"); ?></p>
</body></html>