<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: ../dashboard/");
    exit;
}
 
// Include config file

require_once "../connect/connect.php";


// Define variables and initialize with empty values
$email = $password = $useranswer = $code = "";
$email_err = $password_err = "";
 
// Processing form data when form is submitted

if($_SERVER["REQUEST_METHOD"] == "POST"){
	
	
    // Check if email is empty
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter your email.";
    } else{
        $email = trim($_POST["email"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
	
		
    // Validate credentials
    if(empty($email_err) && empty($password_err) && empty($answer_err)){
        // Prepare a select statement
        $sql = "SELECT id, email, password FROM users WHERE email = :email";
        
        if($stmt = $pdo->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
            
            // Set parameters
            $param_email = trim($_POST["email"]);
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Check if email exists, if yes then verify password
                if($stmt->rowCount() == 1){
                    if($row = $stmt->fetch()){
                        $id = $row["id"];
                        $email = $row["email"];
                        $hashed_password = $row["password"];
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["email"] = $email;                            
                            
                            // Redirect user to welcome page
                            header("location: ../dashboard/");
                        } else{
                            // Display an error message if password is not valid
                            $password_err = "The password you entered was not valid.";
                        }
                    }
                } else{
                    // Display an error message if email doesn't exist
                    $email_err = "Please check your inputs.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

         // Close statement
            unset($stmt);
        }
    }
    
    // Close connection
    unset($pdo);
	}


?>

<html lang="en" class=""><head>
<meta charset="UTF-8">
<title>Welcome to Topad.net</title>
<meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width, initial-scale=1">
  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style class="INLINE_PEN_STYLESHEET_ID"> body {
}
p {
    margin-top: 0rem;
    margin-bottom: 0rem;
}
a { color: #000;
text-decoration: auto;
}
a:hover, a:active, a:focus { color:#000;
}
@-webkit-keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
@keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
h1 { font-size: 3em; font-weight: bold;
}
h3 { display: block; font-size: 1.5em; margin-left: 0; margin-right: 0; font-weight: bold;
}
.h-100 { height: 83%!important;
}
.text-white {
    color: #6a6e72!important;
}
.cent {
    margin-top: 1rem!important;
    margin-bottom: 2rem!important;
}
.bottom {
font-size: 0.8rem;
color: #6a6e72;
text-decoration: auto;
}
</style>
</head>
<body>
<div class="header">
<a href="../" style="float: left;"><h2 class="fw-light m-3" style="color: #559ade; font-size: 2rem;">TopAd</h2></a>
</div>
<div class="d-flex flex-column justify-content-center w-100 h-100">
<div class="d-flex flex-column justify-content-center align-items-center">
<h2 class="fw-light text-white m-3" style="text-align: -webkit-center;font-weight: 400!important;">Welcome back :)</h2>

<h3 style="padding-right: 10%;padding-left: 10%;text-align: center;font-size: 1.3rem;max-width: 1360px;padding-bottom: 2rem;" class="fw-light text-white m-2">Wish you a great experience.</h3>

<form class="forms-sample" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="text-align: -webkit-center;">
<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default">Email</span>
  </div>
  <input type="text" name="email" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo $email; ?>">
</div>


<div class="input-group mb-3" style="padding-left: 10px; padding-right: 10px; max-width: 400px;">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-default">Password</span>
  </div>
  <input type="password" name="password" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo $password; ?>">
</div>

<span class="help-block"><?php if (!empty($email_err)){echo  $email_err . "<br>";} if (!empty($password_err)){echo  $password_err . "<br>";} ?></span>
<div class="btn-group cent">

<button type="submit" class="btn btn-outline-dark" style="border-top-left-radius: 4px;border-bottom-left-radius: 4px;padding-right: 1rem;padding-left: 1rem;">LOGIN</button>
</form>

</div>
<h6 class="fw-light text-white m-0 text-decoration-none" style="padding-left: 20px; padding-right: 20px;">Or click <a href="../forgot-password/" style="font-weight: bolder;">here</a> if you forgot your password.</h6> 
</div>
</div>
<div style="text-align: center; margin-bottom: 1.6rem;"><a href="../how-it-works/" class="bottom">How it works</a>&emsp;<a href="../pricing/" class="bottom">Pricing</a>&emsp;<a href="../contact-us/" class="bottom">Contact us</a>
&emsp;<a href="../about/" class="bottom">About</a></div>
<p class="fw-light text-white bottom" style="text-align: -webkit-center;">Topad.net © <?php echo date("Y"); ?></p>
</body>
</html>