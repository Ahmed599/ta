<html lang="en" class="">
<head>
<meta charset="UTF-8">
<title>Pricing - Topad.net</title>
<meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style class="INLINE_PEN_STYLESHEET_ID"> body {
}
p {
    margin-top: 0rem;
    margin-bottom: 0rem;
}
a { color: #000;
text-decoration: auto;
}
a:hover, a:active, a:focus { color:#000;
}
@-webkit-keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
@keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
h1 { font-size: 3em; font-weight: bold;
}
h3 { display: block; font-size: 1.5em; margin-left: 0; margin-right: 0; font-weight: bold;
}
.h-100 { height: 83%!important;
}
.text-white {
    color: #6a6e72!important;
}
.cent {
    margin-top: 2rem!important;
    margin-bottom: 2rem!important;
}
.bottom {
font-size: 0.8rem;
color: #6a6e72;
text-decoration: auto;
}
  </style>
<div class="header">
<?php
echo "<a href=\"../\" style=\"float: left;\"><h2 class=\"fw-light m-3\" style=\"color: #559ade; font-size: 2rem;\">TopAd</h2></a>";
?>
</div>
</div>
<div class="d-flex flex-column justify-content-center w-100 h-100" style="align-items: center;">
<div class="d-flex flex-column justify-content-center align-items-center" style="text-align: center; max-width: 850px;">
<h1 class="fw-light text-white m-3" style="text-align: -webkit-center;">Pricing</h1>
<br>
<h5 class="text-white m-2" style="font-weight: 400;"><b>Impressions :</b> $0.001  (For Advertisers and Publishers).</h5>
<h5 class="text-white m-2" style="font-weight: 400;"><b>Clicks :</b> $0.08 : $0.12 (For Advertisers and Publishers).</h5>
</div>
</div>
<?php
echo"<div style=\"text-align: center; margin-bottom: 1rem;\"><a href=\"../how-it-works/\" class=\"bottom\">How it works</a>&emsp;<a href=\"../pricing/\" class=\"bottom\">Pricing</a>&emsp;<a href=\"../contact-us/\" class=\"bottom\">Contact us</a>
&emsp;<a href=\"../about/\" class=\"bottom\">About</a></div>";
?>
<p class="fw-light text-white bottom" style="text-align: -webkit-center;">Topad.net <?php echo date("Y"); ?></p>
</body>
</html>