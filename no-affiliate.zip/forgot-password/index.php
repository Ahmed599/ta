<?php					

session_start();

require_once "../connect/connect.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../phpmailer\src\Exception.php';
require_once '../phpmailer\src\PHPMailer.php';
require_once '../phpmailer\src\SMTP.php';
$mail = new PHPMailer(true);
 
$email = "";
$email_err = "";
 
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
if(isset($_SESSION["email"])){
	if((empty(trim($_POST["email"]))) or (trim($_POST["email"]) != $_SESSION["email"])){
		$email_err = "Please enter your email.";
	} else{
		$email = trim($_POST["email"]);
	}
}
if(!(isset($_SESSION["email"]))){
	if(empty(trim($_POST["email"]))){
		$email_err = "Please enter your email.";
	} else{
		$email = trim($_POST["email"]);
		}
		
	}
	$myStr = (md5(rand(1000,10000000000000)));
	$code = substr($myStr, 0, 6);
    // Validate credentials
    if(empty($email_err)){
		$stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
		$stmt->execute([$email]);
		$data = $stmt->fetch(PDO::FETCH_ASSOC);

		if ($data){
		
		//echo $code;
		$stmt = $pdo->prepare('UPDATE users SET emailcode = ? WHERE email = ?');
		$stmt->execute([$code, $email]);
		//$stmt->fetchAll();
		try {
			$url = "https://www.topad.net/password-reset/";
			$from = "no-reply@topad.net";
			$to = $email;
			// Server settings
			$mail->SMTPDebug = SMTP::DEBUG_SERVER; // for detailed debug output
			$mail->isSMTP();
			$mail->Host = 'smtp-relay.brevo.com';
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
			$mail->Port = 587;
		
			$mail->Username = 'topad.net@gmail.com'; // YOUR gmail email
			$mail->Password = 'xsmtpsib-84867de6121d39f505ffc7b9073db195299dcfbacf5c77e44c651930b178e3b5-G40IHK58xXZO96pj'; // YOUR gmail password
		
			// Sender and recipient settings
			$mail->setFrom('no-reply@topad.net', 'TopAd ');
			$mail->addAddress("$email", '');
		
			// Setting the email content
			$mail->IsHTML(true);
			$mail->Subject = "Reset your Topad account password";
			$mail->Body = 'Your code is : ' . $code . '. please click     <a href="' . $url . '"> to complete the last step';
			//$mail->AltBody = 'Plain text message body for non-HTML email client. Gmail SMTP email body.';
			$mail->send();
			header("location: https://www.topad.net/check-your-email");
		} catch (Exception $e) {
			header("location: https://www.topad.net/error");
		}

	}else{
						$email_err = "Please enter your email.";
						}

					}
		}
?>

<html lang="en">
<head>
<meta charset="UTF-8">
<title>Forgot Password - Topad.net</title>
<meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style class="INLINE_PEN_STYLESHEET_ID"> body {
}
p {
    margin-top: 0rem;
    margin-bottom: 0rem;
}
a { color: #000;
text-decoration: auto;
}
a:hover, a:active, a:focus { color:#000;
}
@-webkit-keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
@keyframes gradient { 0% { background-position: 0% 50%;
	}
	50% { background-position: 100% 50%;
	}
	100% { background-position: 0% 50%;
	}
}
h1 { font-size: 3em; font-weight: bold;
}
h3 { display: block; font-size: 1.5em; margin-left: 0; margin-right: 0; font-weight: bold;
}
.h-100 { height: 83%!important;
}
.text-white {
    color: #6a6e72!important;
}
.cent {
    margin-top: 1rem!important;
    margin-bottom: 2rem!important;
}
.bottom {
font-size: 0.8rem;
color: #6a6e72;
text-decoration: auto;
}
  </style>

</head>
<body>
<div class="header">
<a href="../" style="float: left;"><h2 class="fw-light m-3" style="color: #559ade; font-size: 2rem;">TopAd</h2></a>
</div>
<div class="d-flex flex-column justify-content-center w-100 h-100">
<div class="d-flex flex-column justify-content-center align-items-center">
<h2 class="fw-light text-white m-3" style="text-align: -webkit-center;font-weight: 400!important;">It's pretty easy :)</h2>

<h3 style="padding-right: 10%;padding-left: 10%;text-align: center;font-size: 1.3rem;max-width: 1360px;padding-bottom: 2rem;" class="fw-light text-white m-2">You are few steps away from resetting your password.</h3>

<form class="forms-sample" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="text-align: -webkit-center;">
<div class="input-group mb-3" style="max-width: 400px; padding-left: 10px; padding-right: 10px;">

  <input type="email" name="email" class="form-control" placeholder="email" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo $email; ?>">
</div>

<span class="help-block"><?php if (!empty($email_err)){echo  $email_err . "<br>";} ?></span>
<div class="btn-group cent">

<!--<span style="width: 1rem;"></span>-->
<button type="submit" class="btn btn-outline-dark" style="border-top-left-radius: 4px;border-bottom-left-radius: 4px;padding-right: 1rem;padding-left: 1rem;">Next</button>
</form>

</div>
</div>
</div>
<div style="text-align: center; margin-bottom: 1.6rem;"><a href="https://www.topad.net/how-it-works/" class="bottom">How it works</a>&emsp;<a href="https://www.topad.net/pricing/" class="bottom">Pricing</a>&emsp;<a href="https://www.topad.net/contact-us/" class="bottom">Contact us</a>
&emsp;<a href="https://www.topad.net/about/" class="bottom">About</a></div>
<p class="fw-light text-white bottom" style="text-align: -webkit-center;">Topad.net © <?php echo date("Y"); ?></p>
</body></html>
