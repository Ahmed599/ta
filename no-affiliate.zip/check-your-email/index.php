<html lang="en">
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Check your email - Topad.net</title>
  <link rel="icon" type="image/png" href="https://raw.githubusercontent.com/TAnetwork/ta/main/images/topad-icon.png">
  <link rel="stylesheet" href="../assets/materialdesignicons.min.css">
  <link rel="stylesheet" href="../assets/base/vendor.bundle.base.css">
  <link rel="stylesheet" href="../assets/select2/select2.min.css">
  <link rel="stylesheet" href="../assets/select2-bootstrap-theme/select2-bootstrap.min.css">
  <link rel="stylesheet" href="../assets/style.css">
</head>

<body style="background-color: #f1f6f8;">
<div class="header">
  <h2 class="fw-light m-3" style="color: #559ade;">TopAd</h2>
</div>

    <div class="content-wrapper" data-select2-id="10" style="margin-top: 120px;">
          <div class="row" style="place-content: center;">
            <div class="col-md-6 grid-margin stretch-card" style="display: contents;">
              <div class="card" style="min-width: auto; width: auto;">
                <div class="card-body" style="padding-bottom: 0;">
                  <p class="card-title" style="text-align: -webkit-center; margin-bottom: 0;color: #212529a8;">Yay! congratulations</p>
                  <p></p>
		<hr style="margin-bottom: 1.2em;width: 80%;">
                  <form class="forms-sample">     
                    <div class="form-group">
                    <p>Please check your inbox for the verification message and then click here to login. We're waiting for you :)</p>
                  </div>
                    
                    
                    <div class="form-group" style="text-align: center;margin-top: 2rem;margin-bottom: 0;">
    <a class="btn btn-lg" href="../login/" style="background-color: #559ade;color: white;">Login</a>
		</div>
         </form>
                </div>
              </div>
            </div>
            </div>
        </div>
<p style="margin-top: 36px; font-size: 0.8em; text-align: center;">Topad.net © <?php echo date("Y"); ?></p>
  <script src="../assets/vendors/base/vendor.bundle.base.js"></script>
  <script src="../assets/js/template.js"></script>
  <script src="../assets/vendors/typeahead.js/typeahead.bundle.min.js"></script>
  <script src="../assets/vendors/select2/select2.min.js"></script>
  <script src="../assets/js/file-upload.js"></script>
  <script src="../assets/js/typeahead.js"></script>
  <script src="../assets/js/select2.js"></script>

</body></html>