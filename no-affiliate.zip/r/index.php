<?php

$servername = "127.0.0.1:3306";
$username = "root";
$password = "wpH35AZ1Lv3@";
$dbname = "topadn6_project";

try {
$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$mon = date("F");
$day = date("j");
$year = date("Y");
$one = '1';
$click1 = '0.08';
$click3 = '0.12';
$a = $_GET['a'];
$user = $_GET['p'];

$statement = $pdo->prepare("SELECT id FROM users WHERE redirect = :user");
$statement->execute(array('user' => $user));
$id = $statement->fetchColumn();

if($id){

        $stmt = $pdo->prepare("SELECT url FROM ads_normal WHERE redirect = :a");
        $stmt->execute(array('a' => $a));
        $url = $stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT type FROM ads_normal WHERE redirect = :a");
        $stmt->execute(array('a' => $a));
        $type = $stmt->fetchColumn();

        if($url){
                if($type == "1"){
                        $statement = $pdo->prepare("UPDATE users SET clicks_map = JSON_SET(clicks_map,'$.$year.$mon.$day' , JSON_EXTRACT(clicks_map, '$.$year.$mon.$day') + :one) WHERE redirect = :user");
                        $statement->execute(array('one' => $one, 'user' => $user));

                        $statement = $pdo->prepare("UPDATE ads_normal SET clicks = JSON_SET(clicks,'$.$year.$mon.$day' , JSON_EXTRACT(clicks, '$.$year.$mon.$day') + :one) WHERE redirect = :a");
                        $statement->execute(array('one' => $one, 'a' => $a));

                        $statement = $pdo->prepare("UPDATE users SET payment_map = JSON_SET(payment_map,'$.$year.$mon.$day' , JSON_EXTRACT(payment_map, '$.$year.$mon.$day') + :click) WHERE redirect = :user");
                        $statement->execute(array('click' => $click1, 'user' => $user));

                        $statement = $pdo->prepare("UPDATE ads_normal SET spent = JSON_SET(spent,'$.$year.$mon.$day' , JSON_EXTRACT(spent, '$.$year.$mon.$day') + :click) WHERE redirect = :a");
                        $statement->execute(array('click' => $click1, 'a' => $a));

                        $statement = $pdo->prepare("UPDATE ads_normal SET remains = remains - :click WHERE redirect = :a");
                        $statement->execute(array('click' => $click1, 'a' => $a));

                        //$statement = $pdo->prepare("UPDATE ads_normal SET clicks = clicks + :one WHERE redirect = :a");
                        //$statement->execute(array('one' => $one, 'a' => $a));

                        $statement = $pdo->prepare("UPDATE users SET coming_payment = coming_payment + :click WHERE redirect = :user");
                        $statement->execute(array('click' => $click1, 'user' => $user));

                        $statement = $pdo->prepare("UPDATE users SET coming_clicks = coming_clicks + :one WHERE redirect = :user");
                        $statement->execute(array('one' => $one, 'user' => $user));

                        $statement = $pdo->prepare("UPDATE users SET total_payment = total_payment + :click WHERE redirect = :user");
                        $statement->execute(array('click' => $click1, 'user' => $user));

                        header("Location: $url");
                        exit;

                }if($type == "3"){
                        $statement = $pdo->prepare("UPDATE users SET clicks_map = JSON_SET(clicks_map,'$.$year.$mon.$day' , JSON_EXTRACT(clicks_map, '$.$year.$mon.$day') + :one) WHERE redirect = :user");
                        $statement->execute(array('one' => $one, 'user' => $user));

                        $statement = $pdo->prepare("UPDATE ads_normal SET clicks = JSON_SET(clicks,'$.$year.$mon.$day' , JSON_EXTRACT(clicks, '$.$year.$mon.$day') + :one) WHERE redirect = :a");
                        $statement->execute(array('one' => $one, 'a' => $a));

                        $statement = $pdo->prepare("UPDATE users SET payment_map = JSON_SET(payment_map,'$.$year.$mon.$day' , JSON_EXTRACT(payment_map, '$.$year.$mon.$day') + :click) WHERE redirect = :user");
                        $statement->execute(array('click' => $click3, 'user' => $user));

                        $statement = $pdo->prepare("UPDATE ads_normal SET spent = JSON_SET(spent,'$.$year.$mon.$day' , JSON_EXTRACT(spent, '$.$year.$mon.$day') + :click) WHERE redirect = :a");
                        $statement->execute(array('click' => $click3, 'a' => $a));

                        $statement = $pdo->prepare("UPDATE ads_normal SET remains = remains - :click WHERE redirect = :a");
                        $statement->execute(array('click' => $click3, 'a' => $a));

                        //$statement = $pdo->prepare("UPDATE ads_normal SET clicks = clicks + :one WHERE redirect = :a");
                        //$statement->execute(array('one' => $one, 'a' => $a));

                        $statement = $pdo->prepare("UPDATE users SET coming_payment = coming_payment + :click WHERE redirect = :user");
                        $statement->execute(array('click' => $click3, 'user' => $user));

                        $statement = $pdo->prepare("UPDATE users SET coming_clicks = coming_clicks + :one WHERE redirect = :user");
                        $statement->execute(array('one' => $one, 'user' => $user));

                        $statement = $pdo->prepare("UPDATE users SET total_payment = total_payment + :click WHERE redirect = :user");
                        $statement->execute(array('click' => $click3, 'user' => $user));

                        header("Location: $url");
                        exit;

                }
        }else{
        header("Location: https://www.topad.net");
        }
}else{
header("Location: https://www.topad.net");
}
} catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

?>

