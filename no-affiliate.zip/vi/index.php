<?php

$servername = "127.0.0.1:3306";
$username = "root";
$password = "wpH35AZ1Lv3@";
$dbname = "topadn6_project";

try {
  $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $redirect = $_GET['r'];
  $mon = date("F");
  $day = date("j");
  $year = date("Y");

  $statement = $pdo->prepare("UPDATE users SET views_map = JSON_SET(views_map,'$.$year.$mon.$day' , JSON_EXTRACT(views_map, '$.$year.$mon.$day') + 1) WHERE redirect = :redirect");
  $statement->execute(array('redirect' => $redirect));

  $statement = $pdo->prepare("UPDATE users SET coming_views = coming_views + 1 WHERE redirect = :redirect");
  $statement->execute(array('redirect' => $redirect));

  } catch(PDOException $e) {

      header("location: https://www.topad.net/error");
  }

?>