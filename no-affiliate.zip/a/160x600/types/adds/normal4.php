<?php
$statement = $pdo->prepare("UPDATE users SET coming_payment = coming_payment + :spendamount WHERE redirect = :user");
$statement->execute(array('spendamount' => $spendamount, 'user' => $user));

$statement = $pdo->prepare("UPDATE users SET total_payment = total_payment + :spendamount WHERE redirect = :user");
$statement->execute(array('spendamount' => $spendamount, 'user' => $user));

$statement = $pdo->prepare("UPDATE users SET impressions_map = JSON_SET(impressions_map,'$.$year.$mon.$day' , JSON_EXTRACT(impressions_map, '$.$year.$mon.$day') + :one) WHERE redirect = :user");
$statement->execute(array('one' => $one, 'user' => $user));

$statement = $pdo->prepare("UPDATE users SET payment_map = JSON_SET(payment_map,'$.$year.$mon.$day' , JSON_EXTRACT(payment_map, '$.$year.$mon.$day') + :spendamount) WHERE redirect = :user");
$statement->execute(array('spendamount' => $spendamount, 'user' => $user));

$statement = $pdo->prepare("UPDATE users SET coming_imps = coming_imps + :one WHERE redirect = :user");
$statement->execute(array('one' => $one, 'user' => $user));

$statement = $pdo->prepare("UPDATE ads_normal SET step = step + :one WHERE redirect = :a");
$statement->execute(array('one' => $one, 'a' => $a));
?>