<?php
$statement = $pdo->prepare("UPDATE users SET coming_payment = coming_payment + :spendamount WHERE redirect = :sixx");
$statement->execute(array('spendamount' => $spendamount, 'sixx' => $sixx));

$statement = $pdo->prepare("UPDATE users SET total_payment = total_payment + :spendamount WHERE redirect = :sixx");
$statement->execute(array('spendamount' => $spendamount, 'sixx' => $sixx));

$statement = $pdo->prepare("UPDATE users SET impressions_map = JSON_SET(impressions_map,'$.$year.$mon.$day' , JSON_EXTRACT(impressions_map, '$.$year.$mon.$day') + :one) WHERE redirect = :sixx");
$statement->execute(array('one' => $one, 'sixx' => $sixx));

$statement = $pdo->prepare("UPDATE users SET payment_map = JSON_SET(payment_map,'$.$year.$mon.$day' , JSON_EXTRACT(payment_map, '$.$year.$mon.$day') + :spendamount) WHERE redirect = :sixx");
$statement->execute(array('spendamount' => $spendamount, 'sixx' => $sixx));

$statement = $pdo->prepare("UPDATE users SET coming_imps = coming_imps + :one WHERE redirect = :sixx");
$statement->execute(array('one' => $one, 'sixx' => $sixx));

$statement = $pdo->prepare("UPDATE ads_normal SET step = :zero WHERE redirect = :a");
$statement->execute(array('zero' => $zero, 'a' => $a));
?>