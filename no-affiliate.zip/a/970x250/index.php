<?php

$servername = "127.0.0.1:3306";
$username = "root";
$password = "wpH35AZ1Lv3@";
$dbname = "topadn6_project";

$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$user = $_GET["r"];
$sixx = 'e38da45b5f55f80e24ceb5a3614c15b6';
$today=date("d");
$mon = date("F");
$day = date("j");
$year = date("Y");
$zero = '0';
$one = '1';
$two = '2';
$three = '3';
$four = '4';
$five = '5';
$spendamount = '0.001';

$sizes = array(1, 2, 3, 4); 
shuffle($sizes);
$dir = "http://www.topad.net/images";

foreach ($sizes as $num) {

    $statement = $pdo->prepare("SELECT * FROM ads_normal WHERE status = :one AND payment = :one AND size$num = :two order by rand() limit 1");
    $statement->execute(array('one' => $one, 'two' => $two));
    $row = $statement->fetch();

    $id = $row["id"];
    $adv = $row["adv_id"];
    $step = $row["step"];
    $a = $row["redirect"];
    $remains = $row["remains"];
    $ad_type = $row["type"];
    $src = $row["image$num"];

    if ($remains < 0.1){
    $statement = $pdo->prepare("UPDATE ads_normal SET status = :two WHERE redirect = :a");
    $statement->execute(array('two' => $two, 'a' => $a));

    }elseif($remains > 0.1){

    if ((strlen($src) > 10) and ($ad_type == "1")){
        echo "<a target=\"_blank\" href=\"http://www.topad.net/r/?a=$a&p=$user\"><img src=\"$dir/$src\"></a>";
        break;
        require "types/normal.php";
    }elseif ((strlen($src) > 10) and ($ad_type == "2")){
        echo "<img src=\"$dir/$src\">";
        break;
        require "types/views.php";
    }elseif ((strlen($src) > 10) and ($ad_type == "3")){
        echo "<a target=\"_blank\" href=\"http://www.topad.net/r/?a=$a&p=$user\"><img src=\"$dir/$src\"></a>";
        break;
        require "types/clicks.php";
        }

    }else{
    $stebn = "https://raw.githubusercontent.com/TAnetwork/ta/main/images/970x250.png";
    echo "<a target='_blank' href='http://www.topad.net/'><img src='$stebn'></a>";
    }
}

?>