<?php

$servername = "127.0.0.1:3306";
$username = "root";
$password = "";
$dbname = "topadn6_project";

$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$user = $_GET["r"];
$sixx = 'e38da45b5f55f80e24ceb5a3614c15b6';
$today=date("d");
$mon = date("F");
$day = date("j");
$year = date("Y");
$zero = '0';
$one = '1';
$two = '2';
$four = '4';
$spendamount = '0.001';

$statement = $pdo->prepare("SELECT * FROM ads_normal WHERE status = :one AND payment = :one AND size1 = :two OR size2 = :two OR size3 = :two OR size4 = :two order by rand() limit 1");
$statement->execute(array('one' => $one, 'two' => $two));
while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
  $id = $row["id"];
  $adv = $row["adv_id"];
  $step = $row["step"];
  $a = $row["redirect"];
  $remains = $row["remains"];
  $ad_type = $row["type"];
    
    if ($remains < 0.1){
        $statement = $pdo->prepare("UPDATE ads_normal SET status = :two WHERE redirect = :a");
        $statement->execute(array('two' => $two, 'a' => $a));
      
    }elseif($remains > 0.1){

        $sizes = array(1, 2, 3, 4); 
        shuffle($sizes);
        $dir = "http://127.0.0.1:8080/no-affiliate/images/";
        foreach ($sizes as $i) {
      if (!(empty($row["image$i"])) and ($row["size$i"] == "5") and ($ad_type == "1")){
        $src = $row["image$i"];
        //require "types/normal.php";
        echo "<a target=\"_blank\" href=\"http://127.0.0.1:8080/no-affiliate/r/?a=$a&p=$user\"><img src=\"$dir/$src\"></a>";
        break;
        require "types/normal.php";
      }elseif (!(empty($row["image$i"])) and ($row["size$i"] == "5") and ($ad_type == "2")){
        $src = $row["image$i"];
        //require "types/views.php";
        echo "<img src=\"$dir/$src\">";
        break;
        require "types/views.php";
      }elseif (!(empty($row["image$i"])) and ($row["size$i"] == "5") and ($ad_type == "3")){
        $src = $row["image$i"];
        //require "types/clicks.php";
        echo "<a target=\"_blank\" href=\"http://127.0.0.1:8080/no-affiliate/r/?a=$a&p=$user\"><img src=\"$dir/$src\"></a>";
        break;
        require "types/clicks.php";
        }

        }
  }else{
    $stebn = "http://127.0.0.1:8080/no-affiliate/images/160x600.jpg";
    echo "<a target='_blank' href='http://127.0.0.1:8080/no-affiliate/'><img src='$stebn'></a>";
  }
}
?>
<script src="https://cdn.statically.io/gh/TAnetwork/ta/main/t.js"></script>
