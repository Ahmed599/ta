<?php
$statement = $pdo->prepare("UPDATE ads_normal SET views = JSON_SET(views,'$.$year.$mon.$day' , JSON_EXTRACT(views, '$.$year.$mon.$day') + :one) WHERE redirect = :a");
$statement->execute(array('one' => $one, 'a' => $a));

$statement = $pdo->prepare("UPDATE sizes SET 300x600 = 300x600 + :one WHERE id = :one");
$statement->execute(array('one' => $one));

$statement = $pdo->prepare("UPDATE ads_normal SET views = views + :one WHERE redirect = :a");
$statement->execute(array('one' => $one, 'a' => $a));

if ($step == "0" or $step == "1" or $step == "2" or $step == "3" or $step == "4" or $step == "5" or $step == "6") {

    $statement = $pdo->prepare("UPDATE users SET impressions_map = JSON_SET(impressions_map,'$.$year.$mon.$day' , JSON_EXTRACT(impressions_map, '$.$year.$mon.$day') + :one) WHERE redirect = :user");
    $statement->execute(array('one' => $one, 'user' => $user));
    $statement = $pdo->prepare("UPDATE ads_normal SET step = step + :one WHERE redirect = :a");
    $statement->execute(array('one' => $one, 'a' => $a));

}elseif ($step == "7" or $step == "8") {

    $statement = $pdo->prepare("UPDATE users SET impressions_map = JSON_SET(impressions_map,'$.$year.$mon.$day' , JSON_EXTRACT(impressions_map, '$.$year.$mon.$day') + :one) WHERE redirect = :sixx");
    $statement->execute(array('one' => $one, 'sixx' => $sixx));
    $statement = $pdo->prepare("UPDATE ads_normal SET step = step + :one WHERE redirect = :a");
    $statement->execute(array('one' => $one, 'a' => $a));

}elseif ($step == "9") {

    $statement = $pdo->prepare("UPDATE users SET impressions_map = JSON_SET(impressions_map,'$.$year.$mon.$day' , JSON_EXTRACT(impressions_map, '$.$year.$mon.$day') + :one) WHERE redirect = :sixx");
    $statement->execute(array('one' => $one, 'sixx' => $sixx));
    $statement = $pdo->prepare("UPDATE ads_normal SET step = :zero WHERE redirect = :a");
    $statement->execute(array('zero' => $zero, 'a' => $a));

}else{
    }
?>
