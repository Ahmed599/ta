<?php
$statement = $pdo->prepare("UPDATE ads_normal SET views = JSON_SET(views,'$.$year.$mon.$day' , JSON_EXTRACT(views, '$.$year.$mon.$day') + :one) WHERE redirect = :a");
$statement->execute(array('one' => $one, 'a' => $a));

$statement = $pdo->prepare("UPDATE ads_normal SET spent = JSON_SET(spent,'$.$year.$mon.$day' , JSON_EXTRACT(spent, '$.$year.$mon.$day') + :spendamount) WHERE redirect = :a");
$statement->execute(array('spendamount' => spendamount, 'a' => $a));

$statement = $pdo->prepare("UPDATE ads_normal SET remains = remains - :spendamount WHERE redirect = :a");
$statement->execute(array('spendamount' => spendamount, 'a' => $a));

$statement = $pdo->prepare("UPDATE sizes SET 728x90 = 728x90 + :one WHERE id = :one");
$statement->execute(array('one' => $one));

$statement = $pdo->prepare("UPDATE ads_normal SET views = views + :one WHERE redirect = :a");
$statement->execute(array('one' => $one, 'a' => $a));

$statement = $pdo->prepare("UPDATE ads_normal SET totalspent = totalspent + :spendamount WHERE redirect = :a");
$statement->execute(array('spendamount' => $spendamount, 'a' => $a));

$statement = $pdo->prepare("UPDATE ads_normal SET currentspent = currentspent + :spendamount WHERE redirect = :a");
$statement->execute(array('spendamount' => $spendamount, 'a' => $a));


if ($step == "0" or $step == "1" or $step == "2" or $step == "3" or $step == "4" or $step == "5" or $step == "6") {

    require "adds/views4.php";

}elseif ($step == "7") {

    require "adds/views5.php";

}elseif ($step == "8") {

    require "adds/views5.php";

}elseif ($step == "9") {

    require "adds/views6.php";

}else{
    }
?>
