<?php include 'das-php.php';
include 'flt.php';
?>
<html lang="en"><head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Ads</title>
  <meta name="robots" content="noindex">
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.0/css/boxicons.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.snow.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.bubble.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/remixicon@2.2.0/fonts/remixicon.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.36.3/apexcharts.min.css" rel="stylesheet">
  <link href="https://unpkg.com/simple-datatables@2.1.13/dist/style.css" rel="stylesheet">
  <link href="https://bootstrapmade.com/demo/templates/NiceAdmin/assets/css/style.css" rel="stylesheet">

<style>
.tab {
  overflow: hidden;
}

.tab button {
  background-color: inherit;
  border: none;
  outline: none;
  cursor: pointer;
  color: #899bbd;
}

.tabcontent {
  display: none;
  border-top: none;
}
.tabcontent1 {
  display: none;
  border-top: none;
}
.tabcontent2 {
  display: none;
  border-top: none;
}
.tabcontent3 {
  display: none;
  border-top: none;
}
.tabcontent4 {
  display: none;
  border-top: none;
}
.tabcontent5 {
  display: none;
  border-top: none;
}
</style>
</head>
<body>

<header id="header" class="header fixed-top d-flex align-items-center header-scrolled">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
        <img src="../logo.jpg" alt="">
        <span class="d-none d-lg-block" style="font-weight: 300;">TopAd</span>
      </a>
      
    </div>

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown" aria-expanded="false">
            <span class="d-md-block dropdown-toggle ps-2"><i class="bi bi-list toggle-sidebar-btn"></i></span>
          </a>

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile" style="">
            <li class="dropdown-header">
              <h6><?php echo $name; ?></h6>
              <span>Publisher</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="../forgot-password/index.php">
                <i class="bi bi-gear"></i>
                <span>Forgot/Reset Password</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="../help/index.php">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="../logout/index.php">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul>
        </li>
      </ul>
    </nav>
  </header>



  <main id="main" class="main" style="margin-left: 0px;">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div>

    <section class="section dashboard">
      <div class="row" style="justify-content: center;">

      <div class="col-lg-8">
          <div class="row">

            <div class="card-body">
			  <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Results</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
				$host = '127.0.0.1:3306';
				$db   = 'topadn6_project';
				$user = 'root';
				$pass = 'wpH35AZ1Lv3@';
				$charset = 'utf8mb4';

				$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
				$options = [
					PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
					PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
					PDO::ATTR_EMULATE_PREPARES   => false,
				];
				try {
					 $pdo = new PDO($dsn, $user, $pass, $options);
				} catch (\PDOException $e) {
					 throw new \PDOException($e->getMessage(), (int)$e->getCode());
				}
				
				$id = 353;
				$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
				$stmt->execute([$id]);
				$data = $stmt->fetchAll();
				if ($data){
					foreach ($data as $da){
						$name = $da["fullname"];
						$active = $da["active"];
						$advred = $da["redirect"];
					}
				}
				
				$payment = 1;
				$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE payment = ?');
				$stmt->execute([$payment]);
				$data = $stmt->fetchAll();
				if (($data)==0){
					echo "No results yet.";
				}else{
					echo"<thead>
					<tr>
					<th scope=\"col\" style=\"width: 12.5%;\">id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">adv id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Campaign title</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Views</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Clicks</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Budget</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Spent</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Remains</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Status</th>
					</tr>
                    </thead>
                    <tbody>";
					foreach ($data as $ad){
						$day = date("j");
						$mon = date("F");
						$year = date("Y");
						$adid = $ad["id"];
						$budget = $ad["budget"];
						$spent = $ad['spent'];
						$remains = $ad["remains"];
						$adred = $ad["redirect"];
						$views = $ad["views"];
						$clicks = $ad["clicks"];
						?>
					<tr>
						<td><?= htmlspecialchars($ad['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['adv_id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['campaign_name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						$views_result = 0;
						$json0 = json_encode($views);
						$json = json_decode($views);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$views_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($views_result), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?php
						$clicks_result = 0;
						$json0 = json_encode($clicks);
						$json = json_decode($clicks);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$clicks_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($clicks_result), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?= htmlspecialchars(number_format($ad['budget']), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						$spent_result = 0;
						$json0 = json_encode($spent);
						$json = json_decode($spent);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$spent_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($spent_result, 2), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?php echo htmlspecialchars(number_format($remains, 2), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						 	if ($ad['status']=='0'){
							echo '<span class="badge bg-warning">Pending</span>';}
							if ($ad['status']=='1'){
							echo '<span class="badge bg-success">Running</span>';}
							if ($ad['status']=='2'){
							echo '<span class="badge bg-primary">Finished</span>';}
							if ($ad['status']=='3'){
							echo '<span class="badge bg-info">Paused</span>';}
							if ($ad['status']=='4'){
							echo '<span class="badge bg-secondary">Stopped</span>';}
							if ($ad['status']=='5'){
							echo '<span class="badge bg-danger">Rejected</span>';}
						 ?>
						 
						 </td>
						 </tr>
						 <?php           
							}
						}
				?>
						 </tbody>
                  </table>
				  </div>
				  </div>
                </div>
            </div>

            <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Stopped</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
				
				$status = 4;				
				$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE payment = ? AND status = ?');
				$stmt->execute([$payment, $status]);
				$data = $stmt->fetchAll();
				
				if (($data)==0){
					echo "No results yet.";
				}else{
					echo"<thead>
					<tr><th scope=\"col\" style=\"width: 12.5%;\">id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">adv id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Campaign title</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Views</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Clicks</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Budget</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Spent</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Remains</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Status</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Paid</th>
					</tr>
                    </thead>
                    <tbody>";
					foreach ($data as $ad){
						$day = date("j");
						$mon = date("F");
						$year = date("Y");
						$adid = $ad["id"];
						$budget = $ad["budget"];
						$spent = $ad['spent'];
						$remains = $ad["remains"];
						$adred = $ad["redirect"];
						$views = $ad["views"];
						$clicks = $ad["clicks"];
						?>
						<tr>
						<td><?= htmlspecialchars($ad['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['adv_id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['campaign_name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						$views_result = 0;
						$json0 = json_encode($views);
						$json = json_decode($views);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$views_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($views_result), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?php
						$clicks_result = 0;
						$json0 = json_encode($clicks);
						$json = json_decode($clicks);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$clicks_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($clicks_result), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?= htmlspecialchars(number_format($ad['budget']), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						$spent_result = 0;
						$json0 = json_encode($spent);
						$json = json_decode($spent);
						for ($x = 0; $x <= 10; $x++) {
							$key = date('j',strtotime("-$x days"));
							$key2 = date('F',strtotime("-$x days"));
							$key3 = date('Y',strtotime("-$x days"));
							$spent_result += $json->$key3->$key2->$key;
						}
						echo htmlspecialchars(number_format($spent_result, 2), ENT_QUOTES, 'UTF-8');
						?>
						</td>
						<td><?php echo htmlspecialchars(number_format($remains, 2), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php
						 	if ($ad['status']=='4'){
							echo '<span class="badge bg-secondary">Stopped</span>';}
						 ?>
						 
						 </td>
						 <td><?php
						 	if ($ad['paid']=='0'){
							echo "<a href=\"paid.php?a=$adred&r=$advred\"><span class=\"badge bg-warning\">Not yet.</span></a>";}
							if ($ad['paid']=='1'){
							echo '<span class="badge bg-success">Done</span>';}
						 ?>
						 
						 </td>
						 </tr>
						 <?php           
								}
							}				
						?>
						 </tbody>
                  </table>
				  </div>
				  </div>
                </div>
            </div>
			</div>
      
			  <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Pending</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
				
				
				$status = 0;				
				$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE payment = ? AND status = ?');
				$stmt->execute([$payment, $status]);
				$data = $stmt->fetchAll();
				
				if (($data) < 1){
					echo "No results yet.";
				}else{
					echo"<thead>
					<tr><th scope=\"col\" style=\"width: 12.5%;\">id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">adv id</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Campaign title</th>
					<th scope=\"col\" style=\"width: 12.5%;\">description</th>
					<th scope=\"col\" style=\"width: 12.5%;\">category</th>
					<th scope=\"col\" style=\"width: 12.5%;\">country</th>
					<th scope=\"col\" style=\"width: 12.5%;\">language</th>
					<th scope=\"col\" style=\"width: 12.5%;\">keywords</th>
					<th scope=\"col\" style=\"width: 12.5%;\">budget</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Images</th>
					<th scope=\"col\" style=\"width: 12.5%;\">Status</th>
					</tr>
                    </thead>
                    <tbody>";
					foreach ($data as $ad){
						$day = date("j");
						$mon = date("F");
						$year = date("Y");
						$adid = $ad["id"];
						$image1 = $ad["image1"];
						$image2 = $ad["image2"];
						$image3 = $ad["image3"];
						$image4 = $ad["image4"];					
						$adred = $ad["redirect"];
						$size1 = $ad["size1"];
						$size2 = $ad["size2"];
						$size3 = $ad["size3"];
						$size4 = $ad["size4"];	
						?>
						<tr>
						<td><?= htmlspecialchars($ad['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['adv_id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['campaign_name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['description'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['category'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['country'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['language'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($ad['keywords'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars(number_format($ad['budget']), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php if(!($size1) == 0){echo "<a href=\"../images/$image1\"><img style=\"width: 60%;\" src=\"../images/$image1\"\"></a><br><a href=\"delete.php?im=$image1&r=$adred\"><span class=\"badge bg-success\">Delete</span></a>";}
										if(!($size2) == 0){echo "<a href=\"../images/$image2\"><img style=\"width: 60%;\" src=\"../images/$image2\" class=\"img-thumbnail\" \"></a><br><a href=\"delete.php?im=$image2&r=$adred\"><span class=\"badge bg-success\">Delete</span></a>";}
										if(!($size3) == 0){echo "<a href=\"../images/$image3\"><img style=\"width: 60%;\" src=\"../images/$image3\" class=\"img-thumbnail\" \"></a><br><a href=\"delete.php?im=$image3&r=$adred\"><span class=\"badge bg-success\">Delete</span></a>";}
										if(!($size4) == 0){echo "<a href=\"../images/$image4\"><img style=\"width: 60%;\" src=\"../images/$image4\" class=\"img-thumbnail\" \"></a><br><a href=\"delete.php?im=$image4&r=$adred\"><span class=\"badge bg-success\">Delete</span></a>";}
															
									?></td>
						 <td><?php
							echo "<a href=\"accept.php?a=$adred&r=$advred\"><span class=\"badge bg-warning\">Accept</span></a><br>
							<a href=\"reject.php?a=$adred&r=$advred\"><span class=\"badge bg-warning\">Reject</span></a>";
						 ?></td>
						 </tr>
						 <?php           
			}
		}
				
				?>
						 </tbody>
                  </table></div></div>
                </div>
            </div>
			</div>

          </div>
        </div>

      </div>
    </section>

  </main>

  <!-- Vendor JS Files -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.36.3/apexcharts.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.3/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/echarts/5.4.1/echarts.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.min.js"></script>
  <script src="https://bootstrapmade.com/demo/templates/NiceAdmin/assets/vendor/simple-datatables/simple-datatables.js"></script>
  <!--<script src="../assets/vendor/simple-datatables/simple-datatables.js"></script>-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/6.3.1/tinymce.min.js"></script>
  <script>
	function res(evt, item) {
	  var i, tabcontent, tablinks;
	  tabcontent = document.getElementsByClassName("tabcontent");
	  for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	  }
	  tablinks = document.getElementsByClassName("tablinks");
	  for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	  }
	  document.getElementById(item).style.display = "block";
	  evt.currentTarget.className += " active";
	}
	document.getElementById("today-main").click();
</script>
  <script>
	function res1(evt1, item1) {
	  var i, tabcontent1, tablinks1;
	  tabcontent1 = document.getElementsByClassName("tabcontent1");
	  for (i = 0; i < tabcontent1.length; i++) {
		tabcontent1[i].style.display = "none";
	  }
	  tablinks1 = document.getElementsByClassName("tablinks1");
	  for (i = 0; i < tablinks1.length; i++) {
		tablinks1[i].className = tablinks1[i].className.replace(" active", "");
	  }
	  document.getElementById(item1).style.display = "block";
	  evt1.currentTarget.className += " active";
	}
		document.getElementById("yesterday-main").click();
</script>
  <script>
	function res2(evt2, item2) {
	  var i, tabcontent2, tablinks2;
	  tabcontent2 = document.getElementsByClassName("tabcontent2");
	  for (i = 0; i < tabcontent2.length; i++) {
		tabcontent2[i].style.display = "none";
	  }
	  tablinks2 = document.getElementsByClassName("tablinks2");
	  for (i = 0; i < tablinks2.length; i++) {
		tablinks2[i].className = tablinks2[i].className.replace(" active", "");
	  }
	  document.getElementById(item2).style.display = "block";
	  evt2.currentTarget.className += " active";
	}
		document.getElementById("last-yesterday-main").click();
</script>
<script>
	function res3(evt3, item3) {
	  var i, tabcontent3, tablinks3;
	  tabcontent3 = document.getElementsByClassName("tabcontent3");
	  for (i = 0; i < tabcontent3.length; i++) {
		tabcontent3[i].style.display = "none";
	  }
	  tablinks3 = document.getElementsByClassName("tablinks3");
	  for (i = 0; i < tablinks3.length; i++) {
		tablinks3[i].className = tablinks3[i].className.replace(" active", "");
	  }
	  document.getElementById(item3).style.display = "block";
	  evt3.currentTarget.className += " active";
	}
		document.getElementById("this-week-main").click();
</script>
<script>
	function res4(evt4, item4) {
	  var i, tabcontent4, tablinks4;
	  tabcontent4 = document.getElementsByClassName("tabcontent4");
	  for (i = 0; i < tabcontent4.length; i++) {
		tabcontent4[i].style.display = "none";
	  }
	  tablinks4 = document.getElementsByClassName("tablinks4");
	  for (i = 0; i < tablinks4.length; i++) {
		tablinks4[i].className = tablinks4[i].className.replace(" active", "");
	  }
	  document.getElementById(item4).style.display = "block";
	  evt4.currentTarget.className += " active";
	}
		document.getElementById("this-month-main").click();
</script>
<script>
	function res5(evt5, item5) {
	  var i, tabcontent5, tablinks5;
	  tabcontent5 = document.getElementsByClassName("tabcontent5");
	  for (i = 0; i < tabcontent5.length; i++) {
		tabcontent5[i].style.display = "none";
	  }
	  tablinks5 = document.getElementsByClassName("tablinks5");
	  for (i = 0; i < tablinks5.length; i++) {
		tablinks5[i].className = tablinks5[i].className.replace(" active", "");
	  }
	  document.getElementById(item5).style.display = "block";
	  evt5.currentTarget.className += " active";
	}
		document.getElementById("total-main").click();
</script>
<script>
var options = {
          series: [
          {
            name: "Impressions",
            <?php echo "data: ". $impressions_array . "\n"; ?>
          },
          {
            name: "Clicks",
            <?php echo "data: ". $clicks_array . "\n"; ?>
          }
        ],
          chart: {
          height: 350,
          type: 'line',
          dropShadow: {
            enabled: true,
            color: '#000',
            top: 18,
            left: 7,
            blur: 10,
            opacity: 0.2
          },
          toolbar: {
            show: false
          }
        },
        colors: ['#77B6EA', '#198754'],
        dataLabels: {
          enabled: true,
        },
        stroke: {
          curve: 'smooth'
        },
        title: {
          text: '',
          align: 'left'
        },
        grid: {
          borderColor: '#e7e7e7',
          row: {
            colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
            opacity: 0.5
          },
        },
        markers: {
          size: 1
        },
        xaxis: {
          <?php echo "categories: ". $days_array . "\n"; ?>,
          title: {
            text: 'Day'
          }
        },
        
        legend: {
          position: 'top',
          horizontalAlign: 'right',
          floating: true,
          offsetY: -25,
          offsetX: -5
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();
</script>

<svg id="SvgjsSvg1145" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;"><defs id="SvgjsDefs1146"></defs><polyline id="SvgjsPolyline1147" points="0,0"></polyline><path id="SvgjsPath1148" d="M-1 270.7625L-1 270.7625C-1 270.7625 128.9170673076923 270.7625 128.9170673076923 270.7625C128.9170673076923 270.7625 214.86177884615384 270.7625 214.86177884615384 270.7625C214.86177884615384 270.7625 300.80649038461536 270.7625 300.80649038461536 270.7625C300.80649038461536 270.7625 386.7512019230769 270.7625 386.7512019230769 270.7625C386.7512019230769 270.7625 472.69591346153845 270.7625 472.69591346153845 270.7625C472.69591346153845 270.7625 558.640625 270.7625 558.640625 270.7625C558.640625 270.7625 558.640625 270.7625 558.640625 270.7625 "></path></svg><svg id="SvgjsSvg1145" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;"><defs id="SvgjsDefs1146"></defs><polyline id="SvgjsPolyline1147" points="0,0"></polyline><path id="SvgjsPath1148" d="M-1 270.7625L-1 270.7625C-1 270.7625 175.07091346153845 270.7625 175.07091346153845 270.7625C175.07091346153845 270.7625 291.7848557692308 270.7625 291.7848557692308 270.7625C291.7848557692308 270.7625 408.4987980769231 270.7625 408.4987980769231 270.7625C408.4987980769231 270.7625 525.2127403846154 270.7625 525.2127403846154 270.7625C525.2127403846154 270.7625 641.9266826923077 270.7625 641.9266826923077 270.7625C641.9266826923077 270.7625 758.640625 270.7625 758.640625 270.7625C758.640625 270.7625 758.640625 270.7625 758.640625 270.7625 "></path></svg></body></html>
