<?php
require_once "../connect/connect1.php";
require_once "flt.php";

function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

$Ad_im = test_input($_GET['im']);
$Adv_redirect = test_input($_GET['r']);

$stmt = $pdo->prepare('SELECT * FROM ads_normal WHERE redirect = ?');
$stmt->execute([$Adv_redirect]);
$data = $stmt->fetchAll();
if ($data){
	for ($x = 1; $x <= 4; $x++) {
		$image = "image$x";
		$size = "size$x";
		$status = 4;
		$zero = 0;
		$empty = '';
		$stmt = $pdo->prepare("SELECT * FROM ads_normal WHERE redirect = ? and $image = ?");
		$stmt->execute([$Adv_redirect, $Ad_im]);
		$data = $stmt->fetchAll();
		if ($data){
			$stmt = $pdo->prepare("UPDATE ads_normal SET $size = ? and $image = ? WHERE redirect = ?");
			$stmt->execute([$zero, $empty, $Adv_redirect]);
			$stmt->fetchAll();
		}
	}
	header("Location: 2deb000b57bfac9d72c14d4ed967b572.php");
}
?>
<html>
<meta name="robots" content="noindex">
</html>
