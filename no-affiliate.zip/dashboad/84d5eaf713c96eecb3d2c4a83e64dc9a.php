<?php
include '../connect/connect.php';
include 'flt.php';
?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Payments</title>
  <meta name="robots" content="noindex">
  <meta content="" name="description">
  <meta content="" name="keywords">

  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.0/css/boxicons.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.snow.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.bubble.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/remixicon@2.2.0/fonts/remixicon.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.36.3/apexcharts.min.css" rel="stylesheet">
  <link href="https://unpkg.com/simple-datatables@2.1.13/dist/style.css" rel="stylesheet">
  <link href="https://bootstrapmade.com/demo/templates/NiceAdmin/assets/css/style.css" rel="stylesheet">
  </head>
<body>
			  <div class="col-12">
						<div class="card recent-sales" style="overflow: auto;">
						<div class="card-body">
                  <h5 class="card-title">Payments</h5>

                  <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns">
				  <div class="dataTable-container"><table class="table table-borderless datatable dataTable-table">
               <?php
				$coming_payment = 10;
				$type = 1;
				$blocked = 0;
				$stmt = $pdo->prepare('SELECT * FROM users WHERE coming_payment > ? AND type = ? AND blocked = ?');
				$stmt->execute([$coming_payment, $type, $blocked]);
				$data = $stmt->fetchAll();
			
					echo"<thead><tr><th scope=\"col\" style=\"width: 12%;\">id</th>
					<th scope=\"col\" style=\"width: 12%;\">full name</th>
					<th scope=\"col\" style=\"width: 12%;\">paypal</th>
					<th scope=\"col\" style=\"width: 12%;\">website</th>
					<th scope=\"col\" style=\"width: 12%;\">country</th>
					<th scope=\"col\" style=\"width: 12%;\">views</th>
					<th scope=\"col\" style=\"width: 12%;\">impressions</th>
					<th scope=\"col\" style=\"width: 12%;\">clicks</th>
					<th scope=\"col\" style=\"width: 12%;\">coming payment</th>
					<th scope=\"col\" style=\"width: 12%;\">action</th></tr>
                    </thead>
                    <tbody>";
				if ($data){
					foreach ($data as $user){				
						$redirect = $user["redirect"];
						$code = $user["code"];
						?>
						<tr>
						<td><?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['fullname'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['paypal'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['website'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars($user['country'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars(number_format($user['coming_views']), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars(number_format($user['coming_imps']), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= htmlspecialchars(number_format($user['coming_clicks']), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?= '$' . htmlspecialchars(number_format($user['coming_payment']), ENT_QUOTES, 'UTF-8'); ?></td>
						 <td><?php
							echo "<a href=\"user_paid.php?r=$redirect&c=$code\"><span class=\"badge bg-warning\">Paid</span></a>";
						 ?></td>
						 </tr>
						 <?php           
							}
						}
					?>
						 </tbody>
                  </table></div></div>
                </div>
            </div>
			</body>
		</html>	
