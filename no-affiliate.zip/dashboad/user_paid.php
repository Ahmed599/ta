<?php

include '../connect/connect.php';
require_once "flt.php";

function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

$redirect = test_input($_GET['r']);
$code = test_input($_GET['c']);

$coming_payment = 0;
$stmt = $pdo->prepare('UPDATE users SET coming_payment = ? WHERE redirect = ? AND code = ?');
$stmt->execute([$coming_payment, $redirect, $code]);
//$stmt->fetchAll();
$coming_payment = 0;
$stmt = $pdo->prepare('UPDATE users SET coming_imps = ? WHERE redirect = ? AND code = ?');
$stmt->execute([$coming_payment, $redirect, $code]);
//$stmt->fetchAll();
$coming_payment = 0;
$stmt = $pdo->prepare('UPDATE users SET coming_views = ? WHERE redirect = ? AND code = ?');
$stmt->execute([$coming_payment, $redirect, $code]);
//$stmt->fetchAll();
$coming_payment = 0;
$stmt = $pdo->prepare('UPDATE users SET coming_clicks = ? WHERE redirect = ? AND code = ?');
$stmt->execute([$coming_payment, $redirect, $code]);
//$stmt->fetchAll();
header("Location: 84d5eaf713c96eecb3d2c4a83e64dc9a.php");

?>
<html>
<meta name="robots" content="noindex">
</html>