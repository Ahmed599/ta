<?php
require_once "../connect/connect.php";
require_once "flt.php";

function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

$Ad_redirect = test_input($_GET['a']);

$paid = 1;
$stmt = $pdo->prepare('UPDATE ads_normal SET paid = ? WHERE redirect = ?');
$stmt->execute([$paid, $Ad_redirect]);
//$stmt->fetchAll();
header("Location: 2deb000b57bfac9d72c14d4ed967b572.php");
				
?>
<html>
<meta name="robots" content="noindex">
</html>