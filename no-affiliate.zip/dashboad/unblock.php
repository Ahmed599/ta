<?php
require_once "../connect/connect.php";
require_once "flt.php";

function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

$Adv_redirect = test_input($_GET['r']);

$blocked = 0;
$stmt = $pdo->prepare('UPDATE users SET blocked = ? WHERE redirect = ?');
$stmt->execute([$blocked, $Adv_redirect]);
header("Location: 9bc65c2abec141778ffaa729489f3e87.php");

?>
<html>
<meta name="robots" content="noindex">
</html>
