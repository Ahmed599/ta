<?php
session_start();
$email = $_SESSION["email"];

if (!isset($_SESSION['email'])){
        header('Location: https://www.topad.net');
}

if (!($email == "mariam@topad.net")){
        header('Location: https://www.topad.net');
}
?>
