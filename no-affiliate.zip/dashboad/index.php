<?php
session_start();
if (isset($_SESSION['email']) && $_SESSION['email'] == 'mariam@topad.net'){
	echo "<!DOCTYPE html><html><meta name=\"robots\" content=\"noindex\"><body><button onclick=\"document.location='2deb000b57bfac9d72c14d4ed967b572.php'\">Ads</button><button onclick=\"document.location='9bc65c2abec141778ffaa729489f3e87.php'\">Users</button><button onclick=\"document.location='84d5eaf713c96eecb3d2c4a83e64dc9a.php'\">Payments</button></body></html>";
}else{
	header('Location: https://www.topad.net');

}
?>

